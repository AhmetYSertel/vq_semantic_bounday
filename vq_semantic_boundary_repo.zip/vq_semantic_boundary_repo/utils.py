"""
Shared utilities for QCP experiments (v2).
Added: multi-seed runner, confidence intervals, improved data loading,
       variance helpers, reproducibility infrastructure.
"""

import os
import sys
import json
import csv
import time
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
from typing import Callable, Dict, List, Any, Optional

# Paths
ROOT = Path(__file__).parent
RESULTS_DIR = ROOT / "results"
PLOTS_DIR = ROOT / "plots"
DATA_DIR = ROOT / "data"
for d in [RESULTS_DIR, PLOTS_DIR, DATA_DIR]:
    d.mkdir(exist_ok=True)

plt.rcParams.update({
    'figure.figsize': (10, 6), 'figure.dpi': 300, 'font.size': 11,
    'font.family': 'serif', 'axes.grid': True, 'grid.alpha': 0.3,
    'axes.spines.top': False, 'axes.spines.right': False,
})

COLORS = {
    'qcp': '#2563EB', 'qcp_attn': '#7C3AED', 'nl': '#DC2626',
    'nl_string': '#F59E0B', 'nl_embed': '#10B981', 'accent': '#6366F1',
    'raw_emb': '#F97316', 'pq': '#14B8A6', 'json': '#8B5CF6',
}

# ============================================================
# Multi-Seed Runner
# ============================================================

def multi_seed_run(run_fn, seeds=[42, 123, 456, 789, 1024], **kwargs):
    """Run experiment across multiple seeds and aggregate."""
    all_results = []
    for i, seed in enumerate(seeds):
        print(f"\n{'~'*40} Seed {seed} ({i+1}/{len(seeds)}) {'~'*40}")
        result = run_fn(seed=seed, **kwargs)
        all_results.append(result)
    aggregated = aggregate_results(all_results)
    return {'per_seed': all_results, 'seeds': seeds, 'n_seeds': len(seeds), 'aggregated': aggregated}


def aggregate_results(results):
    """Aggregate numeric results across seeds: compute mean, std, CI."""
    if not results:
        return {}
    agg = {}
    def _collect_numeric(d, prefix=""):
        out = {}
        for k, v in d.items():
            key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                out[key] = v
            elif isinstance(v, dict):
                out.update(_collect_numeric(v, key))
        return out
    all_flat = [_collect_numeric(r) for r in results]
    all_keys = set()
    for f in all_flat:
        all_keys.update(f.keys())
    for key in sorted(all_keys):
        values = [f[key] for f in all_flat if key in f]
        if len(values) >= 2:
            arr = np.array(values, dtype=float)
            agg[key] = {
                'mean': float(np.mean(arr)), 'std': float(np.std(arr, ddof=1)),
                'ci95': float(1.96 * np.std(arr, ddof=1) / np.sqrt(len(arr))),
                'min': float(np.min(arr)), 'max': float(np.max(arr)),
                'n': len(arr), 'values': values,
            }
        elif len(values) == 1:
            agg[key] = {'mean': values[0], 'std': 0.0, 'ci95': 0.0, 'n': 1}
    return agg


def format_with_ci(mean, ci, decimals=4):
    return f"{mean:.{decimals}f} +/- {ci:.{decimals}f}"


# ============================================================
# File I/O
# ============================================================

def save_plot(fig, name):
    fig.savefig(PLOTS_DIR / f"{name}.png", bbox_inches='tight', dpi=300)
    fig.savefig(PLOTS_DIR / f"{name}.pdf", bbox_inches='tight')
    plt.close(fig)
    print(f"  -> Saved plot: {name}.png / .pdf")

def save_csv(data, headers, name):
    path = RESULTS_DIR / f"{name}.csv"
    with open(path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(data)
    print(f"  -> Saved CSV: {name}.csv")

def save_json(data, name):
    path = RESULTS_DIR / f"{name}.json"
    with open(path, 'w') as f:
        json.dump(data, f, indent=2, default=str)
    print(f"  -> Saved JSON: {name}.json")

def print_table(headers, rows, title=""):
    if title:
        print(f"\n{'='*60}")
        print(f"  {title}")
        print(f"{'='*60}")
    col_widths = [max(len(str(h)), max((len(str(r[i])) for r in rows), default=0))
                  for i, h in enumerate(headers)]
    header_str = " | ".join(f"{h:<{col_widths[i]}}" for i, h in enumerate(headers))
    separator = "-+-".join("-" * w for w in col_widths)
    print(f"  {header_str}")
    print(f"  {separator}")
    for row in rows:
        row_str = " | ".join(f"{str(v):<{col_widths[i]}}" for i, v in enumerate(row))
        print(f"  {row_str}")
    print()


# ============================================================
# Data Loading
# ============================================================

def load_diverse_texts(n=10000, seed=42):
    np.random.seed(seed)
    texts = []
    sources = {}
    try:
        from datasets import load_dataset
        print("  Loading STS Benchmark...")
        try:
            sts = load_dataset("sentence-transformers/stsb", split="test")
            c = 0
            for item in sts:
                texts.append(item['sentence1']); texts.append(item['sentence2']); c += 2
            sources['stsb'] = c
        except Exception as e:
            print(f"  STS load failed: {e}")
        print("  Loading DailyDialog...")
        try:
            dialog = load_dataset("daily_dialog", split="train")
            c = 0
            for item in dialog:
                for utt in item['dialog']:
                    if len(utt.strip()) > 10:
                        texts.append(utt.strip()); c += 1
                        if c >= n // 3: break
                if c >= n // 3: break
            sources['daily_dialog'] = c
        except Exception as e:
            print(f"  DailyDialog load failed: {e}")
    except ImportError:
        print("  datasets library not available, using synthetic data")
    if len(texts) < n:
        sc = n - len(texts)
        texts.extend(_generate_synthetic_texts(sc, seed))
        sources['synthetic'] = sc
    np.random.shuffle(texts)
    texts = texts[:n]
    print(f"  Loaded {len(texts)} texts total. Sources: {sources}")
    return texts


def _generate_synthetic_texts(n, seed=42):
    np.random.seed(seed)
    domains = {
        'science': ["The process of photosynthesis converts sunlight into chemical energy in plants",
            "Quantum mechanics describes the behavior of particles at the subatomic level",
            "Neural networks are computational models inspired by biological brain structures",
            "Climate change is driven by increasing greenhouse gas concentrations",
            "DNA replication ensures genetic information is passed to daughter cells",
            "The theory of relativity describes the relationship between space and time",
            "Enzymes catalyze biochemical reactions by lowering activation energy",
            "The periodic table organizes elements by atomic number and properties",
            "Evolution by natural selection explains the diversity of life on Earth",
            "Black holes form when massive stars collapse under their own gravity"],
        'technology': ["Machine learning algorithms improve their performance through experience with data",
            "Cloud computing provides on-demand access to shared computing resources",
            "Cybersecurity protects systems and networks from digital attacks",
            "The internet of things connects everyday devices to the internet",
            "Blockchain technology provides a decentralized and transparent ledger",
            "Virtual reality creates immersive simulated environments for users",
            "Edge computing processes data closer to where it is generated",
            "Natural language processing enables computers to understand human language",
            "Autonomous vehicles use sensors and AI to navigate without human input",
            "5G networks provide faster data speeds and lower latency than previous generations"],
        'business': ["Supply chain management coordinates the flow of goods from production to consumption",
            "Market analysis helps businesses understand customer needs and competition",
            "Financial planning involves setting goals and creating strategies to achieve them",
            "Human resources management handles recruitment training and employee relations",
            "Risk management identifies and mitigates potential threats to an organization",
            "Strategic planning defines an organization's direction and resource allocation",
            "Customer relationship management helps businesses manage interactions with clients",
            "Project management involves planning executing and closing projects effectively",
            "Innovation management fosters new ideas and brings them to market",
            "Corporate governance ensures accountability and fairness in business operations"],
        'health': ["Regular exercise improves cardiovascular health and reduces disease risk",
            "A balanced diet provides essential nutrients for bodily functions",
            "Mental health encompasses emotional psychological and social well-being",
            "Vaccines stimulate the immune system to protect against infectious diseases",
            "Sleep is essential for physical restoration and cognitive function",
            "Chronic stress can lead to various physical and mental health problems",
            "Physical therapy helps restore movement and function after injury",
            "Preventive medicine focuses on preventing diseases before they occur",
            "Telemedicine provides remote healthcare services using digital technology",
            "Nutrition science studies how food affects health and metabolism"],
        'daily': ["I need to pick up groceries from the store after work today",
            "The weather forecast says it will rain tomorrow afternoon",
            "Can you recommend a good restaurant for dinner tonight",
            "I am planning a vacation to Europe next summer",
            "The traffic on the highway was terrible this morning",
            "I just finished reading an interesting book about history",
            "My favorite hobby is gardening and growing vegetables",
            "We should schedule a meeting to discuss the project timeline",
            "The new coffee shop downtown has excellent espresso drinks",
            "I need to renew my passport before the trip next month"],
        'technical': ["The function returns a sorted array of integers in ascending order",
            "Database indexing significantly improves query execution performance",
            "API rate limiting prevents server overload from excessive requests",
            "Memory leaks occur when allocated memory is not properly freed",
            "Load balancing distributes network traffic across multiple servers",
            "Version control systems track changes to source code over time",
            "Unit tests verify that individual components work correctly in isolation",
            "Microservices architecture decomposes applications into small independent services",
            "Container orchestration manages the deployment of containerized applications",
            "Continuous integration automates building and testing of code changes"],
    }
    all_templates = []
    for t in domains.values(): all_templates.extend(t)
    prefixes = ["", "Essentially, ", "In summary, ", "To put it simply, ",
                "Research shows that ", "It is well known that ", "Studies indicate that "]
    suffixes = ["", ".", " in modern applications.", " across various domains.",
                " according to recent research.", " in current practice."]
    texts = []
    while len(texts) < n:
        t = all_templates[np.random.randint(len(all_templates))]
        p = prefixes[np.random.randint(len(prefixes))]
        s = suffixes[np.random.randint(len(suffixes))]
        texts.append(f"{p}{t}{s}".strip())
    return texts[:n]


def load_paraphrase_pairs(n=1000, seed=42):
    np.random.seed(seed)
    texts = _generate_synthetic_texts(n, seed)
    return [(t, _simple_paraphrase(t)) for t in texts]


def _simple_paraphrase(text):
    replacements = [("improves","enhances"),("reduces","decreases"),("provides","offers"),
        ("enables","allows"),("describes","explains"),("involves","includes"),
        ("helps","assists"),("ensures","guarantees"),("creates","generates"),
        ("uses","utilizes"),("process","procedure"),("system","framework"),
        ("important","significant"),("various","multiple"),("essential","crucial"),
        ("effectively","efficiently"),("significantly","substantially"),
        ("typically","usually"),("excellent","outstanding"),("interesting","fascinating"),
        ("good","great"),("new","novel"),("The ","A "),("the ","a ")]
    result = text
    np.random.shuffle(replacements)
    applied = 0
    for old, new in replacements:
        if old in result and applied < 3:
            result = result.replace(old, new, 1); applied += 1
    if np.random.random() > 0.5 and ", " in result:
        parts = result.split(", ", 1)
        result = parts[1].capitalize() + ", " + parts[0].lower()
    return result


# ============================================================
# Agent Communication Templates
# ============================================================

def generate_agent_messages(n=1000, seed=42):
    """Generate realistic agent communication messages with type labels."""
    np.random.seed(seed)
    messages = []
    templates = {
        'routing': [
            ("Route to {module} for {task}.", "routing"),
            ("Forward this request to the {module} module.", "routing"),
            ("Send to {module} handler.", "routing"),
            ("This should be handled by {module}.", "routing"),
            ("Assign to {module} for processing.", "routing"),
        ],
        'status': [
            ("Task {task_id} completed successfully.", "status_positive"),
            ("Task {task_id} failed with error.", "status_negative"),
            ("Processing {task_id} is in progress.", "status_neutral"),
            ("Task {task_id} has been queued.", "status_neutral"),
            ("Operation {task_id} timed out.", "status_negative"),
        ],
        'decision': [
            ("Output accepted. Proceed to next stage.", "decision_positive"),
            ("Output rejected. Requires revision.", "decision_negative"),
            ("Approved for deployment.", "decision_positive"),
            ("Denied. Insufficient permissions.", "decision_negative"),
            ("Validation passed.", "decision_positive"),
            ("Validation failed.", "decision_negative"),
            ("Quality check passed.", "decision_positive"),
            ("Quality check failed. Retry.", "decision_negative"),
        ],
        'tool_call': [
            ("Call search API with query: {query}.", "tool_call"),
            ("Execute database lookup for {entity}.", "tool_call"),
            ("Run code analysis on {file}.", "tool_call"),
            ("Invoke calculator for {expression}.", "tool_call"),
            ("Fetch data from {endpoint}.", "tool_call"),
        ],
        'handoff': [
            ("Subtask result: {summary}. Handing off to next module.", "handoff"),
            ("Intermediate output ready. Passing to {module}.", "handoff"),
            ("Phase 1 complete. Result: {summary}.", "handoff"),
            ("Analysis done. Key finding: {summary}.", "handoff"),
        ],
        'control': [
            ("Enable caching for this session.", "control_enable"),
            ("Do not enable caching.", "control_disable"),
            ("Activate verbose logging.", "control_enable"),
            ("Deactivate verbose logging.", "control_disable"),
            ("Increase the timeout to 30 seconds.", "control_modify"),
            ("Decrease the timeout to 5 seconds.", "control_modify"),
            ("Proceed with the action.", "control_enable"),
            ("Do not proceed with the action.", "control_disable"),
        ],
    }
    modules = ["memory","retrieval","reasoning","code_gen","search","analysis",
               "summarization","translation","classification","validation"]
    tasks = ["summarization","fact_checking","code_review","data_extraction",
             "sentiment_analysis","entity_recognition","translation","qa"]
    queries = ["latest AI research","stock prices","weather forecast","product reviews",
               "scientific papers","news articles","competitor analysis"]
    entities = ["user_123","order_456","product_789","session_abc","config_def"]
    files = ["main.py","config.yaml","report.docx","data.csv","model.pt"]
    endpoints = ["/api/v1/data","/api/v2/search","/internal/metrics","/external/feed"]
    summaries = ["data quality is high with 95% completeness",
        "three anomalies detected in the input",
        "performance metrics within acceptable range",
        "user sentiment is predominantly positive",
        "no critical issues found in code review"]
    expressions = ["sqrt(144)","log(1000)","45 * 23 + 17","0.15 * 2500"]

    for _ in range(n):
        msg_type = np.random.choice(list(templates.keys()))
        template, label = templates[msg_type][np.random.randint(len(templates[msg_type]))]
        text = template.format(
            module=np.random.choice(modules), task=np.random.choice(tasks),
            task_id=f"T-{np.random.randint(1000,9999)}", query=np.random.choice(queries),
            entity=np.random.choice(entities), file=np.random.choice(files),
            endpoint=np.random.choice(endpoints), summary=np.random.choice(summaries),
            expression=np.random.choice(expressions))
        messages.append({
            'text': text, 'type': msg_type, 'label': label,
            'has_negation': any(w in text.lower() for w in
                ['not','reject','fail','denied','disable','deactivate']),
        })
    return messages


def timer(func):
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        return result, time.perf_counter() - start
    return wrapper

def format_number(n, precision=4):
    if abs(n) >= 1000: return f"{n:,.0f}"
    return f"{n:.{precision}f}"
