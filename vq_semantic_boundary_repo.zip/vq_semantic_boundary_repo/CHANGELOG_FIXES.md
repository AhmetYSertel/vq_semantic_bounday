# qcp_experiments_v2 — Fixes (2026-03-01)

## What was fixed

1) Exp17 PQ baseline leakage fix
- PQ codebooks are now trained on TRAIN embeddings and applied to EVAL embeddings.
- Previous version trained PQ on eval embeddings (data leakage) which inflated fidelity.

2) qcp.py dual-mode top-k selection metric consistency
- encode_attention and encode_attention_batch now select top-k centroids by squared L2 distance,
  consistent with k-means/VQ geometry.
- Previous version used dot-product ranking, mixing similarity and reconstruction objectives.

3) Exp20 multi-code (residual VQ) corrected
- Multi-code now uses per-stage residual codebooks trained sequentially on residuals.
- Previous version reused a single codebook for all residual stages, which can reduce fidelity.

These changes aim to make baseline comparisons fairer and dual-mode/multi-code behavior consistent
with the intended reconstruction objective.
