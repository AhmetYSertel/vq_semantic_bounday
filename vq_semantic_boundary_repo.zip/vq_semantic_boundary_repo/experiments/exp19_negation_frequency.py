"""
Experiment 19: Negation Frequency Analysis (NEW)
=================================================
Measures how often critical logical distinctions appear in realistic
agent communication, and what fraction would fall below the margin
threshold (requiring escalation).

Answers the question: "Is the 0.4% escalation rate realistic for
production agent pipelines?"
"""

import sys
import numpy as np
sys.path.insert(0, ".")
from qcp import Codebook, Encoder, QCP
from utils import generate_agent_messages, load_diverse_texts, save_json, print_table


def run(n_messages=5000, K=256, seed=42):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 19: Negation Frequency Analysis")
    print("=" * 60)

    np.random.seed(seed)
    encoder = Encoder()

    # --- 1. Generate realistic agent messages ---
    print(f"\n[1/4] Generating {n_messages} agent messages...")
    messages = generate_agent_messages(n_messages, seed=seed)
    texts = [m['text'] for m in messages]
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)

    # --- 2. Train codebook ---
    print("[2/4] Training codebook...")
    train_texts = load_diverse_texts(5000, seed=seed+100)
    train_embs = encoder.encode(train_texts, batch_size=256)
    codebook = Codebook.train(train_embs, K=K, random_state=seed)
    qcp = QCP(codebook)

    # --- 3. Encode all messages ---
    print("[3/4] Encoding messages...")
    codes, qerrs, confs, deltas = qcp.encode_vq_batch(embeddings)

    # --- 4. Analysis ---
    print("[4/4] Analyzing...\n")

    # Count negation messages
    negation_msgs = [m for m in messages if m['has_negation']]
    negation_rate = len(negation_msgs) / len(messages)

    # Message type distribution
    type_counts = {}
    for m in messages:
        t = m['type']
        type_counts[t] = type_counts.get(t, 0) + 1

    # Label distribution (including positive/negative decisions)
    label_counts = {}
    for m in messages:
        l = m['label']
        label_counts[l] = label_counts.get(l, 0) + 1

    # Low-margin analysis
    low_margin_threshold = 0.05
    low_margin_mask = deltas < low_margin_threshold
    low_margin_rate = float(np.mean(low_margin_mask))

    # Low-margin among negation messages
    neg_indices = [i for i, m in enumerate(messages) if m['has_negation']]
    if neg_indices:
        neg_deltas = deltas[neg_indices]
        neg_low_margin = float(np.mean(neg_deltas < low_margin_threshold))
        neg_mean_delta = float(np.mean(neg_deltas))
    else:
        neg_low_margin = 0.0
        neg_mean_delta = 0.0

    # Low-margin among decision messages
    dec_indices = [i for i, m in enumerate(messages) if m['type'] == 'decision']
    if dec_indices:
        dec_deltas = deltas[dec_indices]
        dec_low_margin = float(np.mean(dec_deltas < low_margin_threshold))
    else:
        dec_low_margin = 0.0

    # Confidence-aware escalation estimate
    alpha_values = [0.3, 0.5, 0.7, 0.85]
    escalation_estimates = {}
    for alpha in alpha_values:
        esc_rate = float(np.mean((confs < alpha) | (deltas < 0.01)))
        esc_negation = float(np.mean(
            [(confs[i] < alpha or deltas[i] < 0.01) for i in neg_indices]
        )) if neg_indices else 0.0
        escalation_estimates[str(alpha)] = {
            'overall_escalation': esc_rate,
            'negation_escalation': esc_negation,
        }

    # Print results
    print(f"  Total messages: {len(messages)}")
    print(f"  Messages with negation/rejection: {len(negation_msgs)} ({negation_rate:.1%})")
    print(f"\n  Message type distribution:")
    for t, c in sorted(type_counts.items()):
        print(f"    {t:20s}: {c:5d} ({c/len(messages):.1%})")
    print(f"\n  Decision label distribution:")
    for l, c in sorted(label_counts.items()):
        if 'decision' in l or 'control' in l:
            print(f"    {l:20s}: {c:5d}")

    headers = ["Metric", "All Messages", "Negation Msgs", "Decision Msgs"]
    rows = [
        ["Count", str(len(messages)), str(len(negation_msgs)), str(len(dec_indices))],
        ["Low-margin rate (<0.05)", f"{low_margin_rate:.1%}",
         f"{neg_low_margin:.1%}", f"{dec_low_margin:.1%}"],
        ["Mean delta", f"{float(np.mean(deltas)):.4f}",
         f"{neg_mean_delta:.4f}", f"{float(np.mean(deltas[dec_indices])):.4f}" if dec_indices else "N/A"],
    ]
    print_table(headers, rows, "Negation & Low-Margin Analysis")

    print("  Escalation rate estimates by alpha threshold:")
    for alpha, est in escalation_estimates.items():
        print(f"    alpha={alpha}: overall={est['overall_escalation']:.1%}, "
              f"negation_msgs={est['negation_escalation']:.1%}")

    # Critical finding
    print(f"\n  KEY FINDING:")
    print(f"  In realistic agent traffic, {negation_rate:.1%} of messages contain")
    print(f"  negation/rejection patterns. Of these, {neg_low_margin:.1%} have")
    print(f"  delta < {low_margin_threshold} (low margin, high misrouting risk).")
    print(f"  This suggests production escalation rate may be ~{escalation_estimates['0.5']['overall_escalation']:.1%}")
    print(f"  at alpha=0.5, vs. the 0.4% observed on synthetic benchmarks.\n")

    summary = {
        'seed': seed, 'K': K, 'n_messages': len(messages),
        'negation_rate': negation_rate,
        'low_margin_rate_overall': low_margin_rate,
        'low_margin_rate_negation': neg_low_margin,
        'low_margin_rate_decisions': dec_low_margin,
        'type_distribution': type_counts,
        'label_distribution': label_counts,
        'escalation_estimates': escalation_estimates,
    }
    save_json(summary, "exp19_negation_frequency")
    return summary


if __name__ == "__main__":
    run()
