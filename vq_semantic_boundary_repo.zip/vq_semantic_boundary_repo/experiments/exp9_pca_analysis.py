"""
Experiment 9: PCA Dimensionality Reduction Analysis
=====================================================
Tests whether PCA pre-processing before VQ improves encoding fidelity
by removing noise dimensions from sentence-transformer embeddings.

Pipeline: text → encoder → 384d → PCA → kd → VQ → code

Two outcomes:
  - If noise is significant: PCA improves fidelity → add PCA-enhanced QCP
  - If noise is minimal: PCA hurts fidelity → confirms embeddings are compact
    (strong empirical finding for paper)

Measures:
  1. Explained variance ratio per component (how much info each dim carries)
  2. VQ fidelity in REDUCED space (kd cosine similarity)
  3. VQ fidelity in ORIGINAL space (384d, after inverse PCA + VQ decode)
  4. Codebook memory savings
  5. Quantization error comparison
"""

import sys
import numpy as np
from sklearn.decomposition import PCA

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS, PLOTS_DIR)
import matplotlib.pyplot as plt


def run(n_samples: int = 10000, K: int = 256,
        target_dims: list = None):
    if target_dims is None:
        target_dims = [32, 64, 128, 256]

    print("\n" + "="*60)
    print("  EXPERIMENT 9: PCA Dimensionality Reduction Analysis")
    print("="*60)

    # --- 1. Load and encode ---
    print("\n[1/5] Loading encoder and texts...")
    encoder = Encoder()
    texts = load_diverse_texts(n_samples)
    n_samples = len(texts)

    print(f"[2/5] Encoding {n_samples} texts...")
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)
    d_original = embeddings.shape[1]  # 384
    print(f"  Embedding dimension: {d_original}")

    # --- 2. PCA analysis: explained variance ---
    print("[3/5] Fitting full PCA for variance analysis...")
    pca_full = PCA(n_components=d_original, random_state=42)
    pca_full.fit(embeddings)

    explained = pca_full.explained_variance_ratio_
    cumulative = np.cumsum(explained)

    # Key thresholds
    dims_90 = int(np.searchsorted(cumulative, 0.90)) + 1
    dims_95 = int(np.searchsorted(cumulative, 0.95)) + 1
    dims_99 = int(np.searchsorted(cumulative, 0.99)) + 1

    print(f"  Dimensions for 90% variance: {dims_90}/{d_original}")
    print(f"  Dimensions for 95% variance: {dims_95}/{d_original}")
    print(f"  Dimensions for 99% variance: {dims_99}/{d_original}")
    print(f"  Top-10 components explain: {cumulative[9]:.1%}")
    print(f"  Top-64 components explain: {cumulative[63]:.1%}")

    # --- 3. Test VQ fidelity at each target dimension ---
    print(f"[4/5] Testing VQ fidelity at dims={target_dims}...")

    # Split: 50% train, 50% test
    split = n_samples // 2
    train_emb = embeddings[:split]
    test_emb = embeddings[split:]

    # Baseline: no PCA (full 384d)
    print(f"\n  d={d_original:>4} (baseline, no PCA):")
    train_size = max(K * 10, split // 2)
    train_idx = np.random.choice(split, train_size, replace=False)
    cb_baseline = Codebook.train(train_emb[train_idx], K=K)
    qcp_baseline = QCP(cb_baseline)

    fidelity_baseline = qcp_baseline.encoding_fidelity_batch(test_emb)
    codes_bl, qerrs_bl, _, _ = qcp_baseline.encode_vq_batch(test_emb)

    baseline_stats = {
        'dim': d_original,
        'variance_retained': 1.0,
        'fidelity_reduced_mean': float(np.mean(fidelity_baseline)),
        'fidelity_reduced_median': float(np.median(fidelity_baseline)),
        'fidelity_original_mean': float(np.mean(fidelity_baseline)),
        'fidelity_original_median': float(np.median(fidelity_baseline)),
        'qerr_mean': float(np.mean(qerrs_bl)),
        'qerr_median': float(np.median(qerrs_bl)),
        'codebook_bytes': int(K * d_original * 4),  # float32
        'pca': False,
    }
    print(f"    Fidelity: mean={baseline_stats['fidelity_original_mean']:.4f}  "
          f"median={baseline_stats['fidelity_original_median']:.4f}")
    print(f"    qerr:     mean={baseline_stats['qerr_mean']:.4f}  "
          f"median={baseline_stats['qerr_median']:.4f}")
    print(f"    Codebook: {baseline_stats['codebook_bytes']:,} bytes")

    # Test each PCA dimension
    pca_results = []
    fidelity_arrays = {'baseline': fidelity_baseline}

    for d_target in target_dims:
        if d_target >= d_original:
            continue

        print(f"\n  d={d_target:>4} (PCA {d_original}→{d_target}, "
              f"variance={cumulative[d_target-1]:.1%}):")

        # Fit PCA on training data
        pca = PCA(n_components=d_target, random_state=42)
        pca.fit(train_emb)

        # Transform
        train_reduced = pca.transform(train_emb).astype(np.float32)
        test_reduced = pca.transform(test_emb).astype(np.float32)

        # Train codebook in reduced space
        train_idx_pca = np.random.choice(split, train_size, replace=False)
        cb_pca = Codebook.train(train_reduced[train_idx_pca], K=K)
        qcp_pca = QCP(cb_pca)

        # A) Fidelity in REDUCED space: cos(e_reduced, decode(encode(e_reduced)))
        fidelity_reduced = qcp_pca.encoding_fidelity_batch(test_reduced)
        codes_pca, qerrs_pca, _, _ = qcp_pca.encode_vq_batch(test_reduced)

        # B) Fidelity in ORIGINAL space: cos(e_original, pca_inverse(decode(encode(pca(e_original)))))
        # Decode in reduced space, then inverse PCA back to 384d
        decoded_reduced = cb_pca.decode_batch(codes_pca)  # (N, d_target)
        decoded_original = pca.inverse_transform(decoded_reduced)  # (N, 384)

        # Cosine similarity in original 384d space
        norms_orig = np.linalg.norm(test_emb, axis=1, keepdims=True)
        norms_dec = np.linalg.norm(decoded_original, axis=1, keepdims=True)
        fidelity_original = np.sum(test_emb * decoded_original, axis=1) / (
            norms_orig.flatten() * norms_dec.flatten() + 1e-10)

        # C) PCA-only fidelity (no VQ, just project and reconstruct)
        # Shows how much PCA alone loses
        pca_reconstructed = pca.inverse_transform(test_reduced)
        norms_pca_rec = np.linalg.norm(pca_reconstructed, axis=1, keepdims=True)
        fidelity_pca_only = np.sum(test_emb * pca_reconstructed, axis=1) / (
            norms_orig.flatten() * norms_pca_rec.flatten() + 1e-10)

        result = {
            'dim': d_target,
            'variance_retained': float(cumulative[d_target-1]),
            'fidelity_reduced_mean': float(np.mean(fidelity_reduced)),
            'fidelity_reduced_median': float(np.median(fidelity_reduced)),
            'fidelity_original_mean': float(np.mean(fidelity_original)),
            'fidelity_original_median': float(np.median(fidelity_original)),
            'fidelity_pca_only_mean': float(np.mean(fidelity_pca_only)),
            'fidelity_pca_only_median': float(np.median(fidelity_pca_only)),
            'qerr_mean': float(np.mean(qerrs_pca)),
            'qerr_median': float(np.median(qerrs_pca)),
            'codebook_bytes': int(K * d_target * 4),
            'pca_matrix_bytes': int(d_original * d_target * 4),
            'memory_saving': float(1 - (K * d_target) / (K * d_original)),
            'pca': True,
        }
        pca_results.append(result)
        fidelity_arrays[f'd{d_target}'] = fidelity_original

        print(f"    Fidelity (reduced {d_target}d): mean={result['fidelity_reduced_mean']:.4f}  "
              f"median={result['fidelity_reduced_median']:.4f}")
        print(f"    Fidelity (original 384d):  mean={result['fidelity_original_mean']:.4f}  "
              f"median={result['fidelity_original_median']:.4f}")
        print(f"    Fidelity (PCA only, no VQ): mean={result['fidelity_pca_only_mean']:.4f}  "
              f"median={result['fidelity_pca_only_median']:.4f}")
        print(f"    qerr (reduced):    mean={result['qerr_mean']:.4f}  "
              f"median={result['qerr_median']:.4f}")
        print(f"    Codebook memory:   {result['codebook_bytes']:,} bytes "
              f"({result['memory_saving']:.0%} saving)")
        print(f"    Δ fidelity vs baseline: {result['fidelity_original_mean'] - baseline_stats['fidelity_original_mean']:+.4f}")

    # --- 4. Plots ---
    print("\n[5/5] Generating plots...")

    # Plot 1: Explained variance curve
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    axes[0].plot(range(1, d_original + 1), cumulative, color=COLORS['qcp'], lw=2)
    axes[0].axhline(y=0.90, color='gray', ls='--', alpha=0.5, label='90%')
    axes[0].axhline(y=0.95, color='gray', ls=':', alpha=0.5, label='95%')
    axes[0].axhline(y=0.99, color='gray', ls='-.', alpha=0.5, label='99%')
    for d_t in target_dims:
        if d_t < d_original:
            axes[0].axvline(x=d_t, color=COLORS['accent'], ls='--', alpha=0.3)
            axes[0].annotate(f'd={d_t}\n{cumulative[d_t-1]:.1%}',
                           xy=(d_t, cumulative[d_t-1]),
                           fontsize=8, ha='left')
    axes[0].set_xlabel('Number of PCA Components')
    axes[0].set_ylabel('Cumulative Explained Variance')
    axes[0].set_title('PCA Explained Variance (all-MiniLM-L6-v2)')
    axes[0].legend(fontsize=9)
    axes[0].set_xlim(0, d_original)
    axes[0].set_ylim(0, 1.05)

    # Plot 2: Fidelity comparison bar chart
    all_dims = [r['dim'] for r in pca_results]
    fid_reduced = [r['fidelity_reduced_mean'] for r in pca_results]
    fid_original = [r['fidelity_original_mean'] for r in pca_results]
    fid_pca_only = [r['fidelity_pca_only_mean'] for r in pca_results]

    x = np.arange(len(all_dims) + 1)  # +1 for baseline
    width = 0.25

    labels = [f'd={d}' for d in all_dims] + [f'd={d_original}\n(no PCA)']
    fid_reduced_full = fid_reduced + [baseline_stats['fidelity_reduced_mean']]
    fid_original_full = fid_original + [baseline_stats['fidelity_original_mean']]
    fid_pca_only_full = fid_pca_only + [1.0]  # no PCA = perfect reconstruction

    bars1 = axes[1].bar(x - width, fid_original_full, width,
                        label='Original 384d fidelity', color=COLORS['qcp'], alpha=0.8)
    bars2 = axes[1].bar(x, fid_reduced_full, width,
                        label='Reduced space fidelity', color=COLORS['qcp_attn'], alpha=0.8)
    bars3 = axes[1].bar(x + width, fid_pca_only_full, width,
                        label='PCA-only (no VQ)', color=COLORS['accent'], alpha=0.8)

    axes[1].set_xlabel('PCA Target Dimension')
    axes[1].set_ylabel('Mean Cosine Similarity (Fidelity)')
    axes[1].set_title('VQ Fidelity: PCA-Reduced vs Baseline')
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(labels)
    axes[1].legend(fontsize=9)
    axes[1].set_ylim(0.5, 1.05)

    # Add value labels on bars
    for bars in [bars1, bars2, bars3]:
        for bar in bars:
            h = bar.get_height()
            if h > 0.5:
                axes[1].annotate(f'{h:.3f}',
                               xy=(bar.get_x() + bar.get_width()/2, h),
                               xytext=(0, 3), textcoords='offset points',
                               ha='center', va='bottom', fontsize=7)

    fig.suptitle('Experiment 9: PCA Dimensionality Reduction Analysis', fontsize=14)
    plt.tight_layout()
    save_plot(fig, 'exp9_pca_analysis')

    # Plot 3: Box plot comparing fidelity distributions
    fig, ax = plt.subplots(figsize=(10, 6))
    box_data = []
    box_labels = []
    box_colors_list = []

    for d_t in target_dims:
        if d_t < d_original and f'd{d_t}' in fidelity_arrays:
            box_data.append(fidelity_arrays[f'd{d_t}'])
            box_labels.append(f'PCA→{d_t}d')
            box_colors_list.append(COLORS['qcp_attn'])

    box_data.append(fidelity_arrays['baseline'])
    box_labels.append(f'No PCA\n({d_original}d)')
    box_colors_list.append(COLORS['qcp'])

    bp = ax.boxplot(box_data, labels=box_labels, patch_artist=True, widths=0.5)
    for patch, color in zip(bp['boxes'], box_colors_list):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)

    ax.set_ylabel('Cosine Similarity (Fidelity in Original 384d Space)')
    ax.set_title('VQ Fidelity Distribution: PCA-Reduced vs Baseline')
    save_plot(fig, 'exp9_pca_boxplot')

    # Plot 4: Memory vs Fidelity tradeoff
    fig, ax = plt.subplots(figsize=(8, 6))
    mem_savings = [r['memory_saving'] * 100 for r in pca_results]
    fid_orig = [r['fidelity_original_mean'] for r in pca_results]
    dims_labels = [r['dim'] for r in pca_results]

    ax.scatter(mem_savings, fid_orig, s=120, color=COLORS['qcp_attn'],
              zorder=5, edgecolors='white', linewidth=1.5)
    ax.scatter([0], [baseline_stats['fidelity_original_mean']], s=150,
              color=COLORS['qcp'], marker='*', zorder=5, label='Baseline (no PCA)')

    for i, d_t in enumerate(dims_labels):
        ax.annotate(f'd={d_t}', (mem_savings[i], fid_orig[i]),
                   textcoords='offset points', xytext=(8, 5), fontsize=9)

    ax.set_xlabel('Codebook Memory Saving (%)')
    ax.set_ylabel('Mean Fidelity (Original 384d Space)')
    ax.set_title('PCA: Memory Savings vs Fidelity Tradeoff')
    ax.legend()
    save_plot(fig, 'exp9_pca_tradeoff')

    # --- 5. Save results ---
    # CSV: per-sample fidelity for each dimension
    csv_rows = []
    for i in range(len(test_emb)):
        row = [i, float(fidelity_baseline[i])]
        for d_t in target_dims:
            if d_t < d_original and f'd{d_t}' in fidelity_arrays:
                row.append(float(fidelity_arrays[f'd{d_t}'][i]))
        csv_rows.append(row)

    csv_headers = ['sample_id', f'fidelity_d{d_original}']
    for d_t in target_dims:
        if d_t < d_original:
            csv_headers.append(f'fidelity_pca{d_t}')
    save_csv(csv_rows, csv_headers, 'exp9_pca_fidelity_raw')

    # JSON summary
    summary = {
        'n_samples': n_samples,
        'n_test': len(test_emb),
        'K': K,
        'd_original': d_original,
        'encoder': encoder.model_name,
        'variance_analysis': {
            'dims_for_90pct': dims_90,
            'dims_for_95pct': dims_95,
            'dims_for_99pct': dims_99,
            'top10_variance': float(cumulative[9]),
            'top64_variance': float(cumulative[63]),
            'top128_variance': float(cumulative[127]),
        },
        'baseline': baseline_stats,
        'pca_results': pca_results,
        'conclusion': None,  # filled below
    }

    # Auto-determine conclusion
    best_pca = max(pca_results, key=lambda r: r['fidelity_original_mean'])
    if best_pca['fidelity_original_mean'] > baseline_stats['fidelity_original_mean'] + 0.005:
        summary['conclusion'] = {
            'verdict': 'PCA_HELPS',
            'best_dim': best_pca['dim'],
            'improvement': best_pca['fidelity_original_mean'] - baseline_stats['fidelity_original_mean'],
            'narrative': (f"PCA to d={best_pca['dim']} improves 384d fidelity by "
                         f"{best_pca['fidelity_original_mean'] - baseline_stats['fidelity_original_mean']:+.4f}, "
                         f"indicating significant noise in the embedding space. "
                         f"Recommended: integrate PCA pre-processing into QCP pipeline.")
        }
    elif best_pca['fidelity_original_mean'] >= baseline_stats['fidelity_original_mean'] - 0.005:
        summary['conclusion'] = {
            'verdict': 'PCA_NEUTRAL',
            'best_dim': best_pca['dim'],
            'delta': best_pca['fidelity_original_mean'] - baseline_stats['fidelity_original_mean'],
            'narrative': (f"PCA dimensionality reduction has negligible impact on fidelity "
                         f"(Δ={best_pca['fidelity_original_mean'] - baseline_stats['fidelity_original_mean']:+.4f}). "
                         f"Sentence-transformer embeddings are already compact with minimal noise. "
                         f"PCA can be used for memory savings ({best_pca['memory_saving']:.0%}) "
                         f"without quality loss.")
        }
    else:
        summary['conclusion'] = {
            'verdict': 'PCA_HURTS',
            'best_dim': best_pca['dim'],
            'loss': baseline_stats['fidelity_original_mean'] - best_pca['fidelity_original_mean'],
            'narrative': (f"PCA reduces fidelity by "
                         f"{baseline_stats['fidelity_original_mean'] - best_pca['fidelity_original_mean']:.4f}. "
                         f"All {d_original} dimensions carry semantic information; "
                         f"dimensionality reduction causes information loss. "
                         f"The embedding space is already maximally compact.")
        }

    save_json(summary, 'exp9_pca_summary')

    # Paper-ready summary
    print("\n  📝 Paper Summary:")
    print(f"  {summary['conclusion']['narrative']}")
    print(f"  Variance: 90% at d={dims_90}, 95% at d={dims_95}, 99% at d={dims_99}")
    for r in pca_results:
        print(f"    d={r['dim']:>4}: fidelity_384d={r['fidelity_original_mean']:.4f}  "
              f"Δ={r['fidelity_original_mean'] - baseline_stats['fidelity_original_mean']:+.4f}  "
              f"memory={r['memory_saving']:.0%} saved")

    return summary


if __name__ == '__main__':
    run()
