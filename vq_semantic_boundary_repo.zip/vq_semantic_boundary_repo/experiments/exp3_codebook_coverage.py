"""
Experiment 3: Codebook Coverage
=================================
Assesses what fraction of real-world semantic inputs are adequately
represented by a K=256 codebook.
"""

import sys
import numpy as np

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS)
import matplotlib.pyplot as plt


def run(n_corpus: int = 50000, K: int = 256):
    print("\n" + "="*60)
    print("  EXPERIMENT 3: Codebook Coverage")
    print("="*60)

    # --- 1. Load data ---
    print(f"\n[1/4] Loading {n_corpus} texts...")
    texts = load_diverse_texts(n_corpus)
    n_corpus = len(texts)

    # --- 2. Encode ---
    print("[2/4] Encoding corpus...")
    encoder = Encoder()
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)

    # --- 3. Train codebook on 10% subset, test on rest ---
    print(f"[3/4] Training codebook (K={K}) on 10% subset...")
    train_size = max(K * 4, n_corpus // 10)
    indices = np.random.permutation(n_corpus)
    train_idx = indices[:train_size]
    test_idx = indices[train_size:]

    codebook = Codebook.train(embeddings[train_idx], K=K)
    qcp = QCP(codebook)

    test_embeddings = embeddings[test_idx]
    n_test = len(test_embeddings)
    print(f"  Train: {train_size}, Test: {n_test}")

    # --- 4. Compute coverage metrics ---
    print("[4/4] Computing coverage metrics...")

    codes, qerrs, confs, deltas = qcp.encode_vq_batch(test_embeddings)
    fidelities = qcp.encoding_fidelity_batch(test_embeddings)

    # Coverage rate at various thresholds
    qerr_thresholds = np.linspace(0, np.percentile(qerrs, 99), 100)
    coverage_rates = [float(np.mean(qerrs <= t)) for t in qerr_thresholds]

    # Fidelity-based coverage
    fid_thresholds = np.linspace(0.5, 1.0, 100)
    fid_coverage = [float(np.mean(fidelities >= t)) for t in fid_thresholds]

    # Codebook utilization
    unique_codes, code_counts = np.unique(codes, return_counts=True)
    utilization = len(unique_codes) / K
    dead_codes = K - len(unique_codes)

    # Usage distribution stats
    full_usage = np.zeros(K)
    for code, count in zip(unique_codes, code_counts):
        full_usage[code] = count

    usage_stats = {
        'utilization': utilization,
        'dead_codes': dead_codes,
        'max_usage': int(np.max(code_counts)),
        'min_usage': int(np.min(code_counts)),
        'mean_usage': float(np.mean(code_counts)),
        'std_usage': float(np.std(code_counts)),
        'gini': float(_gini_coefficient(full_usage)),
    }

    # Results
    qerr_stats = {
        'mean': float(np.mean(qerrs)),
        'median': float(np.median(qerrs)),
        'p5': float(np.percentile(qerrs, 5)),
        'p95': float(np.percentile(qerrs, 95)),
        'max': float(np.max(qerrs)),
    }

    headers = ["Metric", "Value"]
    rows = [
        ["Mean qerr", f"{qerr_stats['mean']:.4f}"],
        ["Median qerr", f"{qerr_stats['median']:.4f}"],
        ["P95 qerr", f"{qerr_stats['p95']:.4f}"],
        ["Mean fidelity (cosine)", f"{np.mean(fidelities):.4f}"],
        ["Coverage (fidelity > 0.9)", f"{np.mean(fidelities > 0.9):.1%}"],
        ["Coverage (fidelity > 0.8)", f"{np.mean(fidelities > 0.8):.1%}"],
        ["Codebook utilization", f"{utilization:.1%} ({len(unique_codes)}/{K})"],
        ["Dead codes", f"{dead_codes}"],
        ["Gini coefficient", f"{usage_stats['gini']:.3f}"],
        ["Most used centroid", f"{usage_stats['max_usage']} assignments"],
        ["Mean conf", f"{np.mean(confs):.4f}"],
        ["VQ mode rate (conf≥0.7 & Δ≥0.1)", f"{np.mean((confs >= 0.7) & (deltas >= 0.1)):.1%}"],
    ]
    print_table(headers, rows, f"Codebook Coverage (K={K}, N_test={n_test})")

    # --- Plot 1: qerr histogram ---
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    axes[0, 0].hist(qerrs, bins=100, color=COLORS['qcp'], alpha=0.7, density=True)
    axes[0, 0].axvline(np.mean(qerrs), color='red', ls='--', label=f"Mean={np.mean(qerrs):.3f}")
    axes[0, 0].set_xlabel("Quantization Error (qerr)")
    axes[0, 0].set_ylabel("Density")
    axes[0, 0].set_title("Quantization Error Distribution")
    axes[0, 0].legend()

    # Plot 2: Coverage rate curve
    axes[0, 1].plot(fid_thresholds, fid_coverage, color=COLORS['qcp'], lw=2)
    axes[0, 1].axhline(0.9, color='gray', ls=':', alpha=0.5)
    axes[0, 1].axvline(0.9, color='gray', ls=':', alpha=0.5)
    axes[0, 1].set_xlabel("Fidelity Threshold (cosine sim)")
    axes[0, 1].set_ylabel("Coverage Rate")
    axes[0, 1].set_title("Coverage Rate vs Fidelity Threshold")
    # Mark 90% fidelity point
    idx_90 = np.argmin(np.abs(np.array(fid_thresholds) - 0.9))
    axes[0, 1].annotate(f"{fid_coverage[idx_90]:.1%} at 0.9",
                         xy=(0.9, fid_coverage[idx_90]),
                         xytext=(0.75, fid_coverage[idx_90] - 0.15),
                         arrowprops=dict(arrowstyle="->"), fontsize=10)

    # Plot 3: Codebook utilization
    sorted_usage = np.sort(full_usage)[::-1]
    axes[1, 0].bar(range(K), sorted_usage, color=COLORS['qcp'], alpha=0.7, width=1.0)
    axes[1, 0].set_xlabel("Centroid (sorted by usage)")
    axes[1, 0].set_ylabel("Number of Assignments")
    axes[1, 0].set_title(f"Codebook Utilization (Gini={usage_stats['gini']:.3f})")

    # Plot 4: Fidelity histogram
    axes[1, 1].hist(fidelities, bins=80, color=COLORS['qcp'], alpha=0.7, density=True)
    axes[1, 1].axvline(np.mean(fidelities), color='red', ls='--',
                        label=f"Mean={np.mean(fidelities):.4f}")
    axes[1, 1].set_xlabel("Encoding Fidelity (cosine sim)")
    axes[1, 1].set_ylabel("Density")
    axes[1, 1].set_title("Encoding Fidelity Distribution")
    axes[1, 1].legend()

    fig.suptitle(f"Experiment 3: Codebook Coverage (K={K})", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp3_coverage")

    # Save data
    save_csv(
        [[float(qerr_thresholds[i]), coverage_rates[i]] for i in range(len(qerr_thresholds))],
        ["qerr_threshold", "coverage_rate"],
        "exp3_coverage_curve"
    )

    save_json({
        'K': K,
        'n_test': n_test,
        'qerr': qerr_stats,
        'mean_fidelity': float(np.mean(fidelities)),
        'coverage_90': float(np.mean(fidelities > 0.9)),
        'coverage_80': float(np.mean(fidelities > 0.8)),
        'utilization': usage_stats,
    }, "exp3_coverage_summary")

    print(f"\n  📝 Paper Summary:")
    print(f"  A K={K} codebook achieves {np.mean(fidelities):.1%} mean encoding fidelity")
    print(f"  with {np.mean(fidelities > 0.9):.1%} of inputs above 0.9 cosine similarity.")
    print(f"  Codebook utilization: {utilization:.1%} ({dead_codes} dead codes).")

    return {'mean_fidelity': float(np.mean(fidelities)), 'utilization': utilization}


def _gini_coefficient(arr):
    """Compute Gini coefficient (0=perfect equality, 1=perfect inequality)."""
    arr = np.sort(arr.flatten()).astype(float)
    n = len(arr)
    if n == 0 or np.sum(arr) == 0:
        return 0.0
    index = np.arange(1, n + 1)
    return float((2 * np.sum(index * arr) - (n + 1) * np.sum(arr)) / (n * np.sum(arr)))


if __name__ == "__main__":
    run()
