"""
Experiment 20: Multi-Code Evaluation (NEW)
==========================================
Evaluates multi-code encoding (residual VQ) at n=1,2,3,4 codes.

Multi-code encoding: after assigning the first code, subtract the
centroid and encode the residual. This extends resolution to K^n
distinct addresses.

Reports fidelity vs bandwidth tradeoff.
"""

import sys
import time
import numpy as np
sys.path.insert(0, ".")
from qcp import Codebook, Encoder, QCP
from utils import load_diverse_texts, save_json, save_plot, print_table, COLORS
import matplotlib.pyplot as plt


def train_stage_codebooks(train_embeddings, K, n_stages, seed=42):
    """Train one codebook per residual stage (proper residual VQ)."""
    stage_codebooks = []
    residuals = train_embeddings.astype(np.float32).copy()
    for s in range(n_stages):
        cb = Codebook.train(residuals, K=K, random_state=seed + s)
        stage_codebooks.append(cb)
        # Update residuals for next stage
        # Nearest centroid under current stage codebook
        dists = (np.sum(residuals ** 2, axis=1, keepdims=True) +
                 np.sum(cb.centroids ** 2, axis=1, keepdims=True).T -
                 2.0 * residuals @ cb.centroids.T)
        codes = np.argmin(dists, axis=1)
        residuals = residuals - cb.centroids[codes]
    return stage_codebooks


def multi_code_encode_stagewise(embedding, stage_codebooks, n_codes):
    """Residual VQ with per-stage codebooks."""
    residual = embedding.astype(np.float32).copy()
    codes = []
    reconstructed = np.zeros_like(residual)
    for s in range(n_codes):
        cb = stage_codebooks[s]
        dists = np.sum((cb.centroids - residual) ** 2, axis=1)
        code = int(np.argmin(dists))
        codes.append(code)
        centroid = cb.centroids[code]
        reconstructed += centroid
        residual = residual - centroid
    qerr = float(np.sum((embedding - reconstructed) ** 2))
    return codes, reconstructed, qerr


def multi_code_encode_batch_stagewise(embeddings, stage_codebooks, n_codes):
    """Batch residual VQ with per-stage codebooks."""
    embeddings = embeddings.astype(np.float32)
    N, d = embeddings.shape
    all_codes = np.zeros((N, n_codes), dtype=np.int32)
    residuals = embeddings.copy()
    reconstructed = np.zeros_like(embeddings)

    for s in range(n_codes):
        cb = stage_codebooks[s]
        dists = (np.sum(residuals ** 2, axis=1, keepdims=True) +
                 np.sum(cb.centroids ** 2, axis=1, keepdims=True).T -
                 2.0 * residuals @ cb.centroids.T)
        codes = np.argmin(dists, axis=1)
        all_codes[:, s] = codes
        cent = cb.centroids[codes]
        reconstructed += cent
        residuals = residuals - cent

    return all_codes, reconstructed



def run(n_samples=5000, K=256, seed=42):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 20: Multi-Code Evaluation")
    print("=" * 60)

    np.random.seed(seed)
    encoder = Encoder()
    texts = load_diverse_texts(n_samples, seed=seed)
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)

    # Split
    split = n_samples // 2
    train_emb, eval_emb = embeddings[:split], embeddings[split:]
    max_codes = 4
    stage_codebooks = train_stage_codebooks(train_emb, K=K, n_stages=max_codes, seed=seed)

    results = {}
    code_counts = [1, 2, 3, 4]

    for n_codes in code_counts:
        print(f"\n  Evaluating n_codes={n_codes}...")
        t0 = time.perf_counter()
        all_codes, reconstructed = multi_code_encode_batch_stagewise(eval_emb, stage_codebooks, n_codes)
        encode_time = time.perf_counter() - t0

        fidelities = QCP.cosine_similarity_batch(eval_emb, reconstructed)

        # Byte cost: n_codes bytes (for K=256) + metadata (12 bytes)
        byte_cost = n_codes * 1 + 12  # codes + qerr/conf/delta

        results[n_codes] = {
            'n_codes': n_codes,
            'fidelity_mean': float(np.mean(fidelities)),
            'fidelity_median': float(np.median(fidelities)),
            'fidelity_p5': float(np.percentile(fidelities, 5)),
            'fidelity_p95': float(np.percentile(fidelities, 95)),
            'fidelity_std': float(np.std(fidelities)),
            'byte_cost': byte_cost,
            'full_msg_bytes': byte_cost + 16 + 8,  # + source_id + timestamp
            'encode_time_ms': encode_time * 1000,
            'distinct_addresses': K ** n_codes,
        }

    # Print
    headers = ["N Codes", "Fidelity (mean)", "Fidelity (med)", "P5", "P95",
               "Bytes/msg", "Addresses", "Encode (ms)"]
    rows = []
    for nc in code_counts:
        r = results[nc]
        rows.append([
            nc, f"{r['fidelity_mean']:.4f}", f"{r['fidelity_median']:.4f}",
            f"{r['fidelity_p5']:.4f}", f"{r['fidelity_p95']:.4f}",
            r['full_msg_bytes'], f"{r['distinct_addresses']:,}", f"{r['encode_time_ms']:.1f}",
        ])
    print_table(headers, rows, "Multi-Code Encoding: Fidelity vs Bandwidth")

    # Improvement over single code
    base_fid = results[1]['fidelity_mean']
    for nc in code_counts[1:]:
        delta = results[nc]['fidelity_mean'] - base_fid
        bw_ratio = results[nc]['full_msg_bytes'] / results[1]['full_msg_bytes']
        print(f"  n={nc}: fidelity +{delta:.4f} vs n=1, bandwidth {bw_ratio:.1f}x")

    save_json({'seed': seed, 'K': K, 'n_eval': len(eval_emb), 'results': results},
              "exp20_multi_code")

    # Plot
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    ncs = code_counts
    fids = [results[nc]['fidelity_mean'] for nc in ncs]
    bws = [results[nc]['full_msg_bytes'] for nc in ncs]
    fid_stds = [results[nc]['fidelity_std'] for nc in ncs]

    axes[0].errorbar(ncs, fids, yerr=fid_stds, marker='o', color=COLORS['qcp'],
                     capsize=5, linewidth=2)
    axes[0].set_xlabel("Number of Codes")
    axes[0].set_ylabel("Mean Fidelity")
    axes[0].set_title("Fidelity vs Number of Codes")
    axes[0].set_xticks(ncs)

    axes[1].bar(ncs, bws, color=COLORS['qcp'], alpha=0.8)
    axes[1].set_xlabel("Number of Codes")
    axes[1].set_ylabel("Message Size (bytes)")
    axes[1].set_title("Bandwidth vs Number of Codes")
    axes[1].set_xticks(ncs)

    fig.suptitle("Experiment 20: Multi-Code Encoding Evaluation", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp20_multi_code")

    return results


if __name__ == "__main__":
    run()
