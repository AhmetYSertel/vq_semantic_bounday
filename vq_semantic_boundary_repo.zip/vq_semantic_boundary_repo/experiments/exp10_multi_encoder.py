"""
Experiment 10: Multi-Encoder Fidelity Analysis
================================================
Tests QCP encoding fidelity across multiple sentence-transformer encoders
to validate that results are encoder-agnostic, not specific to all-MiniLM-L6-v2.

Encoders:
  1. all-MiniLM-L6-v2 (d=384)  — baseline (used in all other experiments)
  2. all-mpnet-base-v2 (d=768) — larger, higher quality embeddings

Measures per encoder:
  - VQ fidelity (mean, median, p5, p95)
  - Codebook coverage (fraction with fidelity > 0.9)
  - Quantization error distribution
"""

import sys
import numpy as np
import time

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS, PLOTS_DIR)
import matplotlib.pyplot as plt


ENCODERS = [
    ("sentence-transformers/all-MiniLM-L6-v2", "MiniLM-L6 (d=384)"),
    ("sentence-transformers/all-mpnet-base-v2", "MPNet-base (d=768)"),
]


def run(n_samples: int = 10000, K: int = 256):
    print("\n" + "="*60)
    print("  EXPERIMENT 10: Multi-Encoder Fidelity Analysis")
    print("="*60)

    # Load texts once
    print("\n[1/3] Loading texts...")
    texts = load_diverse_texts(n_samples)
    n_samples = len(texts)
    print(f"  {n_samples} texts loaded")

    # Split: 50% train, 50% test
    split = n_samples // 2
    train_texts = texts[:split]
    test_texts = texts[split:]

    results = []
    fidelity_arrays = {}

    for model_name, label in ENCODERS:
        print(f"\n[2/3] Testing encoder: {label}")
        print(f"  Model: {model_name}")

        # Encode
        t0 = time.time()
        encoder = Encoder(model_name)
        d = encoder.d
        print(f"  Dimension: {d}")

        train_emb = encoder.encode(train_texts, batch_size=256, show_progress_bar=True)
        test_emb = encoder.encode(test_texts, batch_size=256, show_progress_bar=True)
        enc_time = time.time() - t0
        print(f"  Encoding time: {enc_time:.1f}s")

        # Train codebook
        train_size = max(K * 10, split // 2)
        train_idx = np.random.choice(split, train_size, replace=False)
        cb = Codebook.train(train_emb[train_idx], K=K)
        qcp = QCP(cb)

        # VQ fidelity on test set
        fidelity = qcp.encoding_fidelity_batch(test_emb)
        codes, qerrs, _, _ = qcp.encode_vq_batch(test_emb)

        # Coverage
        coverage_90 = float(np.mean(fidelity >= 0.9))
        coverage_80 = float(np.mean(fidelity >= 0.8))

        # Codebook utilization
        unique_codes = len(np.unique(codes))
        utilization = unique_codes / K

        r = {
            'encoder': model_name,
            'label': label,
            'dim': d,
            'K': K,
            'n_test': len(test_emb),
            'fidelity_mean': float(np.mean(fidelity)),
            'fidelity_median': float(np.median(fidelity)),
            'fidelity_p5': float(np.percentile(fidelity, 5)),
            'fidelity_p95': float(np.percentile(fidelity, 95)),
            'fidelity_std': float(np.std(fidelity)),
            'qerr_mean': float(np.mean(qerrs)),
            'qerr_median': float(np.median(qerrs)),
            'coverage_90': coverage_90,
            'coverage_80': coverage_80,
            'utilization': utilization,
            'dead_codes': int(K - unique_codes),
            'encoding_time_s': enc_time,
        }
        results.append(r)
        fidelity_arrays[label] = fidelity

        print(f"  Fidelity: mean={r['fidelity_mean']:.4f}  median={r['fidelity_median']:.4f}")
        print(f"  P5={r['fidelity_p5']:.4f}  P95={r['fidelity_p95']:.4f}")
        print(f"  Coverage@90%: {coverage_90:.1%}  Coverage@80%: {coverage_80:.1%}")
        print(f"  qerr: mean={r['qerr_mean']:.4f}  median={r['qerr_median']:.4f}")
        print(f"  Utilization: {utilization:.1%} ({unique_codes}/{K})")

    # ── Plots ──
    print("\n[3/3] Generating plots...")

    # Box plot comparison
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))

    box_data = [fidelity_arrays[label] for _, label in ENCODERS]
    box_labels = [label for _, label in ENCODERS]
    box_colors = [COLORS['qcp'], COLORS['qcp_attn']]

    bp = axes[0].boxplot(box_data, labels=box_labels, patch_artist=True, widths=0.5)
    for patch, color in zip(bp['boxes'], box_colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    axes[0].set_ylabel('Cosine Similarity (Fidelity)')
    axes[0].set_title('VQ Encoding Fidelity by Encoder')

    # Bar chart: metrics comparison
    x = np.arange(len(ENCODERS))
    width = 0.3
    means = [r['fidelity_mean'] for r in results]
    cov90 = [r['coverage_90'] for r in results]
    labels = [r['label'] for r in results]

    bars1 = axes[1].bar(x - width/2, means, width, label='Mean Fidelity',
                        color=COLORS['qcp'], alpha=0.8)
    bars2 = axes[1].bar(x + width/2, cov90, width, label='Coverage@90%',
                        color=COLORS['qcp_attn'], alpha=0.8)

    for bars in [bars1, bars2]:
        for bar in bars:
            h = bar.get_height()
            axes[1].annotate(f'{h:.3f}', xy=(bar.get_x() + bar.get_width()/2, h),
                           xytext=(0, 3), textcoords='offset points',
                           ha='center', va='bottom', fontsize=9)

    axes[1].set_xticks(x)
    axes[1].set_xticklabels(labels)
    axes[1].set_ylabel('Score')
    axes[1].set_title('Fidelity & Coverage Comparison')
    axes[1].legend()
    axes[1].set_ylim(0.7, 1.05)

    fig.suptitle('Experiment 10: Multi-Encoder Fidelity', fontsize=14)
    plt.tight_layout()
    save_plot(fig, 'exp10_multi_encoder')

    # ── Save ──
    # CSV: per-sample fidelity
    csv_rows = []
    for i in range(len(test_texts)):
        row = [i]
        for _, label in ENCODERS:
            row.append(float(fidelity_arrays[label][i]))
        csv_rows.append(row)
    headers = ['sample_id'] + [f'fidelity_{label.replace(" ", "_")}' for _, label in ENCODERS]
    save_csv(csv_rows, headers, 'exp10_multi_encoder_raw')

    summary = {
        'n_samples': n_samples,
        'n_test': len(test_texts),
        'K': K,
        'encoders': results,
        'conclusion': None,
    }

    # Check if results are consistent
    fid_range = max(r['fidelity_mean'] for r in results) - min(r['fidelity_mean'] for r in results)
    if fid_range < 0.05:
        summary['conclusion'] = {
            'verdict': 'ENCODER_AGNOSTIC',
            'fidelity_range': fid_range,
            'narrative': (f"QCP achieves consistent fidelity across encoders "
                         f"(range: {fid_range:.4f}). Results are encoder-agnostic.")
        }
    else:
        best = max(results, key=lambda r: r['fidelity_mean'])
        summary['conclusion'] = {
            'verdict': 'ENCODER_DEPENDENT',
            'fidelity_range': fid_range,
            'best_encoder': best['label'],
            'narrative': (f"Fidelity varies by {fid_range:.4f} across encoders. "
                         f"Best: {best['label']} ({best['fidelity_mean']:.4f}).")
        }

    save_json(summary, 'exp10_multi_encoder_summary')

    # Summary
    print("\n  \U0001f4dd Paper Summary:")
    print(f"  {summary['conclusion']['narrative']}")
    for r in results:
        print(f"    {r['label']}: fid={r['fidelity_mean']:.4f}  "
              f"cov@90={r['coverage_90']:.1%}  util={r['utilization']:.1%}")

    return summary


if __name__ == '__main__':
    run()
