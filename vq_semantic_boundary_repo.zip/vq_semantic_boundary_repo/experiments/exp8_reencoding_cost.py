"""
Experiment 8: Re-Encoding Cost and Quality
=============================================
Measures the computational cost of codebook migration (re-encoding)
and the quality improvement post-migration.
"""

import sys
import time
import numpy as np

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP, compute_retrieval_recall
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS)
import matplotlib.pyplot as plt


def run(max_n: int = 50000):
    print("\n" + "="*60)
    print("  EXPERIMENT 8: Re-Encoding Cost and Quality")
    print("="*60)

    # Migration paths to test
    migrations = [
        (256, 1024),
        (1024, 4096),
    ]
    N_values = [10000, 50000]
    N_values = [n for n in N_values if n <= max_n]

    # --- 1. Load data ---
    print(f"\n[1/3] Loading and encoding data...")
    encoder = Encoder()
    texts = load_diverse_texts(max_n)
    all_embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)

    results = {}

    # --- 2. Run migrations ---
    print("[2/3] Running codebook migrations...")

    for N in N_values:
        embeddings = all_embeddings[:N]
        split = int(N * 0.8)
        corpus_emb = embeddings[:split]
        query_emb = embeddings[split:]
        n_queries = min(100, len(query_emb))
        n_corpus = min(5000, len(corpus_emb))

        for K_old, K_new in migrations:
            if K_new > N // 2:
                continue

            key = f"N{N}_K{K_old}_to_K{K_new}"
            print(f"\n  {key}:")

            # --- Train old codebook ---
            train_size = min(len(corpus_emb), max(K_old * 10, N // 5))
            train_idx = np.random.choice(len(corpus_emb), train_size, replace=False)
            cb_old = Codebook.train(corpus_emb[train_idx], K=K_old)
            qcp_old = QCP(cb_old)

            # Metrics BEFORE migration
            codes_old, qerrs_old, confs_old, deltas_old = qcp_old.encode_vq_batch(corpus_emb)
            fidelity_old = float(np.mean(qcp_old.encoding_fidelity_batch(corpus_emb)))
            mean_qerr_old = float(np.mean(qerrs_old))

            recall_old = compute_retrieval_recall(
                query_emb[:n_queries], corpus_emb[:n_corpus],
                cb_old, k=10, probe_budget=max(2, int(np.sqrt(K_old)))
            )

            # Bucket stats before
            _, counts_old = np.unique(codes_old, return_counts=True)
            bucket_var_old = float(np.var(counts_old))

            print(f"    BEFORE: qerr={mean_qerr_old:.4f}  fidelity={fidelity_old:.4f}  recall@10={recall_old:.3f}")

            # --- Train new codebook ---
            train_size_new = min(len(corpus_emb), max(K_new * 10, N // 5))
            train_idx_new = np.random.choice(len(corpus_emb), train_size_new, replace=False)
            cb_new = Codebook.train(corpus_emb[train_idx_new], K=K_new)
            qcp_new = QCP(cb_new)

            # --- Re-encoding: time it ---
            # CPU timing
            start = time.perf_counter()
            codes_new, qerrs_new, confs_new, deltas_new = qcp_new.encode_vq_batch(corpus_emb)
            cpu_time = time.perf_counter() - start

            # GPU timing (if available)
            gpu_time = None
            try:
                import torch
                if torch.cuda.is_available():
                    corpus_tensor = torch.tensor(corpus_emb, device='cuda')
                    centroids_tensor = torch.tensor(cb_new.centroids, device='cuda')
                    torch.cuda.synchronize()
                    start_gpu = time.perf_counter()
                    # GPU batch distance computation
                    dists = torch.cdist(corpus_tensor, centroids_tensor)
                    codes_gpu = torch.argmin(dists, dim=1)
                    torch.cuda.synchronize()
                    gpu_time = time.perf_counter() - start_gpu
            except Exception:
                pass

            # Metrics AFTER migration
            fidelity_new = float(np.mean(qcp_new.encoding_fidelity_batch(corpus_emb)))
            mean_qerr_new = float(np.mean(qerrs_new))

            recall_new = compute_retrieval_recall(
                query_emb[:n_queries], corpus_emb[:n_corpus],
                cb_new, k=10, probe_budget=max(2, int(np.sqrt(K_new)))
            )

            # Bucket stats after
            _, counts_new = np.unique(codes_new, return_counts=True)
            bucket_var_new = float(np.var(counts_new))

            print(f"    AFTER:  qerr={mean_qerr_new:.4f}  fidelity={fidelity_new:.4f}  recall@10={recall_new:.3f}")
            print(f"    Re-encoding time: CPU={cpu_time:.3f}s" +
                  (f"  GPU={gpu_time:.4f}s" if gpu_time else ""))

            results[key] = {
                'N': N, 'K_old': K_old, 'K_new': K_new,
                'before': {
                    'mean_qerr': mean_qerr_old,
                    'fidelity': fidelity_old,
                    'recall_at_10': recall_old,
                    'bucket_var': bucket_var_old,
                },
                'after': {
                    'mean_qerr': mean_qerr_new,
                    'fidelity': fidelity_new,
                    'recall_at_10': recall_new,
                    'bucket_var': bucket_var_new,
                },
                'qerr_improvement': (mean_qerr_old - mean_qerr_new) / mean_qerr_old,
                'fidelity_improvement': fidelity_new - fidelity_old,
                'recall_improvement': recall_new - recall_old,
                'reencode_time_cpu': cpu_time,
                'reencode_time_gpu': gpu_time,
                'reencode_throughput_cpu': N / cpu_time,
                'reencode_throughput_gpu': N / gpu_time if gpu_time else None,
            }

    # --- 3. Generate outputs ---
    print("\n[3/3] Generating results...\n")

    # Main table
    headers = ["Migration", "N", "CPU Time", "GPU Time", "qerr Δ",
               "Fidelity Δ", "Recall Δ"]
    rows = []
    for key, r in results.items():
        rows.append([
            f"K={r['K_old']}→{r['K_new']}",
            f"{r['N']:,}",
            f"{r['reencode_time_cpu']:.3f}s",
            f"{r['reencode_time_gpu']:.4f}s" if r['reencode_time_gpu'] else "N/A",
            f"{r['qerr_improvement']:+.1%}",
            f"{r['fidelity_improvement']:+.4f}",
            f"{r['recall_improvement']:+.3f}",
        ])
    print_table(headers, rows, "Re-Encoding Cost and Quality Improvement")

    # --- Plots ---
    n_results = len(results)
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # Plot 1: Re-encoding time vs N
    labels = list(results.keys())
    cpu_times = [results[k]['reencode_time_cpu'] for k in labels]
    gpu_times = [results[k]['reencode_time_gpu'] for k in labels]

    x = np.arange(len(labels))
    axes[0, 0].bar(x - 0.15, cpu_times, 0.3, label='CPU', color=COLORS['nl'], alpha=0.7)
    if any(t is not None for t in gpu_times):
        gpu_vals = [t if t is not None else 0 for t in gpu_times]
        axes[0, 0].bar(x + 0.15, gpu_vals, 0.3, label='GPU', color=COLORS['qcp'], alpha=0.7)
    axes[0, 0].set_xticks(x)
    axes[0, 0].set_xticklabels([k.replace('_to_', '→K') for k in labels],
                                 rotation=30, ha='right', fontsize=8)
    axes[0, 0].set_ylabel("Time (seconds)")
    axes[0, 0].set_title("Re-Encoding Wall-Clock Time")
    axes[0, 0].legend()

    # Plot 2: qerr before/after
    befores = [results[k]['before']['mean_qerr'] for k in labels]
    afters = [results[k]['after']['mean_qerr'] for k in labels]
    axes[0, 1].bar(x - 0.15, befores, 0.3, label='Before', color=COLORS['nl'], alpha=0.7)
    axes[0, 1].bar(x + 0.15, afters, 0.3, label='After', color=COLORS['qcp'], alpha=0.7)
    axes[0, 1].set_xticks(x)
    axes[0, 1].set_xticklabels([k.replace('_to_', '→K') for k in labels],
                                 rotation=30, ha='right', fontsize=8)
    axes[0, 1].set_ylabel("Mean qerr")
    axes[0, 1].set_title("Quantization Error: Before vs After Migration")
    axes[0, 1].legend()

    # Plot 3: Fidelity before/after
    fid_before = [results[k]['before']['fidelity'] for k in labels]
    fid_after = [results[k]['after']['fidelity'] for k in labels]
    axes[1, 0].bar(x - 0.15, fid_before, 0.3, label='Before', color=COLORS['nl'], alpha=0.7)
    axes[1, 0].bar(x + 0.15, fid_after, 0.3, label='After', color=COLORS['qcp'], alpha=0.7)
    axes[1, 0].set_xticks(x)
    axes[1, 0].set_xticklabels([k.replace('_to_', '→K') for k in labels],
                                 rotation=30, ha='right', fontsize=8)
    axes[1, 0].set_ylabel("Mean Encoding Fidelity")
    axes[1, 0].set_title("Encoding Fidelity: Before vs After Migration")
    axes[1, 0].legend()

    # Plot 4: Recall before/after
    rec_before = [results[k]['before']['recall_at_10'] for k in labels]
    rec_after = [results[k]['after']['recall_at_10'] for k in labels]
    axes[1, 1].bar(x - 0.15, rec_before, 0.3, label='Before', color=COLORS['nl'], alpha=0.7)
    axes[1, 1].bar(x + 0.15, rec_after, 0.3, label='After', color=COLORS['qcp'], alpha=0.7)
    axes[1, 1].set_xticks(x)
    axes[1, 1].set_xticklabels([k.replace('_to_', '→K') for k in labels],
                                 rotation=30, ha='right', fontsize=8)
    axes[1, 1].set_ylabel("Recall@10")
    axes[1, 1].set_title("Retrieval Quality: Before vs After Migration")
    axes[1, 1].legend()

    fig.suptitle("Experiment 8: Re-Encoding Cost and Quality", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp8_reencoding")

    # Save
    save_json(results, "exp8_reencoding_summary")

    csv_rows = []
    for k, r in results.items():
        csv_rows.append([
            r['N'], r['K_old'], r['K_new'],
            r['reencode_time_cpu'], r['reencode_time_gpu'],
            r['before']['mean_qerr'], r['after']['mean_qerr'],
            r['before']['fidelity'], r['after']['fidelity'],
            r['before']['recall_at_10'], r['after']['recall_at_10'],
        ])
    save_csv(csv_rows,
             ["N", "K_old", "K_new", "time_cpu", "time_gpu",
              "qerr_before", "qerr_after", "fidelity_before", "fidelity_after",
              "recall_before", "recall_after"],
             "exp8_reencoding")

    # Summary
    if results:
        first = list(results.values())[0]
        print(f"\n  📝 Paper Summary:")
        print(f"  Codebook migration (re-encoding) completes in {first['reencode_time_cpu']:.2f}s")
        print(f"  (CPU) for N={first['N']:,}, with qerr improvement of {first['qerr_improvement']:+.1%}")
        print(f"  and fidelity gain of {first['fidelity_improvement']:+.4f}.")
        if first['reencode_time_gpu']:
            print(f"  GPU re-encoding: {first['reencode_time_gpu']:.4f}s "
                  f"({first['reencode_throughput_gpu']:,.0f} nodes/sec).")

    return results


if __name__ == "__main__":
    run()
