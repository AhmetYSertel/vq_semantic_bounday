"""
Experiment 1: Encoding Fidelity
================================
Measures how much semantic information is preserved through QCP encode/decode
compared to natural language paraphrasing.

QCP fidelity: cos(E(s), decode(encode(s)))
NL fidelity:  cos(E(s), E(paraphrase(s)))
"""

import sys
import numpy as np

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS, PLOTS_DIR)
import matplotlib.pyplot as plt


def run(n_samples: int = 10000, K: int = 256):
    print("\n" + "="*60)
    print("  EXPERIMENT 1: Encoding Fidelity")
    print("="*60)

    # --- 1. Load encoder and texts ---
    print("\n[1/4] Loading encoder and texts...")
    encoder = Encoder()
    texts = load_diverse_texts(n_samples)
    n_samples = len(texts)  # actual count

    # --- 2. Encode all texts ---
    print(f"[2/4] Encoding {n_samples} texts...")
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)

    # --- 3. Train codebook and compute QCP fidelity ---
    print(f"[3/4] Training codebook (K={K}) and computing QCP fidelity...")

    # Train on 50% of data for better coverage (10% was too sparse)
    train_size = max(K * 10, n_samples // 2)
    train_idx = np.random.choice(n_samples, train_size, replace=False)
    codebook = Codebook.train(embeddings[train_idx], K=K)
    qcp = QCP(codebook)

    # QCP VQ fidelity: cos(E(s), decode(encode(s)))
    qcp_fidelities = qcp.encoding_fidelity_batch(embeddings)

    # Dual-mode stats
    result = qcp.encode_full_batch(embeddings)
    vq_ratio = result['vq_ratio']
    attn_ratio = result['attn_ratio']

    # Dual-mode fidelity (VQ for high-conf, attention for low-conf)
    dual_fidelities = QCP.cosine_similarity_batch(embeddings, result['decoded'])

    # Per-mode fidelity breakdown
    vq_mask = result['modes'] == 'vq'
    attn_mask = result['modes'] == 'attn'
    
    vq_only_fidelities = qcp_fidelities[vq_mask] if np.any(vq_mask) else np.array([])
    attn_only_fidelities = dual_fidelities[attn_mask] if np.any(attn_mask) else np.array([])

    # --- 4. Analysis and outputs ---
    print("[4/4] Generating results...\n")

    # Statistics
    def compute_stats(arr):
        if len(arr) == 0:
            return {k: 0.0 for k in ['mean','median','std','p5','p95','min','max']}
        return {
            'mean': float(np.mean(arr)),
            'median': float(np.median(arr)),
            'std': float(np.std(arr)),
            'p5': float(np.percentile(arr, 5)),
            'p95': float(np.percentile(arr, 95)),
            'min': float(np.min(arr)),
            'max': float(np.max(arr)),
        }

    qcp_stats = compute_stats(qcp_fidelities)
    dual_stats = compute_stats(dual_fidelities)
    vq_only_stats = compute_stats(vq_only_fidelities)
    attn_only_stats = compute_stats(attn_only_fidelities)

    # Results table
    headers = ["Method", "N", "Mean", "Median", "Std", "P5", "P95"]
    rows = [
        ["QCP VQ (all)", str(n_samples), f"{qcp_stats['mean']:.4f}", f"{qcp_stats['median']:.4f}",
         f"{qcp_stats['std']:.4f}", f"{qcp_stats['p5']:.4f}", f"{qcp_stats['p95']:.4f}"],
        ["QCP Dual-Mode (all)", str(n_samples), f"{dual_stats['mean']:.4f}", f"{dual_stats['median']:.4f}",
         f"{dual_stats['std']:.4f}", f"{dual_stats['p5']:.4f}", f"{dual_stats['p95']:.4f}"],
        ["VQ-only (high conf)", str(int(np.sum(vq_mask))), f"{vq_only_stats['mean']:.4f}", f"{vq_only_stats['median']:.4f}",
         f"{vq_only_stats['std']:.4f}", f"{vq_only_stats['p5']:.4f}", f"{vq_only_stats['p95']:.4f}"],
        ["Attn-only (low conf)", str(int(np.sum(attn_mask))), f"{attn_only_stats['mean']:.4f}", f"{attn_only_stats['median']:.4f}",
         f"{attn_only_stats['std']:.4f}", f"{attn_only_stats['p5']:.4f}", f"{attn_only_stats['p95']:.4f}"],
    ]
    print_table(headers, rows, "Encoding Fidelity (Cosine Similarity)")

    print(f"  Mode split: VQ={vq_ratio:.1%} | Attention={attn_ratio:.1%}")

    # --- Plot 1: Histogram ---
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    
    # Left: VQ fidelity distribution
    bins = np.linspace(0.0, 1.0, 100)
    axes[0].hist(qcp_fidelities, bins=bins, alpha=0.6, color=COLORS['qcp'],
            label=f"QCP VQ (μ={qcp_stats['mean']:.4f}, med={qcp_stats['median']:.4f})", density=True)
    axes[0].axvline(qcp_stats['median'], color=COLORS['qcp'], ls='--', lw=1.5, label=f"Median: {qcp_stats['median']:.4f}")
    axes[0].set_xlabel("Cosine Similarity (Fidelity)")
    axes[0].set_ylabel("Density")
    axes[0].set_title("VQ Argmin Encoding Fidelity")
    axes[0].legend(fontsize=9)

    # Right: Dual-mode fidelity (VQ vs Attention per-mode)
    if len(vq_only_fidelities) > 0:
        axes[1].hist(vq_only_fidelities, bins=bins, alpha=0.5, color=COLORS['qcp'],
                label=f"High-conf VQ (n={int(np.sum(vq_mask))}, μ={vq_only_stats['mean']:.4f})", density=True)
    if len(attn_only_fidelities) > 0:
        axes[1].hist(attn_only_fidelities, bins=bins, alpha=0.5, color=COLORS['qcp_attn'],
                label=f"Low-conf Attention (n={int(np.sum(attn_mask))}, μ={attn_only_stats['mean']:.4f})", density=True)
    axes[1].set_xlabel("Cosine Similarity (Fidelity)")
    axes[1].set_ylabel("Density")
    axes[1].set_title("Dual-Mode Fidelity Breakdown")
    axes[1].legend(fontsize=9)
    
    fig.suptitle("Experiment 1: QCP Encoding Fidelity", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp1_fidelity_histogram")

    # --- Plot 2: Box plot ---
    fig, ax = plt.subplots(figsize=(8, 5))
    box_data = [qcp_fidelities]
    box_labels = ["QCP VQ\n(all inputs)"]
    box_colors = [COLORS['qcp']]
    
    if len(vq_only_fidelities) > 0:
        box_data.append(vq_only_fidelities)
        box_labels.append(f"VQ High-Conf\n(n={int(np.sum(vq_mask))})")
        box_colors.append(COLORS['qcp'])
    if len(attn_only_fidelities) > 0:
        box_data.append(attn_only_fidelities)
        box_labels.append(f"Attn Low-Conf\n(n={int(np.sum(attn_mask))})")
        box_colors.append(COLORS['qcp_attn'])
    box_data.append(dual_fidelities)
    box_labels.append("Dual-Mode\n(combined)")
    box_colors.append(COLORS['accent'])
    
    bp = ax.boxplot(box_data, labels=box_labels, patch_artist=True, widths=0.5)
    for patch, color in zip(bp['boxes'], box_colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.6)
    ax.set_ylabel("Cosine Similarity (Fidelity)")
    ax.set_title("Encoding Fidelity Distribution by Mode")
    save_plot(fig, "exp1_fidelity_boxplot")

    # --- Save data ---
    save_csv(
        [[i, float(qcp_fidelities[i]), float(dual_fidelities[i]), result['modes'][i]]
         for i in range(n_samples)],
        ["sample_id", "qcp_vq_fidelity", "qcp_dual_fidelity", "mode"],
        "exp1_fidelity_raw"
    )

    save_json({
        'n_samples': n_samples,
        'K': K,
        'encoder': encoder.model_name,
        'qcp_vq_all': qcp_stats,
        'qcp_dual_all': dual_stats,
        'vq_only_highconf': vq_only_stats,
        'attn_only_lowconf': attn_only_stats,
        'vq_ratio': vq_ratio,
        'attn_ratio': attn_ratio,
        'n_vq': int(np.sum(vq_mask)),
        'n_attn': int(np.sum(attn_mask)),
    }, "exp1_fidelity_summary")

    # Paper-ready summary
    print("\n  📝 Paper Summary:")
    print(f"  QCP VQ encoding preserves a median cosine similarity of {qcp_stats['median']:.4f}")
    print(f"  across {n_samples:,} diverse inputs (mean={qcp_stats['mean']:.4f}, p5={qcp_stats['p5']:.4f}).")
    print(f"  High-confidence inputs ({vq_ratio:.1%}, VQ mode) achieve {vq_only_stats['mean']:.4f} mean fidelity.")
    print(f"  Low-confidence inputs ({attn_ratio:.1%}, attention mode) achieve {attn_only_stats['mean']:.4f} mean fidelity.")
    print(f"  Combined dual-mode fidelity: mean={dual_stats['mean']:.4f}, median={dual_stats['median']:.4f}.")

    return {
        'qcp_vq': qcp_stats,
        'qcp_dual': dual_stats,
        'vq_only': vq_only_stats,
        'attn_only': attn_only_stats,
    }


if __name__ == "__main__":
    run()
