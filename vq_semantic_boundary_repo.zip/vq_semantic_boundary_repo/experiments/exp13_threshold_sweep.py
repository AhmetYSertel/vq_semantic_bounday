"""
Experiment 13: Threshold Sweep (Pareto Frontier)
==============================================

QCP selects VQ vs Attention mode using two thresholds:
  - alpha: confidence threshold
  - delta_min: margin threshold

This experiment sweeps (alpha, delta_min) and reports the trade-off between:
  - fidelity (cosine)      [quality]
  - escalation rate        [cost]
  - compression ratio      [cost]

The goal is to produce a Pareto-style view suitable for top-tier submissions.

Implementation details:
  - Codebook trained on external diverse corpus.
  - Evaluation messages sampled from a separate diverse split.
  - Wire cost uses the same accounting as Exp11/Exp12.
"""

import sys
import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, ".")

from qcp import Codebook, Encoder, QCP
from utils import load_diverse_texts, save_csv, save_json, save_plot, COLORS


VQ_WIRE_BYTES = 8
ATTN_OVERHEAD_BYTES = 8


def wire_bytes(texts, modes):
    modes = np.array(modes)
    n_vq = int(np.sum(modes == "vq"))
    n_attn = int(np.sum(modes == "attn"))
    attn_idx = np.where(modes == "attn")[0]
    attn_payload = int(sum(len(texts[i].encode("utf-8")) for i in attn_idx))
    return int(n_vq * VQ_WIRE_BYTES + n_attn * ATTN_OVERHEAD_BYTES + attn_payload)


def run(
    K: int = 256,
    n_train: int = 5000,
    n_eval: int = 1500,
    alpha_grid=(0.3, 0.5, 0.7, 0.85),
    delta_grid=(0.0, 0.005, 0.01, 0.02, 0.05),
    seed: int = 42,
):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 13: Threshold Sweep (alpha, delta_min)")
    print("=" * 60)

    rng = np.random.default_rng(seed)
    encoder = Encoder()

    # Train split
    train_texts = load_diverse_texts(n_train)
    train_emb = encoder.encode(train_texts, batch_size=256, show_progress_bar=True)
    cb = Codebook.train(train_emb, K=K)

    # Eval split (separate sample)
    pool = load_diverse_texts(max(8000, n_eval + 2000))
    eval_texts = [pool[i] for i in rng.choice(len(pool), size=n_eval, replace=False)]
    eval_emb = encoder.encode(eval_texts, batch_size=256)

    nl_bytes = int(sum(len(t.encode("utf-8")) for t in eval_texts))

    rows = []
    best = None

    for alpha in alpha_grid:
        for delta_min in delta_grid:
            qcp = QCP(cb, alpha=float(alpha), delta_min=float(delta_min))
            out = qcp.encode_full_batch(eval_emb)
            decoded = out["decoded"]
            fidelity = qcp.cosine_similarity_batch(eval_emb, decoded)
            fid_mean = float(np.mean(fidelity))
            fid_p50 = float(np.median(fidelity))
            esc = float(np.mean(np.array(out["modes"]) == "attn"))
            qcp_bytes = wire_bytes(eval_texts, out["modes"])
            comp = float(nl_bytes / max(1, qcp_bytes))

            # A simple scalar score for recommending a point (paper can present Pareto)
            score = fid_mean - 0.15 * esc  # lightweight regularization on cost
            if best is None or score > best["score"]:
                best = {
                    "alpha": float(alpha),
                    "delta_min": float(delta_min),
                    "fidelity_mean": fid_mean,
                    "fidelity_p50": fid_p50,
                    "escalation": esc,
                    "compression": comp,
                    "qcp_bytes": int(qcp_bytes),
                    "score": float(score),
                }

            rows.append([
                float(alpha), float(delta_min), fid_mean, fid_p50, esc, comp, int(qcp_bytes)
            ])

    # Save CSV
    save_csv(
        rows,
        ["alpha", "delta_min", "fidelity_mean", "fidelity_p50", "escalation_rate", "compression_ratio", "qcp_bytes"],
        "exp13_threshold_sweep"
    )

    summary = {
        "K": int(K),
        "n_train": int(n_train),
        "n_eval": int(n_eval),
        "encoder": encoder.model_name,
        "nl_bytes": int(nl_bytes),
        "alpha_grid": list(map(float, alpha_grid)),
        "delta_grid": list(map(float, delta_grid)),
        "recommended": {k: v for k, v in best.items() if k != "score"},
    }
    save_json(summary, "exp13_threshold_sweep_summary")

    # Plot: escalation vs fidelity, point size by compression
    xs = [r[4] for r in rows]  # escalation
    ys = [r[2] for r in rows]  # fidelity
    sizes = [max(10.0, r[5] * 25.0) for r in rows]  # compression -> size

    fig = plt.figure(figsize=(6.7, 4.8))
    plt.scatter(xs, ys, s=sizes, alpha=0.75)
    plt.xlabel("Escalation rate (attn)")
    plt.ylabel("Mean cosine fidelity")
    plt.title("Threshold Sweep: Cost–Quality Trade-off")
    plt.tight_layout()
    save_plot(fig, "exp13_threshold_sweep")

    print("\nRecommended operating point:")
    print(f"  alpha={best['alpha']}, delta_min={best['delta_min']}")
    print(f"  fidelity_mean={best['fidelity_mean']:.4f}, escalation={best['escalation']:.1%}, compression={best['compression']:.2f}x")

    return summary


if __name__ == "__main__":
    run()
