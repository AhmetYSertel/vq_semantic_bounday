"""
Experiment 18: Latency Decomposition (NEW)
==========================================
Break down end-to-end QCP communication latency into components:
  1. Embedding time (encoder forward pass)
  2. Quantization time (nearest-centroid search)
  3. Serialization time (message construction)
  4. Decode time (table lookup)
  5. Optional: escalation fallback cost

Reports each component separately with variance.
"""

import sys
import time
import struct
import numpy as np
sys.path.insert(0, ".")
from qcp import Codebook, Encoder, QCP, QCPMessage
from utils import load_diverse_texts, save_json, save_plot, print_table, COLORS
import matplotlib.pyplot as plt


def run(n_samples=1000, K=256, n_iters=100, seed=42):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 18: Latency Decomposition")
    print("=" * 60)

    np.random.seed(seed)
    encoder = Encoder()
    texts = load_diverse_texts(n_samples, seed=seed)

    # Pre-encode for quantization benchmarks
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)
    train_idx = np.random.choice(n_samples, min(max(K*4, n_samples//10), n_samples), replace=False)
    codebook = Codebook.train(embeddings[train_idx], K=K, random_state=seed)
    qcp = QCP(codebook)

    results = {}

    # --- 1. Embedding time ---
    print("\n[1/5] Benchmarking embedding time...")
    emb_latencies = []
    sample_texts = texts[:100]
    for _ in range(n_iters):
        t0 = time.perf_counter()
        _ = encoder.encode(sample_texts, batch_size=256)
        emb_latencies.append((time.perf_counter() - t0) / len(sample_texts))
    emb_lat = np.array(emb_latencies) * 1000  # ms
    results['embedding'] = {
        'mean_ms': float(np.mean(emb_lat)),
        'std_ms': float(np.std(emb_lat, ddof=1)),
        'p50_ms': float(np.percentile(emb_lat, 50)),
        'p95_ms': float(np.percentile(emb_lat, 95)),
    }

    # --- 2. Quantization time (VQ argmin) ---
    print("[2/5] Benchmarking quantization time...")
    quant_latencies = []
    batch = embeddings[:100]
    for _ in range(n_iters):
        t0 = time.perf_counter()
        qcp.encode_vq_batch(batch)
        quant_latencies.append((time.perf_counter() - t0) / len(batch))
    quant_lat = np.array(quant_latencies) * 1000
    results['quantization'] = {
        'mean_ms': float(np.mean(quant_lat)),
        'std_ms': float(np.std(quant_lat, ddof=1)),
        'p50_ms': float(np.percentile(quant_lat, 50)),
        'p95_ms': float(np.percentile(quant_lat, 95)),
    }

    # --- 3. Serialization time ---
    print("[3/5] Benchmarking serialization time...")
    codes, qerrs, confs, deltas = qcp.encode_vq_batch(batch)
    ser_latencies = []
    for _ in range(n_iters):
        t0 = time.perf_counter()
        for j in range(len(batch)):
            # Simulate message serialization
            msg_bytes = struct.pack('BfffQQ',
                int(codes[j]), float(qerrs[j]), float(confs[j]), float(deltas[j]),
                0, int(time.time()))
        ser_latencies.append((time.perf_counter() - t0) / len(batch))
    ser_lat = np.array(ser_latencies) * 1000
    results['serialization'] = {
        'mean_ms': float(np.mean(ser_lat)),
        'std_ms': float(np.std(ser_lat, ddof=1)),
        'p50_ms': float(np.percentile(ser_lat, 50)),
        'p95_ms': float(np.percentile(ser_lat, 95)),
    }

    # --- 4. Decode time ---
    print("[4/5] Benchmarking decode time...")
    decode_latencies = []
    for _ in range(n_iters):
        t0 = time.perf_counter()
        codebook.decode_batch(codes)
        decode_latencies.append((time.perf_counter() - t0) / len(codes))
    dec_lat = np.array(decode_latencies) * 1000
    results['decode'] = {
        'mean_ms': float(np.mean(dec_lat)),
        'std_ms': float(np.std(dec_lat, ddof=1)),
        'p50_ms': float(np.percentile(dec_lat, 50)),
        'p95_ms': float(np.percentile(dec_lat, 95)),
    }

    # --- 5. Attention mode (escalation) cost ---
    print("[5/5] Benchmarking attention mode cost...")
    attn_latencies = []
    for _ in range(min(n_iters, 50)):
        t0 = time.perf_counter()
        qcp.encode_attention_batch(batch)
        attn_latencies.append((time.perf_counter() - t0) / len(batch))
    attn_lat = np.array(attn_latencies) * 1000
    results['attention_mode'] = {
        'mean_ms': float(np.mean(attn_lat)),
        'std_ms': float(np.std(attn_lat, ddof=1)),
        'p50_ms': float(np.percentile(attn_lat, 50)),
        'p95_ms': float(np.percentile(attn_lat, 95)),
    }

    # --- Total ---
    total_vq = (results['embedding']['mean_ms'] + results['quantization']['mean_ms'] +
                results['serialization']['mean_ms'] + results['decode']['mean_ms'])
    total_attn = (results['embedding']['mean_ms'] + results['attention_mode']['mean_ms'] +
                  results['serialization']['mean_ms'] + results['decode']['mean_ms'])

    results['total_vq_ms'] = total_vq
    results['total_attn_ms'] = total_attn

    # Print
    headers = ["Component", "Mean (ms)", "Std (ms)", "P50 (ms)", "P95 (ms)", "% of VQ Total"]
    rows = [
        ["Embedding", f"{results['embedding']['mean_ms']:.4f}",
         f"{results['embedding']['std_ms']:.4f}",
         f"{results['embedding']['p50_ms']:.4f}",
         f"{results['embedding']['p95_ms']:.4f}",
         f"{results['embedding']['mean_ms']/total_vq*100:.1f}%"],
        ["Quantization (VQ)", f"{results['quantization']['mean_ms']:.4f}",
         f"{results['quantization']['std_ms']:.4f}",
         f"{results['quantization']['p50_ms']:.4f}",
         f"{results['quantization']['p95_ms']:.4f}",
         f"{results['quantization']['mean_ms']/total_vq*100:.1f}%"],
        ["Serialization", f"{results['serialization']['mean_ms']:.4f}",
         f"{results['serialization']['std_ms']:.4f}",
         f"{results['serialization']['p50_ms']:.4f}",
         f"{results['serialization']['p95_ms']:.4f}",
         f"{results['serialization']['mean_ms']/total_vq*100:.1f}%"],
        ["Decode", f"{results['decode']['mean_ms']:.4f}",
         f"{results['decode']['std_ms']:.4f}",
         f"{results['decode']['p50_ms']:.4f}",
         f"{results['decode']['p95_ms']:.4f}",
         f"{results['decode']['mean_ms']/total_vq*100:.1f}%"],
        ["Total (VQ path)", f"{total_vq:.4f}", "", "", "", "100%"],
        ["", "", "", "", "", ""],
        ["Attention mode*", f"{results['attention_mode']['mean_ms']:.4f}",
         f"{results['attention_mode']['std_ms']:.4f}",
         f"{results['attention_mode']['p50_ms']:.4f}",
         f"{results['attention_mode']['p95_ms']:.4f}", ""],
        ["Total (Attn path)", f"{total_attn:.4f}", "", "", "", ""],
    ]
    print_table(headers, rows, "Latency Decomposition (per message)")
    print("  * Attention mode replaces Quantization step for low-confidence inputs\n")

    save_json({'seed': seed, 'K': K, 'n_samples': n_samples, 'n_iters': n_iters,
               'components': results}, "exp18_latency_decomposition")

    # Plot stacked bar
    fig, ax = plt.subplots(figsize=(10, 6))
    components = ['Embedding', 'Quantization', 'Serialization', 'Decode']
    vq_vals = [results['embedding']['mean_ms'], results['quantization']['mean_ms'],
               results['serialization']['mean_ms'], results['decode']['mean_ms']]
    attn_vals = [results['embedding']['mean_ms'], results['attention_mode']['mean_ms'],
                 results['serialization']['mean_ms'], results['decode']['mean_ms']]

    x = np.arange(2)
    bottom_vq = np.zeros(2)
    comp_colors = ['#3B82F6', '#8B5CF6', '#F59E0B', '#10B981']

    for i, (comp, cv, ca, cc) in enumerate(zip(components, vq_vals, attn_vals, comp_colors)):
        ax.bar(x, [cv, ca], bottom=bottom_vq, label=comp, color=cc, alpha=0.8, width=0.5)
        bottom_vq += np.array([cv, ca])

    ax.set_xticks(x)
    ax.set_xticklabels(['VQ Path', 'Attention Path'])
    ax.set_ylabel('Latency per message (ms)')
    ax.set_title('Experiment 18: Latency Decomposition')
    ax.legend()
    plt.tight_layout()
    save_plot(fig, "exp18_latency_decomposition")

    return results


if __name__ == "__main__":
    run()
