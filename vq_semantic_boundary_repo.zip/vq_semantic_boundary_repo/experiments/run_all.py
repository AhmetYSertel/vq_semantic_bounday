"""
Run All QCP Experiments (v2)
============================
Usage:
  cd qcp_experiments_v2
  python experiments/run_all.py              # Run all
  python experiments/run_all.py --new-only   # Only new (16-20)
  python experiments/run_all.py --exp 1 4 16 # Specific ones
  python experiments/run_all.py --multi-seed # Key exps with 5 seeds

Environment:
  OPENAI_API_KEY=your-key  (for exp4 GPT-5-mini baseline)
"""

import sys
import os
import argparse

# Fix import paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
for p in [PROJECT_ROOT, SCRIPT_DIR]:
    if p not in sys.path:
        sys.path.insert(0, p)
os.chdir(PROJECT_ROOT)

MODULE_MAP = {
    1: 'exp1_encoding_fidelity',
    2: 'exp2_bandwidth_reduction',
    3: 'exp3_codebook_coverage',
    4: 'exp4_encoding_throughput',
    5: 'exp5_cache_hit_rate',
    6: 'exp6_k_sweep',
    7: 'exp7_adaptive_probe',
    8: 'exp8_reencoding_cost',
    9: 'exp9_pca_analysis',
    10: 'exp10_multi_encoder',
    11: 'exp11_pipeline_cost',
    12: 'exp12_end_to_end_cost',
    13: 'exp13_threshold_sweep',
    14: 'exp14_adversarial_semantic_perturbation',
    15: 'exp15_codebook_mismatch',
    16: 'exp16_downstream_task_validation',
    17: 'exp17_baseline_comparison',
    18: 'exp18_latency_decomposition',
    19: 'exp19_negation_frequency',
    20: 'exp20_multi_code_evaluation',
}


def run_experiment(exp_num):
    if exp_num not in MODULE_MAP:
        print(f"  Unknown experiment: {exp_num}")
        return None

    name = MODULE_MAP[exp_num]
    print(f"\n{'#'*60}")
    print(f"  Running Experiment {exp_num}: {name}")
    print(f"{'#'*60}")

    try:
        # Direct import — experiments dir is in sys.path
        module = __import__(name, fromlist=['run'])
        result = module.run()
        print(f"\n  Experiment {exp_num} complete.")
        return result
    except Exception as e:
        print(f"\n  Experiment {exp_num} FAILED: {e}")
        import traceback
        traceback.print_exc()
        return None


def run_multi_seed(exp_num, seeds=[42, 123, 456, 789, 1024]):
    from utils import multi_seed_run
    multi_seed_exps = {1, 14, 16, 17}
    if exp_num not in multi_seed_exps:
        print(f"  Multi-seed not configured for experiment {exp_num}")
        return run_experiment(exp_num)
    name = MODULE_MAP[exp_num]
    module = __import__(name, fromlist=['run'])
    return multi_seed_run(module.run, seeds=seeds)


def main():
    parser = argparse.ArgumentParser(description="Run QCP experiments (v2)")
    parser.add_argument('--exp', nargs='+', type=int, help='Specific experiments to run')
    parser.add_argument('--multi-seed', action='store_true', help='Run with 5 seeds')
    parser.add_argument('--new-only', action='store_true', help='Run only new experiments (16-20)')
    parser.add_argument('--all', action='store_true', help='Run all 20 experiments')
    args = parser.parse_args()

    if args.exp:
        experiments = args.exp
    elif args.new_only:
        experiments = [16, 17, 18, 19, 20]
    elif args.all:
        experiments = list(range(1, 21))
    else:
        experiments = list(range(1, 21))

    print("=" * 60)
    print(f"  QCP Experiment Suite v2")
    print(f"  Working dir: {os.getcwd()}")
    print(f"  sys.path includes: {SCRIPT_DIR}")
    print(f"  Experiments to run: {experiments}")
    print(f"  Multi-seed: {args.multi_seed}")
    print("=" * 60)

    results = {}
    for exp_num in experiments:
        if args.multi_seed and exp_num in {1, 14, 16, 17}:
            results[exp_num] = run_multi_seed(exp_num)
        else:
            results[exp_num] = run_experiment(exp_num)

    print("\n" + "=" * 60)
    print("  ALL EXPERIMENTS COMPLETE")
    print("=" * 60)
    for exp_num in experiments:
        status = "OK" if results.get(exp_num) is not None else "FAILED"
        print(f"  Experiment {exp_num:2d}: {status}")

    return results


if __name__ == "__main__":
    main()
