"""
Experiment 15: Codebook Mismatch Robustness
==========================================

Distributed settings require sender/receiver codebook compatibility.
This experiment quantifies the damage when a receiver decodes codes with
the *wrong* codebook (e.g., different K or different training seed).

We simulate:
  - Sender codebook A (K_A)
  - Receiver codebook B (K_B or different version)

Sender encodes texts to codes using A, receiver decodes codes using B and we
measure cosine fidelity to the original embedding.

This supports the paper's requirement for explicit codebook versioning and
negotiation (meta fields / handshake).
"""

import sys
import numpy as np

sys.path.insert(0, ".")

from qcp import Codebook, Encoder, QCP
from utils import load_diverse_texts, save_json


def run(
    K_sender: int = 256,
    K_receiver: int = 256,
    n_train: int = 5000,
    n_eval: int = 2000,
    seed_sender: int = 42,
    seed_receiver: int = 777,
):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 15: Codebook Mismatch")
    print("=" * 60)

    encoder = Encoder()

    # Training corpora (same distribution, different seeds for variation)
    pool = load_diverse_texts(max(12000, n_train + n_eval + 2000))
    rng_s = np.random.default_rng(seed_sender)
    rng_r = np.random.default_rng(seed_receiver)

    train_s = [pool[i] for i in rng_s.choice(len(pool), size=n_train, replace=False)]
    train_r = [pool[i] for i in rng_r.choice(len(pool), size=n_train, replace=False)]

    emb_s = encoder.encode(train_s, batch_size=256, show_progress_bar=True)
    emb_r = encoder.encode(train_r, batch_size=256, show_progress_bar=True)

    cb_s = Codebook.train(emb_s, K=K_sender, random_state=int(seed_sender))
    cb_r = Codebook.train(emb_r, K=K_receiver, random_state=int(seed_receiver))

    qcp_sender = QCP(cb_s)

    # Eval set (fresh)
    eval_texts = [pool[i] for i in rng_s.choice(len(pool), size=n_eval, replace=False)]
    eval_emb = encoder.encode(eval_texts, batch_size=256)

    # Sender encodes (codes)
    codes, qerrs, confs, deltas = qcp_sender.encode_vq_batch(eval_emb)

    # Receiver decodes with (potentially wrong) codebook
    # If K differs, codes out of range would crash: clamp for simulation (shows why versioning matters)
    max_code = cb_r.K - 1
    clamped_codes = np.clip(codes, 0, max_code)
    decoded_wrong = cb_r.decode_batch(clamped_codes)

    # Baseline: correct decode with sender codebook
    decoded_right = cb_s.decode_batch(codes)

    fid_right = qcp_sender.cosine_similarity_batch(eval_emb, decoded_right)
    fid_wrong = qcp_sender.cosine_similarity_batch(eval_emb, decoded_wrong)

    summary = {
        "encoder": encoder.model_name,
        "sender": {
            "K": int(K_sender),
            "codebook_version": cb_s.get_version(),
            "seed": int(seed_sender),
        },
        "receiver": {
            "K": int(K_receiver),
            "codebook_version": cb_r.get_version(),
            "seed": int(seed_receiver),
            "clamp_applied": bool(K_sender != K_receiver),
        },
        "n_eval": int(n_eval),
        "fidelity": {
            "matched_mean": float(np.mean(fid_right)),
            "matched_p50": float(np.median(fid_right)),
            "mismatch_mean": float(np.mean(fid_wrong)),
            "mismatch_p50": float(np.median(fid_wrong)),
            "drop_mean": float(np.mean(fid_right) - np.mean(fid_wrong)),
        },
        "notes": {
            "interpretation": "A large fidelity drop under mismatch motivates explicit codebook versioning/handshake.",
        },
    }

    save_json(summary, "exp15_codebook_mismatch_summary")

    print("\nFidelity:")
    print(f"  matched:  mean={summary['fidelity']['matched_mean']:.4f}  p50={summary['fidelity']['matched_p50']:.4f}")
    print(f"  mismatch: mean={summary['fidelity']['mismatch_mean']:.4f}  p50={summary['fidelity']['mismatch_p50']:.4f}")
    print(f"  drop_mean={summary['fidelity']['drop_mean']:.4f}")

    return summary


if __name__ == "__main__":
    run()
