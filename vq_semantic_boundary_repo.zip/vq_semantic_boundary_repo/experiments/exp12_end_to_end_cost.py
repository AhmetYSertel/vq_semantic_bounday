"""
Experiment 12: End-to-End Agent Cost Simulation
==============================================
Goal
----
Quantify *system-level* cost reduction when QCP is used as the inter-module
communication protocol inside a simple multi-hop agent pipeline.

We simulate a 3-stage pipeline (A -> B -> C) where each stage sends a message
to the next stage. The payloads are natural language task/status/control
messages sampled from a diverse corpus.

We report:
  - total bytes (NL vs QCP wire model)
  - estimated tokens (NL vs QCP)
  - escalation rate (attention fallback rate)
  - breakdown by hop count

Notes
-----
This is a *cost* simulation, not a quality benchmark. Correctness is addressed
by Exp11 (pipeline paraphrase invariance) and other fidelity experiments.
"""

import sys
import numpy as np

sys.path.insert(0, ".")

from qcp import Codebook, Encoder, QCP
from utils import load_diverse_texts, save_json, save_plot, COLORS
import matplotlib.pyplot as plt


# Wire-level byte model (protocol accounting)
VQ_WIRE_BYTES = 8
ATTN_OVERHEAD_BYTES = 8


def estimate_tokens(text: str) -> int:
    """Very rough token estimate (compatible with the rest of the repo)."""
    return len(text) // 4 + 1


def compute_wire_bytes(texts, modes) -> int:
    modes = np.array(modes)
    n_vq = int(np.sum(modes == "vq"))
    n_attn = int(np.sum(modes == "attn"))
    attn_idx = np.where(modes == "attn")[0]
    attn_payload = int(sum(len(texts[i].encode("utf-8")) for i in attn_idx))
    return int(n_vq * VQ_WIRE_BYTES + n_attn * ATTN_OVERHEAD_BYTES + attn_payload)


def run(K: int = 256, n_messages: int = 1000, hops: int = 2, seed: int = 42):
    """Simulate multi-hop agent pipeline traffic."""
    print("\n" + "=" * 60)
    print("  EXPERIMENT 12: End-to-End Agent Cost Simulation")
    print("=" * 60)

    rng = np.random.default_rng(seed)

    # 1) Train codebook on an external diverse corpus
    print("\n[1/4] Initializing encoder and training codebook...")
    encoder = Encoder()
    train_texts = load_diverse_texts(5000)
    train_emb = encoder.encode(train_texts, batch_size=256, show_progress_bar=True)
    cb = Codebook.train(train_emb, K=K)
    qcp = QCP(cb)

    # 2) Sample message payloads (the traffic)
    print("\n[2/4] Sampling pipeline payloads...")
    traffic = load_diverse_texts(max(n_messages, 2000))
    traffic = [traffic[i] for i in rng.choice(len(traffic), size=n_messages, replace=False)]

    nl_bytes_1hop = int(sum(len(t.encode("utf-8")) for t in traffic))
    nl_tokens_1hop = int(sum(estimate_tokens(t) for t in traffic))

    # 3) Encode with QCP (mode selection per sample)
    print("\n[3/4] Encoding payloads and computing wire cost...")
    emb = encoder.encode(traffic, batch_size=256)
    full = qcp.encode_full_batch(emb)
    modes = full["modes"]
    qcp_bytes_1hop = compute_wire_bytes(traffic, modes)
    escalation_rate = float(np.mean(np.array(modes) == "attn"))

    # Multi-hop totals (assume identical distribution per hop)
    nl_bytes_total = nl_bytes_1hop * hops
    nl_tokens_total = nl_tokens_1hop * hops
    qcp_bytes_total = qcp_bytes_1hop * hops

    compression_1hop = float(nl_bytes_1hop / max(1, qcp_bytes_1hop))
    compression_total = float(nl_bytes_total / max(1, qcp_bytes_total))

    summary = {
        "K": int(K),
        "n_messages": int(n_messages),
        "hops": int(hops),
        "encoder": encoder.model_name,
        "nl": {
            "bytes_1hop": nl_bytes_1hop,
            "tokens_1hop": nl_tokens_1hop,
            "bytes_total": nl_bytes_total,
            "tokens_total": nl_tokens_total,
        },
        "qcp": {
            "bytes_1hop": qcp_bytes_1hop,
            "bytes_total": qcp_bytes_total,
            "vq_ratio": float(full.get("vq_ratio", 1.0 - escalation_rate)),
            "attn_ratio": float(full.get("attn_ratio", escalation_rate)),
            "escalation_rate": escalation_rate,
        },
        "compression": {
            "ratio_1hop": compression_1hop,
            "ratio_total": compression_total,
        },
    }

    print("\nSummary:")
    print(f"  1-hop: NL={nl_bytes_1hop}B -> QCP={qcp_bytes_1hop}B | compression={compression_1hop:.2f}x")
    print(f"  {hops}-hop: NL={nl_bytes_total}B -> QCP={qcp_bytes_total}B | compression={compression_total:.2f}x")
    print(f"  escalation_rate={escalation_rate:.1%}")

    # Plot: bytes by hop
    print("\n[4/4] Plotting...")
    xs = np.arange(1, hops + 1)
    nl_curve = [nl_bytes_1hop * h for h in xs]
    qcp_curve = [qcp_bytes_1hop * h for h in xs]

    fig = plt.figure(figsize=(6.5, 4.5))
    plt.plot(xs, nl_curve, marker="o", label="Natural Language")
    plt.plot(xs, qcp_curve, marker="o", label="QCP (wire)")
    plt.xlabel("Pipeline hops")
    plt.ylabel("Total bytes")
    plt.title("End-to-End Communication Cost")
    plt.legend()
    plt.tight_layout()
    save_plot(fig, "exp12_end_to_end_cost")

    save_json(summary, "exp12_end_to_end_cost_summary")
    return summary


if __name__ == "__main__":
    run()
