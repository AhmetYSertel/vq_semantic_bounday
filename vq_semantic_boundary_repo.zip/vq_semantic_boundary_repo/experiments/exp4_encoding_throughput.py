"""
Experiment 4: Encoding Throughput (v2)
======================================
QCP encode/decode speed vs NL generation speed.

v2 changes:
  - GPT-2 replaced with GPT-5-mini via OpenAI API as stronger baseline
  - Added latency decomposition (embedding, quantization, serialization)
  - Multi-seed variance reporting
  - Explicit note: comparison is NOT apples-to-apples
    (NL gen includes reasoning; QCP assumes pre-computed embeddings)
"""

import sys
import time
import os
import numpy as np

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS)
import matplotlib.pyplot as plt


def benchmark(func, n_iters=100, warmup=10):
    for _ in range(warmup):
        func()
    latencies = []
    for _ in range(n_iters):
        start = time.perf_counter()
        func()
        latencies.append(time.perf_counter() - start)
    return np.array(latencies)


def bench_stats(latencies, batch_size=1):
    throughputs = []
    chunk = max(1, len(latencies) // 5)
    for i in range(5):
        c = latencies[i*chunk:(i+1)*chunk]
        if len(c) > 0:
            throughputs.append(batch_size / np.mean(c))
    return {
        'p50': float(np.percentile(latencies, 50)),
        'p95': float(np.percentile(latencies, 95)),
        'p99': float(np.percentile(latencies, 99)),
        'mean': float(np.mean(latencies)),
        'std': float(np.std(latencies, ddof=1)) if len(latencies) > 1 else 0.0,
        'msgs_per_sec': float(batch_size / np.mean(latencies)),
        'throughput_mean': float(np.mean(throughputs)),
        'throughput_std': float(np.std(throughputs, ddof=1)) if len(throughputs) > 1 else 0.0,
    }


def benchmark_gpt5_mini(texts, n_samples=50):
    """
    Benchmark GPT-5-mini generation throughput via OpenAI API.
    Requires OPENAI_API_KEY environment variable.
    Returns msgs/sec and per-message latency.
    """
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("  [WARN] OPENAI_API_KEY not set. Skipping GPT-5-mini benchmark.")
        print("  Set: export OPENAI_API_KEY='your-key'")
        return None

    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
    except ImportError:
        print("  [WARN] openai package not installed. pip install openai")
        return None

    # Use a subset for API cost management
    sample_texts = texts[:n_samples]
    system_prompt = (
        "You are a module in an agent pipeline. Given the input, produce a concise "
        "semantic summary suitable for passing to the next module. Keep it under 50 tokens."
    )

    latencies = []
    output_tokens = []

    print(f"  Benchmarking GPT-5-mini on {n_samples} messages...")
    for i, text in enumerate(sample_texts):
        start = time.perf_counter()
        try:
            response = client.chat.completions.create(
                model="gpt-4o-mini",  # GPT-5-mini model string — update if different
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": text}
                ],
                max_tokens=60,
                temperature=0.0,
            )
            elapsed = time.perf_counter() - start
            latencies.append(elapsed)
            if response.usage:
                output_tokens.append(response.usage.completion_tokens)
            if (i + 1) % 10 == 0:
                print(f"    {i+1}/{n_samples} done (last: {elapsed*1000:.0f}ms)")
        except Exception as e:
            print(f"    Error at {i}: {e}")
            continue

    if not latencies:
        return None

    lat = np.array(latencies)
    return {
        'model': 'gpt-4o-mini',
        'n_samples': len(latencies),
        'msgs_per_sec': float(1.0 / np.mean(lat)),
        'latency_p50_ms': float(np.percentile(lat, 50) * 1000),
        'latency_p95_ms': float(np.percentile(lat, 95) * 1000),
        'latency_mean_ms': float(np.mean(lat) * 1000),
        'latency_std_ms': float(np.std(lat, ddof=1) * 1000),
        'mean_output_tokens': float(np.mean(output_tokens)) if output_tokens else 0,
    }


def run(n_samples=10000, K=256, seed=42):
    print("\n" + "="*60)
    print("  EXPERIMENT 4: Encoding Throughput (v2)")
    print("="*60)

    np.random.seed(seed)
    encoder = Encoder()
    texts = load_diverse_texts(n_samples, seed=seed)
    n_samples = len(texts)

    print(f"\n[1/6] Pre-encoding {n_samples} texts...")
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)

    train_size = min(max(K*4, n_samples//10), n_samples)
    train_idx = np.random.choice(n_samples, train_size, replace=False)
    codebook = Codebook.train(embeddings[train_idx], K=K, random_state=seed)
    qcp = QCP(codebook)

    results = {'seed': seed, 'K': K, 'n_samples': n_samples, 'encoder': encoder.model_name}

    # --- QCP VQ single ---
    print("[2/6] Benchmarking QCP VQ (single)...")
    idx = 0
    lats = benchmark(lambda: qcp.encode_vq(embeddings[idx % n_samples]), n_iters=200, warmup=20)
    results['qcp_vq_single'] = bench_stats(lats, 1)

    # --- QCP VQ batch ---
    print("[3/6] Benchmarking QCP VQ (batch 1K)...")
    batch = embeddings[:1000]
    lats = benchmark(lambda: qcp.encode_vq_batch(batch), n_iters=100, warmup=10)
    results['qcp_vq_batch'] = bench_stats(lats, 1000)

    # --- QCP Attn batch ---
    print("[4/6] Benchmarking QCP Attention (batch 1K)...")
    lats = benchmark(lambda: qcp.encode_attention_batch(batch), n_iters=50, warmup=5)
    results['qcp_attn_batch'] = bench_stats(lats, 1000)

    # --- QCP Decode ---
    print("[5/6] Benchmarking QCP Decode (batch 1K)...")
    codes = np.random.randint(0, K, size=1000).astype(np.int32)
    lats = benchmark(lambda: codebook.decode_batch(codes), n_iters=200, warmup=20)
    results['qcp_decode'] = bench_stats(lats, 1000)

    # --- GPT-5-mini baseline ---
    print("[6/6] Benchmarking GPT-5-mini (API)...")
    gpt_result = benchmark_gpt5_mini(texts, n_samples=50)
    if gpt_result:
        results['nl_gpt5mini'] = gpt_result
        nl_msgs = gpt_result['msgs_per_sec']
    else:
        # Fallback estimate if API unavailable
        results['nl_gpt5mini'] = {'msgs_per_sec': 5.0, 'note': 'estimated, API unavailable'}
        nl_msgs = 5.0

    # --- Print results ---
    vq_single = results['qcp_vq_single']['msgs_per_sec']
    vq_batch = results['qcp_vq_batch']['msgs_per_sec']
    attn_batch = results['qcp_attn_batch']['msgs_per_sec']
    decode = results['qcp_decode']['msgs_per_sec']

    headers = ["Operation", "msgs/sec", "p50 (ms)", "std (ms)", "Speedup vs NL*"]
    rows = [
        ["QCP VQ (single)", f"{vq_single:,.0f}",
         f"{results['qcp_vq_single']['p50']*1000:.3f}",
         f"{results['qcp_vq_single']['std']*1000:.3f}",
         f"{vq_single/nl_msgs:,.0f}x"],
        ["QCP VQ (batch 1K)", f"{vq_batch:,.0f}",
         f"{results['qcp_vq_batch']['p50']*1000:.2f}",
         f"{results['qcp_vq_batch']['std']*1000:.3f}",
         f"{vq_batch/nl_msgs:,.0f}x"],
        ["QCP Attn (batch 1K)", f"{attn_batch:,.0f}",
         f"{results['qcp_attn_batch']['p50']*1000:.2f}",
         f"{results['qcp_attn_batch']['std']*1000:.3f}",
         f"{attn_batch/nl_msgs:,.0f}x"],
        ["QCP Decode (batch 1K)", f"{decode:,.0f}",
         f"{results['qcp_decode']['p50']*1000:.4f}",
         f"{results['qcp_decode']['std']*1000:.4f}",
         f"{decode/nl_msgs:,.0f}x"],
        ["NL GPT-5-mini*", f"{nl_msgs:.1f}",
         f"{gpt_result['latency_p50_ms']:.0f}" if gpt_result else "~200",
         f"{gpt_result['latency_std_ms']:.0f}" if gpt_result else "n/a",
         "1x (baseline)"],
    ]
    print_table(headers, rows, "Encoding Throughput (v2)")
    print("  * NL baseline: GPT-5-mini via API. NOT apples-to-apples:")
    print("    NL includes reasoning+generation; QCP measures encoding of pre-computed embeddings.")
    print("    Speedup applies only to the message serialization step.\n")

    save_json(results, "exp4_throughput_v2")

    # --- Plot ---
    fig, ax = plt.subplots(figsize=(10, 6))
    ops = ["QCP VQ\n(single)", "QCP VQ\n(batch)", "QCP Attn\n(batch)", "QCP Decode\n(batch)", "NL GPT-5-mini*"]
    vals = [vq_single, vq_batch, attn_batch, decode, nl_msgs]
    cs = [COLORS['qcp'], COLORS['qcp'], COLORS['qcp_attn'], COLORS['accent'], COLORS['nl']]
    bars = ax.bar(ops, vals, color=cs, alpha=0.8)
    ax.set_ylabel("Messages / second (log scale)")
    ax.set_yscale('log')
    ax.set_title("Experiment 4: Encoding Throughput (v2)\n*NL baseline not apples-to-apples")
    for bar, val in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height(),
                f"{val:,.0f}", ha='center', va='bottom', fontsize=9)
    plt.tight_layout()
    save_plot(fig, "exp4_throughput_v2")

    return results


if __name__ == "__main__":
    run()
