"""
Experiment 17: Baseline Comparison (NEW — P0)
=============================================
Compare QCP against proper baselines:
  1. Raw embedding passing (d*4 bytes, zero loss)
  2. Product Quantization (PQ) simulation
  3. Structured JSON label passing
  4. QCP VQ (37 bytes)
  5. QCP Dual-mode

Metrics: fidelity, bandwidth, throughput, routing accuracy
"""

import sys
import time
import struct
import json
import numpy as np
sys.path.insert(0, ".")
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_json, save_csv, save_plot,
                   print_table, COLORS)
import matplotlib.pyplot as plt


def train_pq(train_embeddings, m=8, k_sub=256, seed=42):
    """Train Product Quantization codebooks on TRAIN embeddings (to avoid eval leakage)."""
    from sklearn.cluster import MiniBatchKMeans
    np.random.seed(seed)
    N, d = train_embeddings.shape
    sub_dim = d // m
    kmeans_list = []
    for i in range(m):
        sub_emb = train_embeddings[:, i*sub_dim:(i+1)*sub_dim]
        km = MiniBatchKMeans(n_clusters=k_sub, random_state=seed, n_init=1, max_iter=200, batch_size=4096)
        km.fit(sub_emb)
        kmeans_list.append(km)
    return kmeans_list

def apply_pq(kmeans_list, embeddings):
    """Encode+reconstruct embeddings using trained PQ codebooks."""
    embeddings = embeddings.astype(np.float32)
    N, d = embeddings.shape
    m = len(kmeans_list)
    sub_dim = d // m
    reconstructed = np.zeros_like(embeddings)
    codes_all = np.zeros((N, m), dtype=np.uint8)
    for i, km in enumerate(kmeans_list):
        sub_emb = embeddings[:, i*sub_dim:(i+1)*sub_dim]
        codes = km.predict(sub_emb).astype(np.int32)
        codes_all[:, i] = codes.astype(np.uint8)
        reconstructed[:, i*sub_dim:(i+1)*sub_dim] = km.cluster_centers_[codes].astype(np.float32)
    byte_cost = m * 1  # 1 byte per subquantizer when k_sub=256
    return reconstructed, byte_cost, codes_all


def simulate_json_label(embeddings, handler_centroids, handler_names):
    """
    Simulate structured JSON label passing:
    Route to nearest handler, transmit handler name as JSON.
    """
    e_norm = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    h_norm = handler_centroids / np.linalg.norm(handler_centroids, axis=1, keepdims=True)
    sims = e_norm @ h_norm.T
    labels = [handler_names[i] for i in np.argmax(sims, axis=1)]
    # JSON message: {"handler": "name", "conf": 0.95}
    avg_json_bytes = np.mean([len(json.dumps({"handler": l, "conf": 0.95})) for l in labels])
    return labels, avg_json_bytes


def run(n_samples=10000, K=256, seed=42):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 17: Baseline Comparison")
    print("=" * 60)

    np.random.seed(seed)
    encoder = Encoder()
    texts = load_diverse_texts(n_samples, seed=seed)
    embeddings = encoder.encode(texts, batch_size=256, show_progress_bar=True)
    d = embeddings.shape[1]

    # Split train/eval
    split = n_samples // 2
    train_emb, eval_emb = embeddings[:split], embeddings[split:]

    # Train QCP codebook
    codebook = Codebook.train(train_emb, K=K, random_state=seed)
    qcp = QCP(codebook)

    # Simple handler centroids for routing test
    n_handlers = 10
    handler_centroids = train_emb[:n_handlers*5].reshape(n_handlers, 5, d).mean(axis=1)
    handler_names = [f"handler_{i}" for i in range(n_handlers)]

    results = {}

    # --- 1. Raw Embedding ---
    print("\n[1/5] Raw embedding baseline...")
    t0 = time.perf_counter()
    raw_decoded = eval_emb.copy()  # zero loss
    t_raw = time.perf_counter() - t0
    fid_raw = 1.0  # perfect
    bw_raw = d * 4  # float32
    results['raw_embedding'] = {
        'fidelity_mean': fid_raw, 'fidelity_median': fid_raw,
        'bandwidth_bytes': bw_raw,
        'encode_time_ms': 0.0,
        'decode_time_ms': 0.0,
    }

    # --- 2. PQ ---
    print("[2/5] Product Quantization (m=8, k=256)...")
    t0 = time.perf_counter()
    pq_codebooks = train_pq(train_emb, m=8, k_sub=256, seed=seed)
    pq_reconstructed, pq_bytes, _ = apply_pq(pq_codebooks, eval_emb)
    t_pq = time.perf_counter() - t0
    pq_fid = QCP.cosine_similarity_batch(eval_emb, pq_reconstructed)
    results['pq_m8'] = {
        'fidelity_mean': float(np.mean(pq_fid)),
        'fidelity_median': float(np.median(pq_fid)),
        'fidelity_p5': float(np.percentile(pq_fid, 5)),
        'fidelity_p95': float(np.percentile(pq_fid, 95)),
        'bandwidth_bytes': pq_bytes,
        'total_time_ms': t_pq * 1000,
    }

    # --- 3. QCP VQ ---
    print("[3/5] QCP VQ (K=256)...")
    t0 = time.perf_counter()
    codes, qerrs, confs, deltas = qcp.encode_vq_batch(eval_emb)
    qcp_decoded = codebook.decode_batch(codes)
    t_qcp = time.perf_counter() - t0
    qcp_fid = QCP.cosine_similarity_batch(eval_emb, qcp_decoded)
    results['qcp_vq'] = {
        'fidelity_mean': float(np.mean(qcp_fid)),
        'fidelity_median': float(np.median(qcp_fid)),
        'fidelity_p5': float(np.percentile(qcp_fid, 5)),
        'fidelity_p95': float(np.percentile(qcp_fid, 95)),
        'bandwidth_bytes': 37,
        'total_time_ms': t_qcp * 1000,
    }

    # --- 4. QCP Dual-Mode ---
    print("[4/5] QCP Dual-Mode...")
    t0 = time.perf_counter()
    dual_result = qcp.encode_full_batch(eval_emb)
    t_dual = time.perf_counter() - t0
    dual_fid = QCP.cosine_similarity_batch(eval_emb, dual_result['decoded'])
    vq_r = dual_result['vq_ratio']
    avg_bw_dual = vq_r * 37 + (1 - vq_r) * 88
    results['qcp_dual'] = {
        'fidelity_mean': float(np.mean(dual_fid)),
        'fidelity_median': float(np.median(dual_fid)),
        'fidelity_p5': float(np.percentile(dual_fid, 5)),
        'fidelity_p95': float(np.percentile(dual_fid, 95)),
        'bandwidth_bytes': avg_bw_dual,
        'total_time_ms': t_dual * 1000,
        'vq_ratio': vq_r,
    }

    # --- 5. JSON Label ---
    print("[5/5] JSON label routing...")
    t0 = time.perf_counter()
    json_labels, json_bytes = simulate_json_label(eval_emb, handler_centroids, handler_names)
    t_json = time.perf_counter() - t0
    results['json_label'] = {
        'fidelity_mean': float('nan'),  # not applicable — discrete labels
        'bandwidth_bytes': json_bytes,
        'total_time_ms': t_json * 1000,
        'note': 'Fidelity N/A for label-based routing',
    }

    # --- Print comparison ---
    headers = ["Method", "Fidelity (mean)", "Fidelity (median)", "Bytes/msg", "Compression vs NL*"]
    nl_bytes = 45 * 4.4  # ~198 bytes
    rows = [
        ["Raw Embedding", "1.0000", "1.0000", f"{bw_raw}", f"{nl_bytes/bw_raw:.1f}x"],
        ["PQ (m=8, k=256)", f"{results['pq_m8']['fidelity_mean']:.4f}",
         f"{results['pq_m8']['fidelity_median']:.4f}", f"{pq_bytes}", f"{nl_bytes/pq_bytes:.1f}x"],
        ["QCP VQ", f"{results['qcp_vq']['fidelity_mean']:.4f}",
         f"{results['qcp_vq']['fidelity_median']:.4f}", "37", f"{nl_bytes/37:.1f}x"],
        ["QCP Dual", f"{results['qcp_dual']['fidelity_mean']:.4f}",
         f"{results['qcp_dual']['fidelity_median']:.4f}",
         f"{avg_bw_dual:.0f}", f"{nl_bytes/avg_bw_dual:.1f}x"],
        ["JSON Label", "N/A", "N/A", f"{json_bytes:.0f}", f"{nl_bytes/json_bytes:.1f}x"],
        ["NL (est.)", "~0.85**", "~0.92**", f"{nl_bytes:.0f}", "1.0x (baseline)"],
    ]
    print_table(headers, rows, "Baseline Comparison")
    print("  * NL bytes estimated at 45 tokens * 4.4 bytes/token = ~198 bytes")
    print("  ** NL fidelity: cos(E(s), E(paraphrase(s))) — varies with paraphrase quality\n")

    save_json({'seed': seed, 'K': K, 'n_eval': len(eval_emb), 'baselines': results},
              "exp17_baseline_comparison")

    # --- Plot ---
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    methods = ["Raw\nEmb", "PQ\n(m=8)", "QCP\nVQ", "QCP\nDual"]
    fids = [1.0, results['pq_m8']['fidelity_mean'],
            results['qcp_vq']['fidelity_mean'], results['qcp_dual']['fidelity_mean']]
    bws = [bw_raw, pq_bytes, 37, avg_bw_dual]
    cs = [COLORS['raw_emb'], COLORS['pq'], COLORS['qcp'], COLORS['qcp_attn']]

    axes[0].bar(methods, fids, color=cs, alpha=0.8)
    axes[0].set_ylabel("Mean Fidelity (cosine sim)")
    axes[0].set_title("Encoding Fidelity")
    axes[0].set_ylim(0.5, 1.05)

    axes[1].bar(methods, bws, color=cs, alpha=0.8)
    axes[1].set_ylabel("Bytes per Message")
    axes[1].set_title("Bandwidth Cost")
    axes[1].set_yscale('log')

    fig.suptitle("Experiment 17: Baseline Comparison", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp17_baseline_comparison")

    return results


if __name__ == "__main__":
    run()
