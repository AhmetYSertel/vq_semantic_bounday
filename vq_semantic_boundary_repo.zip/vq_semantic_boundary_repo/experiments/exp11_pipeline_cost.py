"""
Experiment 11: Agent Pipeline Communication (Redesigned)
=========================================================
Tests QCP in a realistic agent pipeline scenario with task-level
correctness metrics, not just cosine fidelity.

Metrics (priority order):
  1. Task-level correctness:
     - Route accuracy: do paraphrased tasks map to the same QCP code?
     - Paraphrase invariance: % of semantic groups where all variants -> same code
  2. Compression: bytes/tokens saved
  3. Escalation rate: % requiring attention mode vs VQ
  4. Cosine fidelity (secondary/diagnostic)

Design:
  - 10 semantic task groups x 20 paraphrase variants = 200 messages
  - 5 message types: task_assign, status, route, quality, tool_call
  - Groups defined so all variants should ideally encode to same code
"""

import sys
import numpy as np
import time

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, save_plot, save_csv, save_json,
                   print_table, COLORS, PLOTS_DIR)
import matplotlib.pyplot as plt


# 10 Semantic Groups x 20 Paraphrase Variants
TASK_GROUPS = [
    {"type": "task_assign", "canonical": "Search the knowledge base for machine learning frameworks and summarize the top results.",
     "variants": [
        "Look up machine learning frameworks in the knowledge base and give a summary of the best ones.",
        "Query the knowledge base for ML framework information and summarize the top findings.",
        "Find information about machine learning frameworks in our knowledge base, then summarize.",
        "Search our KB for ML frameworks and provide a summary of the leading options.",
        "Retrieve knowledge base entries about machine learning frameworks, summarize top results.",
        "Pull up ML framework info from the knowledge base and write a brief summary.",
        "Go through the knowledge base for machine learning framework data and summarize.",
        "Check the knowledge base for popular ML frameworks and create a summary.",
        "Access the knowledge base to find machine learning frameworks and summarize findings.",
        "Explore the knowledge base for ML framework entries, then provide a top-results summary.",
        "Look through our knowledge base to find ML frameworks and summarize key results.",
        "Use the knowledge base to research machine learning frameworks and summarize.",
        "Consult the knowledge base about ML frameworks and produce a summary of top options.",
        "Dig into the knowledge base for machine learning framework information, summarize best results.",
        "Mine the knowledge base for data on ML frameworks and deliver a concise summary.",
        "Scan the knowledge base for machine learning framework content and summarize top entries.",
        "Search KB for machine learning framework details and compile a summary.",
        "Review knowledge base entries related to ML frameworks and provide a summary.",
        "Investigate machine learning frameworks using the knowledge base, then summarize.",
    ]},
    {"type": "task_assign", "canonical": "Analyze the uploaded CSV file for anomalies in the revenue column and flag outliers.",
     "variants": [
        "Check the uploaded CSV for anomalies in revenue and flag any outlier entries.",
        "Look at the CSV file that was uploaded and find anomalies in the revenue data.",
        "Examine the uploaded CSV's revenue column for unusual values and flag them.",
        "Go through the uploaded CSV and identify any anomalous revenue entries.",
        "Inspect the revenue column in the uploaded CSV file and flag outlier values.",
        "Review the CSV file for revenue anomalies and mark the outliers.",
        "Parse the uploaded CSV and detect anomalies in the revenue field.",
        "Analyze revenue data in the uploaded CSV and highlight any outlier entries.",
        "Scan the CSV file's revenue column for anomalous data points and flag them.",
        "Process the uploaded CSV to find revenue outliers and flag anomalies.",
        "Look for unusual patterns in the revenue column of the uploaded CSV file.",
        "Find and flag anomalies in the revenue data of the uploaded CSV.",
        "Run anomaly detection on the revenue column of the uploaded CSV.",
        "Check for outliers in the CSV file's revenue column and report them.",
        "Identify anomalous revenue values in the uploaded CSV and mark them.",
        "Detect revenue outliers in the CSV file that was uploaded.",
        "Audit the uploaded CSV for anomalous entries in the revenue column.",
        "Flag any abnormal revenue values found in the uploaded CSV data.",
        "Search for and flag revenue anomalies in the uploaded CSV file.",
    ]},
    {"type": "status", "canonical": "Task completed successfully. Found three relevant articles about transformer architectures.",
     "variants": [
        "Task done. Discovered three articles on transformer architectures.",
        "Successfully completed the task. Three relevant transformer architecture articles found.",
        "Finished. Located three articles related to transformer architectures.",
        "Task is complete. Three articles about transformer architectures were found.",
        "Done with the task. Found 3 articles covering transformer architectures.",
        "Completed successfully. Identified three relevant papers on transformer architectures.",
        "Task finished. Three transformer architecture articles were retrieved.",
        "All done. Three relevant articles on transformer architectures discovered.",
        "Task wrapped up. Found three articles discussing transformer architectures.",
        "Successfully finished. Three articles related to transformer architectures located.",
        "Completed the task. Retrieved three articles about transformer architectures.",
        "Task complete. Three relevant transformer architecture articles identified.",
        "Done. Three articles on transformer architectures were found successfully.",
        "Finished the task. Three articles about transformer architectures were located.",
        "Task accomplished. Found three pertinent articles on transformer architectures.",
        "Successfully done. Discovered three articles covering transformer architectures.",
        "Task has been completed. Three transformer architecture articles were found.",
        "Work done. Three relevant articles about transformer architectures retrieved.",
        "Successfully completed. Three articles on transformer architectures found.",
    ]},
    {"type": "status", "canonical": "Error encountered: the specified file does not exist in the upload directory.",
     "variants": [
        "Error: the file specified was not found in the upload directory.",
        "An error occurred: the specified file doesn't exist in uploads.",
        "File not found error: the specified file is missing from the upload directory.",
        "Error: unable to locate the specified file in the upload directory.",
        "The specified file could not be found in the upload directory. Error.",
        "Error: file does not exist in the uploads folder as specified.",
        "Encountered an error: specified file is not present in uploads.",
        "File error: the specified file is missing from the upload directory.",
        "Error report: the file specified does not exist in the upload directory.",
        "The file you specified was not found in the upload directory. Error.",
        "Error: no such file found in the upload directory as specified.",
        "Cannot find the specified file in the upload directory. Error encountered.",
        "Error: the upload directory does not contain the specified file.",
        "The specified file is absent from the upload directory. Error.",
        "Error: file not found: the specified file is not in the uploads.",
        "Upload directory error: specified file does not exist.",
        "Error: failed to locate specified file in the upload directory.",
        "The file specified does not exist in the upload directory: error.",
        "Encountered file-not-found error for the specified upload.",
    ]},
    {"type": "route", "canonical": "Route this query to the code generation module. User wants to create a Python script.",
     "variants": [
        "Send this to the code generation module. The user wants a Python script.",
        "Direct this query to code generation. User is requesting a Python script.",
        "Route to code gen module: user wants to create a Python script.",
        "Forward to code generation module: user requests Python script creation.",
        "This should go to the code generation module. User needs a Python script.",
        "Route query to code gen. Intent: Python script creation.",
        "Pass this to the code generation module; user wants Python code.",
        "Direct to code generation: user requesting a Python script.",
        "This query should be handled by code generation. User wants Python.",
        "Send to code gen module. User's intent is Python script creation.",
        "Forward query to code generation module for Python script request.",
        "Route to code generation: user is asking for a Python script.",
        "Assign to code generation module: Python script creation request.",
        "Code generation module should handle this. User wants a Python script.",
        "This is a code generation request. Route to code gen module.",
        "User wants Python code. Route this to the code generation module.",
        "Direct this request to code generation. Purpose: Python script.",
        "Send to the code gen module: user requesting Python code creation.",
        "Route: code generation module. Task: create Python script for user.",
    ]},
    {"type": "route", "canonical": "Route to memory retrieval module. User is referencing a previous conversation.",
     "variants": [
        "Send to memory retrieval. User is talking about a past conversation.",
        "Direct this to memory retrieval module: user references previous chat.",
        "Route to memory retrieval: user mentions a previous conversation.",
        "Forward to memory module. User is referring to an earlier conversation.",
        "This should go to memory retrieval. User references past discussion.",
        "Route query to memory retrieval: previous conversation reference detected.",
        "Send to memory retrieval module. User is referencing prior chat.",
        "Direct to memory module: user is talking about something from before.",
        "Route to memory retrieval. User's query references a past conversation.",
        "Memory retrieval module needed: user referencing previous conversation.",
        "Forward to memory retrieval: user bringing up past conversation topic.",
        "This references a previous conversation. Route to memory retrieval.",
        "Route to memory module: user is recalling a previous discussion.",
        "Send to memory retrieval module; user referring to earlier conversation.",
        "Direct to memory retrieval: previous conversation context needed.",
        "Route: memory retrieval module. Reason: previous conversation reference.",
        "User references past chat. Send to memory retrieval module.",
        "Memory retrieval is needed. User is referencing a previous conversation.",
        "This query requires memory retrieval: user mentions past conversation.",
    ]},
    {"type": "quality", "canonical": "Output passes quality check. Semantic coherence score is high. Factual consistency verified.",
     "variants": [
        "Quality check passed. High semantic coherence. Facts verified.",
        "Output passed quality validation. Coherence is high and facts are consistent.",
        "Quality gate: pass. Semantic coherence strong, factual consistency confirmed.",
        "Passed quality check. High coherence score, facts verified against KB.",
        "Quality validation successful. Semantic coherence and factual consistency both pass.",
        "Output quality: pass. High coherence, verified factual consistency.",
        "Quality check result: pass. Strong semantic coherence, facts confirmed.",
        "Output approved. Quality check shows high coherence and factual accuracy.",
        "Passed quality validation. Semantic coherence is strong and facts are consistent.",
        "Quality gate passed. Coherence score high, factual consistency verified.",
        "Output meets quality standards. High coherence, facts verified.",
        "Quality pass. Semantic coherence above threshold, facts consistent.",
        "Quality check: passed. Output is coherent and factually consistent.",
        "Validation passed. High semantic coherence and verified facts.",
        "Output clears quality gate. Coherence and factual checks both pass.",
        "Quality check outcome: pass. Coherence high, facts confirmed.",
        "Output validated. Quality metrics show strong coherence and accuracy.",
        "Passed. Quality check confirms high coherence and factual consistency.",
        "Quality validation: pass. Semantic coherence and facts both verified.",
    ]},
    {"type": "quality", "canonical": "Output rejected. Confidence below threshold. Ambiguous intent detected.",
     "variants": [
        "Output failed quality check. Low confidence, ambiguous intent.",
        "Rejected: confidence too low and intent is ambiguous.",
        "Quality gate: reject. Confidence below threshold due to ambiguous intent.",
        "Output rejected. Ambiguous intent detected, confidence below threshold.",
        "Failed quality check. Intent is ambiguous and confidence is insufficient.",
        "Quality validation: reject. Low confidence from ambiguous intent.",
        "Output did not pass. Confidence below threshold, intent unclear.",
        "Rejected output. Detected ambiguous intent, confidence too low.",
        "Quality check failed. Ambiguous intent caused low confidence score.",
        "Output failed. Intent ambiguity led to confidence below threshold.",
        "Reject. Output confidence below threshold due to ambiguous user intent.",
        "Quality gate failed: ambiguous intent, insufficient confidence.",
        "Output rejected for low confidence. Cause: ambiguous intent detected.",
        "Failed. Quality check found ambiguous intent and low confidence.",
        "Rejected: confidence below threshold because intent is ambiguous.",
        "Quality check: reject. Ambiguous intent, confidence insufficient.",
        "Output did not pass quality gate: ambiguous intent, low confidence.",
        "Rejection. Confidence below threshold; ambiguous intent detected.",
        "Quality validation failed. Reason: ambiguous intent, low confidence.",
    ]},
    {"type": "tool_call", "canonical": "Execute web search tool with query about quantum computing developments.",
     "variants": [
        "Run a web search for quantum computing developments.",
        "Use the web search tool to find quantum computing developments.",
        "Execute web search: quantum computing developments.",
        "Search the web for recent quantum computing developments.",
        "Invoke web search tool: query quantum computing developments.",
        "Perform a web search about developments in quantum computing.",
        "Call web search tool to look up quantum computing developments.",
        "Trigger web search for quantum computing development information.",
        "Launch web search tool: topic is quantum computing developments.",
        "Run the web search tool for quantum computing progress.",
        "Web search needed: quantum computing developments.",
        "Execute a web search on the topic of quantum computing developments.",
        "Use web search to find quantum computing development updates.",
        "Fire off a web search about quantum computing developments.",
        "Search web for quantum computing latest developments.",
        "Web search tool call: quantum computing developments query.",
        "Initiate web search for developments in quantum computing.",
        "Tool call: web search, quantum computing developments.",
        "Run web search tool with quantum computing developments query.",
    ]},
    {"type": "tool_call", "canonical": "Execute calculator tool to compute compound interest on the given parameters.",
     "variants": [
        "Run the calculator tool to figure out compound interest with the given parameters.",
        "Use calculator to compute compound interest for the specified values.",
        "Execute calculator: compute compound interest with provided parameters.",
        "Call the calculator tool for compound interest calculation.",
        "Calculate compound interest using the calculator tool and given inputs.",
        "Invoke calculator tool to determine compound interest for these parameters.",
        "Trigger the calculator for compound interest computation.",
        "Use the calculator tool: compute compound interest with given params.",
        "Run calculator: compound interest computation on specified parameters.",
        "Execute the calculator tool to work out compound interest.",
        "Calculator tool call: compute compound interest with provided parameters.",
        "Perform compound interest calculation using the calculator tool.",
        "Fire off calculator tool for compound interest on given values.",
        "Calculate compound interest: use calculator tool with parameters.",
        "Call calculator to compute compound interest with the inputs provided.",
        "Use calculator tool to find compound interest for given parameters.",
        "Execute calculator for compound interest calculation with these values.",
        "Run the calculator to compute compound interest on parameters.",
        "Calculator tool: compute compound interest using the given parameters.",
    ]},
]


def run(K: int = 256):
    print("\n" + "="*60)
    print("  EXPERIMENT 11: Agent Pipeline Communication (Redesigned)")
    print("="*60)

    n_groups = len(TASK_GROUPS)
    n_variants = 20  # canonical + 19 paraphrases
    n_total_expected = n_groups * n_variants

    print(f"\n  {n_groups} semantic groups x {n_variants} variants = {n_total_expected} messages")

    # Flatten all messages
    all_texts = []
    group_ids = []
    type_ids = []
    for gid, group in enumerate(TASK_GROUPS):
        all_texts.append(group["canonical"])
        group_ids.append(gid)
        type_ids.append(group["type"])
        for v in group["variants"]:
            all_texts.append(v)
            group_ids.append(gid)
            type_ids.append(group["type"])

    group_ids = np.array(group_ids)
    n_total = len(all_texts)

    # Setup
    print("\n[1/5] Initializing encoder and codebook...")
    encoder = Encoder()

    # Train codebook on diverse corpus (NOT pipeline messages)
    diverse_texts = load_diverse_texts(5000)
    diverse_emb = encoder.encode(diverse_texts, batch_size=256, show_progress_bar=True)
    cb = Codebook.train(diverse_emb, K=K)
    qcp = QCP(cb)

    # Encode all messages
    print(f"\n[2/5] Encoding {n_total} pipeline messages...")
    embeddings = encoder.encode(all_texts, batch_size=256)
    codes, qerrs, confs, deltas = qcp.encode_vq_batch(embeddings)

    # Metric 1: Paraphrase Invariance (Route Accuracy)
    print("\n[3/5] Computing task-level correctness...")

    group_codes = {}
    group_canonical_code = {}

    for gid in range(n_groups):
        mask = group_ids == gid
        group_c = codes[mask]
        group_codes[gid] = group_c
        group_canonical_code[gid] = group_c[0]

    invariance_per_group = []
    for gid in range(n_groups):
        gc = group_codes[gid]
        canonical = gc[0]
        matches = np.sum(gc == canonical)
        invariance_per_group.append(float(matches / len(gc)))

    mean_invariance = float(np.mean(invariance_per_group))
    perfect_groups = sum(1 for inv in invariance_per_group if inv == 1.0)

    canonical_codes = [group_canonical_code[gid] for gid in range(n_groups)]
    unique_canonical = len(set(canonical_codes))
    group_separation = unique_canonical / n_groups

    print(f"  Paraphrase invariance (mean): {mean_invariance:.1%}")
    print(f"  Perfect groups (100% invariance): {perfect_groups}/{n_groups}")
    print(f"  Group separation: {unique_canonical}/{n_groups} unique canonical codes ({group_separation:.1%})")

    for gid in range(n_groups):
        g = TASK_GROUPS[gid]
        inv = invariance_per_group[gid]
        gc = group_codes[gid]
        n_unique = len(np.unique(gc))
        print(f"    Group {gid} ({g['type']:>12}): invariance={inv:.0%}  unique_codes={n_unique}  canonical_code={gc[0]}")

    # Metric 2: Compression
    print(f"\n[4/5] Computing compression metrics...")

    nl_bytes = sum(len(t.encode('utf-8')) for t in all_texts)
    nl_tokens = sum(len(t) // 4 + 1 for t in all_texts)

    full_result = qcp.encode_full_batch(embeddings)
    modes = full_result['modes']
    n_vq = int(np.sum(modes == 'vq'))
    n_attn = int(np.sum(modes == 'attn'))
    qcp_bytes = n_vq * 37 + n_attn * 88
    compression = nl_bytes / qcp_bytes
    escalation_rate = n_attn / n_total

    print(f"  NL: {nl_bytes} bytes, ~{nl_tokens} tokens")
    print(f"  QCP: {qcp_bytes} bytes (VQ={n_vq}, Attn={n_attn})")
    print(f"  Compression: {compression:.1f}x")
    print(f"  Token savings: {nl_tokens} tokens eliminated")
    print(f"  Escalation rate: {escalation_rate:.1%} ({n_attn}/{n_total})")

    # Per-type breakdown
    per_type = {}
    for msg_type in sorted(set(type_ids)):
        idx = [i for i, t in enumerate(type_ids) if t == msg_type]
        type_texts = [all_texts[i] for i in idx]
        type_group_ids = group_ids[idx]
        type_codes = codes[idx]

        t_nl_bytes = sum(len(t.encode('utf-8')) for t in type_texts)
        t_nl_tokens = sum(len(t) // 4 + 1 for t in type_texts)
        t_qcp_bytes = len(idx) * 37

        type_groups = set(type_group_ids)
        type_inv = []
        for gid in type_groups:
            gmask = type_group_ids == gid
            gc = type_codes[gmask]
            canonical = gc[0]
            type_inv.append(float(np.sum(gc == canonical) / len(gc)))

        per_type[msg_type] = {
            'count': len(idx),
            'nl_bytes': t_nl_bytes,
            'nl_tokens': t_nl_tokens,
            'qcp_bytes': t_qcp_bytes,
            'compression': t_nl_bytes / t_qcp_bytes,
            'invariance_mean': float(np.mean(type_inv)),
        }

    # Metric 4: Cosine Fidelity (secondary)
    fidelity = qcp.encoding_fidelity_batch(embeddings)
    fid_mean = float(np.mean(fidelity))
    fid_median = float(np.median(fidelity))

    print(f"\n  Cosine fidelity (secondary): mean={fid_mean:.4f}  median={fid_median:.4f}")

    # Plots
    print(f"\n[5/5] Generating plots...")

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))

    group_labels = [f"G{i}\n({TASK_GROUPS[i]['type'][:6]})" for i in range(n_groups)]
    colors_inv = [COLORS['qcp'] if inv >= 0.8 else COLORS['accent'] for inv in invariance_per_group]
    axes[0].bar(group_labels, invariance_per_group, color=colors_inv, alpha=0.8)
    axes[0].axhline(y=0.8, color='gray', ls='--', alpha=0.5, label='80% threshold')
    axes[0].set_ylabel('Paraphrase Invariance')
    axes[0].set_title('Task-Level Correctness')
    axes[0].set_ylim(0, 1.1)
    axes[0].legend(fontsize=8)
    for i, v in enumerate(invariance_per_group):
        axes[0].annotate(f'{v:.0%}', (i, v), textcoords='offset points',
                        xytext=(0, 5), ha='center', fontsize=8)

    type_names = sorted(per_type.keys())
    comp_values = [per_type[t]['compression'] for t in type_names]
    axes[1].bar(type_names, comp_values, color=COLORS['qcp'], alpha=0.8)
    axes[1].set_ylabel('Compression Ratio (NL/QCP)')
    axes[1].set_title('Bandwidth Compression by Type')
    for i, v in enumerate(comp_values):
        axes[1].annotate(f'{v:.1f}x', (i, v), textcoords='offset points',
                        xytext=(0, 5), ha='center', fontsize=9)

    dominant_pct = [float(np.max(np.bincount(group_codes[gid])) / len(group_codes[gid])) for gid in range(n_groups)]
    axes[2].bar(group_labels, dominant_pct, color=COLORS['qcp'], alpha=0.8)
    axes[2].axhline(y=0.5, color='gray', ls='--', alpha=0.5)
    axes[2].set_ylabel('Dominant Code Concentration')
    axes[2].set_title('Code Assignment Consistency')
    axes[2].set_ylim(0, 1.1)
    for i, v in enumerate(dominant_pct):
        axes[2].annotate(f'{v:.0%}', (i, v), textcoords='offset points',
                        xytext=(0, 5), ha='center', fontsize=8)

    fig.suptitle('Experiment 11: Agent Pipeline Communication', fontsize=14)
    plt.tight_layout()
    save_plot(fig, 'exp11_pipeline')

    # Save
    summary = {
        'n_groups': n_groups,
        'n_variants': n_variants,
        'n_total': n_total,
        'K': K,
        'encoder': encoder.model_name,
        'task_correctness': {
            'paraphrase_invariance_mean': mean_invariance,
            'perfect_groups': perfect_groups,
            'group_separation': group_separation,
            'unique_canonical_codes': unique_canonical,
            'per_group': [
                {
                    'group_id': gid,
                    'type': TASK_GROUPS[gid]['type'],
                    'invariance': invariance_per_group[gid],
                    'n_unique_codes': int(len(np.unique(group_codes[gid]))),
                    'canonical_code': int(group_canonical_code[gid]),
                }
                for gid in range(n_groups)
            ]
        },
        'compression': {
            'nl_bytes': nl_bytes,
            'nl_tokens': nl_tokens,
            'qcp_bytes': qcp_bytes,
            'compression_ratio': compression,
            'token_savings': nl_tokens,
        },
        'escalation': {
            'n_vq': n_vq,
            'n_attn': n_attn,
            'escalation_rate': escalation_rate,
        },
        'fidelity_secondary': {
            'mean': fid_mean,
            'median': fid_median,
        },
        'per_type': per_type,
    }
    save_json(summary, 'exp11_pipeline_summary')

    csv_rows = []
    for i in range(n_total):
        csv_rows.append([
            i, group_ids[i], type_ids[i], int(codes[i]),
            float(qerrs[i]), float(confs[i]), float(fidelity[i]),
            len(all_texts[i].encode('utf-8')),
        ])
    save_csv(csv_rows,
             ['msg_id', 'group_id', 'type', 'code', 'qerr', 'conf', 'fidelity', 'nl_bytes'],
             'exp11_pipeline_messages')

    print(f"\n  \U0001f4dd Paper Summary:")
    print(f"  {n_total} messages across {n_groups} semantic groups.")
    print(f"  Paraphrase invariance: {mean_invariance:.1%} (mean)")
    print(f"  Perfect groups: {perfect_groups}/{n_groups}")
    print(f"  Group separation: {group_separation:.0%}")
    print(f"  Compression: {compression:.1f}x ({nl_tokens} tokens eliminated)")
    print(f"  Escalation rate: {escalation_rate:.1%}")
    print(f"  Cosine fidelity (secondary): {fid_mean:.3f} mean, {fid_median:.3f} median")

    return summary


if __name__ == '__main__':
    run()
