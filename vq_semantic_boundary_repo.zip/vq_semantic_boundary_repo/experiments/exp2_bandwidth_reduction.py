"""
Experiment 2: Bandwidth Reduction
===================================
Measures byte-level and token-level bandwidth of QCP messages
versus equivalent natural language messages.
"""

import sys
import numpy as np

sys.path.insert(0, '.')
from qcp import Codebook, Encoder, QCP, message_size_vq, message_size_attn
from utils import (save_plot, save_csv, save_json, print_table,
                   COLORS, load_diverse_texts)
import matplotlib.pyplot as plt


# Representative inter-module messages (simulating real agent comms)
MESSAGE_TEMPLATES = {
    'subtask_result': [
        "I have completed the data analysis task. The key finding is that revenue increased by 15% in Q3 compared to Q2, driven primarily by the enterprise segment which grew 23%. Consumer segment remained flat. The full breakdown is attached in the report summary.",
        "Task complete: sentiment analysis of 500 customer reviews. Results: 72% positive, 18% neutral, 10% negative. Top positive themes: ease of use, customer support. Top negative themes: pricing, mobile app performance.",
        "Research subtask finished. Found 12 relevant papers on transformer architecture optimization. Key approaches: pruning (4 papers), quantization (3 papers), knowledge distillation (5 papers). Most promising: combined pruning + quantization achieving 4x speedup with <2% accuracy loss.",
        "Database migration completed successfully. 2.3 million records transferred from PostgreSQL to the new schema. Zero data loss confirmed via checksum validation. Migration took 47 minutes. Rollback point preserved.",
        "Image classification model training complete. Final accuracy: 94.2% on test set. Best performing architecture: EfficientNet-B4 with augmentation. Training time: 6 hours on 4 GPUs. Model saved to artifacts.",
        "Completed the user segmentation analysis. Identified 5 distinct clusters: power users (12%), regular users (34%), casual users (28%), dormant users (18%), and churned users (8%). Cluster separation score: 0.73.",
        "Text extraction from 200 PDF documents finished. Average extraction accuracy: 96.8%. Failed documents: 3 (corrupted files). Extracted text stored in the document database with metadata tagging.",
        "A/B test analysis complete. Variant B shows 7.2% improvement in conversion rate over control (p=0.003). Sample size: 15,000 per group. Recommended action: roll out Variant B to all users.",
        "Web scraping task finished. Collected pricing data from 45 competitor websites. 892 product entries extracted. Data cleaned and normalized. 12 entries flagged for manual review due to inconsistent formatting.",
        "Code review analysis complete. Scanned 340 files across 12 repositories. Found 23 critical issues, 67 warnings, and 145 suggestions. Top concern: SQL injection vulnerability in the auth module.",
        "Completed market research compilation. Analyzed 30 industry reports from 2024. Key trend: 67% of enterprises plan to increase AI spending. Market size estimate: $420B by 2027. Full report generated.",
        "Log analysis finished. Processed 2.4 million log entries from the past 7 days. Identified 3 anomalous patterns: unusual login attempts from Eastern Europe, API timeout spike on Tuesday, and memory leak in worker process 7.",
        "Customer churn prediction model trained. AUC-ROC: 0.89 on holdout set. Top predictive features: days since last login, support ticket frequency, subscription tier. Model deployed to staging environment.",
        "Geospatial analysis complete. Mapped 5,000 delivery routes across 3 cities. Average delivery time: 34 minutes. Identified 12 bottleneck zones. Recommended route optimizations could reduce average time by 18%.",
        "Natural language understanding evaluation finished. Tested on 4 benchmarks: GLUE (89.3), SuperGLUE (87.1), SQuAD (91.2), MMLU (78.4). Performance within expected range for model size.",
        "Supply chain optimization results ready. Simulated 50 scenarios. Optimal configuration reduces inventory costs by 22% while maintaining 99.1% fulfillment rate. Recommended vendor mix: 3 primary, 2 backup.",
        "Social media monitoring report generated. Tracked 12,000 mentions across 4 platforms over 30 days. Sentiment trend: improving (+5% from last month). Top trending topic: new product launch.",
        "Fraud detection scan complete. Analyzed 1.2 million transactions. Flagged 847 as suspicious (0.07% flag rate). Estimated false positive rate: 12%. Top fraud pattern: repeated small transactions below review threshold.",
        "Performance benchmark results compiled. Tested 8 model configurations. Best throughput: 1,200 req/sec (config D). Best latency: 45ms p99 (config F). Recommended: config D for batch, config F for real-time.",
        "Document similarity analysis done. Compared 500 legal documents pairwise. Found 23 near-duplicate pairs (similarity > 0.95). Generated deduplication report with recommended merge actions.",
    ],
    'tool_call': [
        "Called the Weather API for Istanbul, Turkey. Current conditions: 18°C, partly cloudy, humidity 65%, wind 12 km/h northwest. Forecast for tomorrow: high 22°C, low 14°C, 30% chance of rain in the afternoon.",
        "Executed SQL query on the sales database. Query: SELECT region, SUM(revenue) FROM sales WHERE quarter='Q3' GROUP BY region. Results: North America $4.2M, Europe $2.8M, Asia Pacific $1.9M, Rest of World $0.7M.",
        "Called the translation API to translate the user's message from Turkish to English. Input: 'Bugün hava çok güzel, dışarı çıkıp yürüyüş yapmak istiyorum.' Output: 'The weather is very nice today, I want to go outside and take a walk.'",
        "Searched Google Scholar for recent papers on vector quantization in neural networks. Found 47 results, filtered to top 10 by citation count. Most cited: 'VQ-VAE: Neural Discrete Representation Learning' with 3,200 citations.",
        "Fetched stock price data for AAPL from the financial API. Current price: $187.43, change: +$2.15 (+1.16%). 52-week range: $142.00 - $199.62. Market cap: $2.89T. P/E ratio: 29.4.",
        "Queried the geocoding API for 'Izmir University of Economics'. Returned coordinates: 38.3917°N, 27.0428°E. Address: Sakarya Caddesi No:156, Balçova, Izmir 35330, Turkey.",
        "Called the GitHub API to fetch repository statistics. Stars: 1,247. Forks: 283. Open issues: 45. Last commit: 2 hours ago. Top contributor: user/dev-lead with 342 commits.",
        "Executed Python script via code interpreter. Script performed linear regression on the uploaded CSV. R-squared: 0.847. Coefficients: intercept=12.3, slope_x1=3.7, slope_x2=-1.2. Plot saved as regression_output.png.",
        "Called the email sending API. Sent message to 3 recipients with subject 'Q3 Report Summary'. Delivery status: 2 delivered, 1 pending. Estimated delivery for pending: within 5 minutes.",
        "Queried the knowledge graph for entity 'Vector Quantization'. Found 15 related concepts, 8 applications, and 23 referenced papers. Key relationships: VQ-VAE, codebook learning, discrete representations.",
        "Called the calendar API to check availability. User is free: tomorrow 2-4 PM, Thursday 10 AM - 12 PM, Friday all day. Conflicts: tomorrow morning (team standup), Thursday afternoon (client call).",
        "Fetched exchange rate data from the forex API. USD/TRY: 34.82 (+0.15%). EUR/TRY: 37.41 (-0.08%). GBP/TRY: 43.67 (+0.22%). Data as of 15 minutes ago.",
        "Called the image generation API with prompt 'futuristic city skyline at sunset, cyberpunk style'. Generated 4 variants at 1024x1024. Estimated cost: $0.04. Images saved to /tmp/generated/.",
        "Queried the DNS API for domain 'example-startup.com'. Status: available for registration. Similar taken domains: example-startup.io, examplestartup.com. Registrar price: $12.99/year.",
        "Called the sentiment analysis API on the customer feedback batch. Processed 200 reviews. Average sentiment score: 0.72 (positive). Distribution: very positive 35%, positive 28%, neutral 22%, negative 10%, very negative 5%.",
        "Fetched flight data from the travel API. Istanbul to Munich, March 15-22. Cheapest: Turkish Airlines $287 (1 stop). Fastest: Lufthansa $412 (direct, 3h10m). Best value: Pegasus $198 (1 stop, 5h20m).",
        "Called the PDF extraction API on the uploaded document. Extracted 45 pages, 12 tables, 8 figures. OCR confidence: 98.2%. Text exported to structured JSON with page-level metadata.",
        "Queried the package registry (PyPI) for 'qcp-framework'. Package not found. Similar packages: qcp-tools (last updated 2023), quantized-comm (no releases). Namespace available for registration.",
        "Called the CI/CD API to trigger a build. Pipeline started: build → test → lint → deploy-staging. Current status: build step complete (42 seconds), test step running. Estimated completion: 8 minutes.",
        "Fetched nutrition data from the food API. Query: 'Turkish kebab plate'. Calories: 650 kcal. Protein: 42g. Carbs: 38g. Fat: 35g. Serving size: 350g. Allergens: gluten, dairy.",
    ],
    'routing_decision': [
        "Classified the incoming query as belonging to the finance domain with 94% confidence. The query mentions stock prices, portfolio allocation, and risk assessment. Routing to the FinanceAgent for specialized handling.",
        "This query requires multi-step reasoning. Step 1: gather product specifications (route to ProductDB). Step 2: compare with competitor data (route to MarketResearch). Step 3: synthesize recommendation (route to RecommendationEngine).",
        "The user's request is a creative writing task. Detected genre: science fiction. Detected constraints: short story format, 1000 words, include themes of AI consciousness. Routing to CreativeWritingAgent with these parameters.",
        "Intent classification result: the user wants to schedule a meeting. Extracted entities: participants (John, Sarah, Mike), preferred time (next Tuesday afternoon), duration (1 hour), topic (Q4 planning). Routing to CalendarAgent.",
        "Query analysis: this is a code debugging request. Language: Python. Framework: FastAPI. Error type: async/await issue. Confidence: 91%. Routing to CodeDebugAgent with Python-async specialization.",
        "Detected language: Turkish. User preference: respond in Turkish. Query type: general knowledge question about history. Routing to GeneralKnowledgeAgent with language parameter set to 'tr'.",
        "Multi-modal input detected. User uploaded an image and asked a question about it. Image type: chart/graph. Routing to VisionAnalysisAgent with chart-reading specialization enabled.",
        "Query classified as medical information request. Applying safety constraints: no diagnosis, no prescription advice, general information only. Routing to HealthInfoAgent with safety guardrails active.",
        "Detected complex math problem requiring step-by-step solution. Domain: calculus (integration). Difficulty: undergraduate level. Routing to MathSolverAgent with show-work parameter enabled.",
        "User is continuing a multi-turn conversation about travel planning. Context length: 12 previous turns. Key entities: destination (Japan), dates (March 2026), budget ($3000). Routing to TravelPlannerAgent with full context.",
        "Ambiguous query detected. Could be interpreted as: (a) product recommendation, (b) technical comparison, or (c) purchase decision help. Confidence spread: 40/35/25. Routing to ClarificationAgent to disambiguate.",
        "Legal question detected. Jurisdiction: Turkey. Topic: employment law. Applying disclaimer requirement. Routing to LegalInfoAgent with KVKK compliance checks enabled.",
        "Urgent request flagged. User mentions deadline: 'need this by tomorrow morning'. Priority: high. Routing to TaskManagerAgent with expedited processing. Estimated completion: 2 hours.",
        "Conversation sentiment shift detected. User tone changed from neutral to frustrated over last 3 turns. Activating empathetic response mode. Routing to SupportAgent with de-escalation protocol.",
        "Data analysis request with uploaded file. File type: CSV, 15 columns, 10,000 rows. Requested analysis: correlation matrix and outlier detection. Routing to DataAnalysisAgent with file reference.",
        "Detected request for real-time information. Topic: live sports scores. Data freshness requirement: < 5 minutes. Routing to LiveDataAgent with sports API access. Caching disabled for this query.",
        "User requested output in specific format: PowerPoint presentation, 10 slides, corporate style. Routing to DocumentGenerationAgent with template: corporate-blue, format: pptx.",
        "Privacy-sensitive query detected. User asking about personal financial data. Applying data access controls. Routing to SecureDataAgent with user authentication verification required.",
        "Batch processing request. User wants to apply the same transformation to 50 documents. Routing to BatchProcessingAgent. Estimated time: 15 minutes. Progress updates will be sent every 2 minutes.",
        "API integration question. User is building with our SDK. Detected: Python client, version 2.3. Known issue with that version: rate limiting bug. Routing to DevSupportAgent with known-issues context.",
    ],
    'status_update': [
        "Pipeline stage 3 of 5 complete. Current progress: 60%. Estimated time remaining: 8 minutes. No errors encountered. Memory usage: 4.2 GB / 16 GB. CPU utilization: 78%.",
        "Agent coordination update: Agent A completed research phase. Agent B is 40% through data collection. Agent C is waiting for Agent B's output. Expected pipeline completion: 12 minutes.",
        "Monitoring alert: response latency for the recommendation module has increased from 200ms to 850ms in the last 5 minutes. Root cause analysis suggests database connection pool exhaustion. Scaling up connections.",
        "Batch job progress: 7,500 of 10,000 items processed (75%). Current throughput: 120 items/minute. Error rate: 0.3%. ETA: 21 minutes. No critical failures detected.",
        "Model inference server status: healthy. Current load: 340 requests/minute. Average latency: 125ms. Queue depth: 12. Auto-scaling: 3 of 5 instances active. GPU utilization: 67%.",
        "Data pipeline checkpoint: ingestion stage complete (2.1M records). Transformation stage: 85% complete. Loading stage: pending. Data quality score: 98.7%. Schema validation: passed.",
        "Scheduled maintenance starting in 15 minutes. Affected services: search index, recommendation engine. Expected downtime: 30 minutes. Fallback mode: cached results will be served.",
        "Background task completed: codebook retraining finished. New codebook version: v2.4. Centroids updated: 23 of 256. Migration status: ready for deployment. Validation accuracy: 97.1%.",
        "Resource utilization report: disk usage at 72% (warning threshold: 80%). Recommended action: archive data older than 90 days. Estimated space recovery: 45 GB.",
        "Experiment tracking update: run #347 completed. Metrics: loss=0.023, accuracy=96.1%, F1=0.947. Compared to baseline: +2.3% accuracy. Model checkpoint saved. Notification sent to team channel.",
        "Rate limiting status: API quota usage at 8,500 of 10,000 daily limit (85%). Current rate: 23 requests/minute. Projected to hit limit in: 65 minutes. Recommendation: throttle non-critical requests.",
        "Security scan completed. Scanned 1,200 endpoints. Vulnerabilities found: 0 critical, 2 high, 8 medium, 15 low. High severity items: outdated TLS certificate on staging, open redirect on legacy endpoint.",
        "Cache performance report: hit rate 87.3% (target: 85%). Cache size: 2.1 GB. Eviction rate: 340 entries/hour. Most cached: product catalog queries. Least cached: user-specific recommendations.",
        "Deployment status: version 3.2.1 rolled out to 30% of traffic. Error rate: 0.02% (within normal range). Latency p99: 340ms (baseline: 320ms). Proceeding with 50% rollout in 30 minutes.",
        "Backup verification complete. All 12 databases backed up successfully. Total backup size: 890 GB. Encryption: AES-256. Restoration test: passed (restored test DB in 4 minutes). Next backup: 6 hours.",
        "Queue health check: message queue depth is 2,340 (normal range: 0-5,000). Consumer lag: 45 seconds. Dead letter queue: 7 messages (investigating). Throughput: 500 messages/second.",
        "Training progress: epoch 45 of 100. Training loss: 0.031. Validation loss: 0.038. Learning rate: 1e-5. No signs of overfitting. GPU memory: 14.2 GB / 24 GB. Estimated completion: 3 hours.",
        "Content moderation stats: reviewed 5,000 items today. Auto-approved: 4,820 (96.4%). Flagged for human review: 145 (2.9%). Auto-rejected: 35 (0.7%). False positive rate estimate: 8%.",
        "System health dashboard: all 8 microservices healthy. Database replication lag: 2ms. CDN cache hit ratio: 94%. DNS resolution: 12ms average. SSL certificates: all valid (next expiry: 45 days).",
        "Workflow orchestration: 5 of 8 parallel tasks complete. Task 6: 70% done. Tasks 7-8: queued. Dependency graph: no blockers. Resource allocation: optimal. ETA for full completion: 25 minutes.",
    ],
    'handoff': [
        "Transferring conversation context to specialist agent. User profile: enterprise customer, technical background, previous interactions about API integration. Current issue: webhook delivery failures. Sentiment: frustrated but constructive.",
        "Delegating subtask to research agent. Context: user wants comparison of cloud providers for ML workloads. Budget constraint: $5000/month. Requirements: GPU access, managed Kubernetes, good Python SDK support.",
        "Escalating to human support. Reason: user requesting account deletion with active subscription. Billing implications need human review. Context summary attached. Priority: medium. Estimated wait: 5 minutes.",
        "Handing off to code generation agent. Specification: REST API endpoint for user authentication. Language: Python/FastAPI. Requirements: JWT tokens, rate limiting, input validation. Database: PostgreSQL.",
        "Transferring to specialized legal agent. Query: GDPR data export request. User jurisdiction: Germany. Required response time: 30 days per regulation. Data scope: all personal data including derived analytics.",
        "Delegating image processing task. Input: 50 product photos. Required operations: background removal, resize to 800x800, format conversion to WebP. Quality: high. Output directory specified by user.",
        "Handing off long-running research task to background agent. Topic: competitive analysis of 20 SaaS companies. Deliverable: comparison matrix with pricing, features, market position. Deadline: 48 hours.",
        "Transferring to multilingual agent. User switched from English to Turkish mid-conversation. Previous context: discussing project management tools. Maintaining conversation history across language switch.",
        "Escalating to senior agent. Reason: complex multi-system debugging issue spanning 3 services. Junior agent identified the symptoms but root cause requires cross-service trace analysis.",
        "Delegating to scheduling agent. Task: find optimal meeting time for 6 participants across 3 time zones (EST, CET, JST). Duration: 90 minutes. Constraints: avoid Monday mornings and Friday afternoons.",
        "Handing off to document generation agent. Requirements: create quarterly business review presentation. Data sources: sales DB, marketing analytics, customer feedback. Template: executive summary format, 15 slides max.",
        "Transferring financial analysis to specialized agent. Context: user uploaded 3 years of financial statements. Requested: ratio analysis, trend identification, peer comparison. Compliance note: data contains PII.",
        "Delegating to testing agent. Task: generate unit tests for the uploaded Python module (450 lines). Coverage target: 90%. Framework: pytest. Include edge cases and error handling tests.",
        "Handing off to DevOps agent. Issue: production deployment failed at step 3 (database migration). Rollback executed automatically. Logs attached. Need: root cause analysis and fix recommendation.",
        "Transferring to data visualization agent. Dataset: 100K rows, 15 columns. Requested visualizations: time series of revenue, geographic heatmap of users, funnel chart of conversion. Output: interactive dashboard.",
        "Escalating to compliance agent. Trigger: user data access request from a jurisdiction with new privacy regulations. Need: assess applicability, determine response requirements, draft compliance response.",
        "Delegating translation and localization task. Content: 200 UI strings. Source: English. Targets: Turkish, German, Japanese. Requirements: maintain technical terminology consistency. Context file provided.",
        "Handing off conversation to after-hours support bot. Summary: user was asking about billing discrepancy ($47.99 charge). Issue partially investigated, need access to billing system for resolution. Priority: low.",
        "Transferring to optimization agent. Problem: minimize cloud infrastructure costs while maintaining SLA (99.9% uptime, <200ms p99 latency). Current monthly spend: $12,400. Target: 20% reduction.",
        "Delegating to content review agent. Task: review and fact-check a 5000-word blog post about AI trends. Check for: factual accuracy, bias, readability score, SEO optimization. Deadline: 4 hours.",
    ],
}


def count_tokens(text: str) -> int:
    """Count tokens using tiktoken (cl100k_base) or fallback to word-based estimate."""
    try:
        import tiktoken
        enc = tiktoken.get_encoding("cl100k_base")
        return len(enc.encode(text))
    except ImportError:
        # Rough estimate: ~1.3 tokens per word for English
        return int(len(text.split()) * 1.3)


def run():
    print("\n" + "="*60)
    print("  EXPERIMENT 2: Bandwidth Reduction")
    print("="*60)

    # --- 1. Collect all messages ---
    print("\n[1/4] Preparing inter-module messages...")
    all_messages = []
    for msg_type, templates in MESSAGE_TEMPLATES.items():
        for msg in templates:
            all_messages.append((msg_type, msg))

    n_messages = len(all_messages)
    print(f"  {n_messages} representative messages across {len(MESSAGE_TEMPLATES)} types")

    # --- 2. Measure NL bandwidth ---
    print("[2/4] Measuring NL bandwidth...")
    nl_data = []
    for msg_type, msg in all_messages:
        tokens = count_tokens(msg)
        byte_size = len(msg.encode('utf-8'))
        nl_data.append({
            'type': msg_type,
            'text': msg,
            'tokens': tokens,
            'bytes': byte_size,
        })

    # --- 3. Measure QCP bandwidth ---
    print("[3/4] Computing QCP bandwidth...")

    # Encode messages
    encoder = Encoder()
    texts = [msg for _, msg in all_messages]
    embeddings = encoder.encode(texts, batch_size=64)

    # Train codebook
    codebook = Codebook.train(embeddings, K=256)
    qcp = QCP(codebook)

    qcp_vq_size = message_size_vq(256)  # ~37 bytes
    qcp_attn_size = message_size_attn(16)  # ~88 bytes

    results = qcp.encode_full_batch(embeddings)

    # --- 4. Results ---
    print("[4/4] Generating results...\n")

    # Per-type aggregation
    type_stats = {}
    for i, (msg_type, msg) in enumerate(all_messages):
        if msg_type not in type_stats:
            type_stats[msg_type] = {'nl_tokens': [], 'nl_bytes': [], 'modes': []}
        type_stats[msg_type]['nl_tokens'].append(nl_data[i]['tokens'])
        type_stats[msg_type]['nl_bytes'].append(nl_data[i]['bytes'])
        type_stats[msg_type]['modes'].append(results['modes'][i])

    # Main results table
    headers = ["Message Type", "NL Tokens", "NL Bytes", "QCP VQ (B)", "QCP Attn (B)",
               "Ratio (VQ)", "Ratio (Attn)"]
    rows = []
    csv_rows = []

    for msg_type in MESSAGE_TEMPLATES.keys():
        s = type_stats[msg_type]
        avg_tokens = np.mean(s['nl_tokens'])
        avg_bytes = np.mean(s['nl_bytes'])
        ratio_vq = avg_bytes / qcp_vq_size
        ratio_attn = avg_bytes / qcp_attn_size

        rows.append([
            msg_type,
            f"{avg_tokens:.0f}",
            f"{avg_bytes:.0f}",
            f"{qcp_vq_size}",
            f"{qcp_attn_size}",
            f"{ratio_vq:.0f}x",
            f"{ratio_attn:.0f}x",
        ])
        csv_rows.append([msg_type, avg_tokens, avg_bytes, qcp_vq_size,
                         qcp_attn_size, ratio_vq, ratio_attn])

    # Overall
    all_tokens = [d['tokens'] for d in nl_data]
    all_bytes = [d['bytes'] for d in nl_data]
    overall_ratio_vq = np.mean(all_bytes) / qcp_vq_size
    overall_ratio_attn = np.mean(all_bytes) / qcp_attn_size

    rows.append([
        "OVERALL",
        f"{np.mean(all_tokens):.0f}",
        f"{np.mean(all_bytes):.0f}",
        f"{qcp_vq_size}",
        f"{qcp_attn_size}",
        f"{overall_ratio_vq:.0f}x",
        f"{overall_ratio_attn:.0f}x",
    ])

    print_table(headers, rows, "Bandwidth: NL vs QCP")

    # Token cost analysis
    print(f"  Mean NL tokens per message: {np.mean(all_tokens):.0f}")
    print(f"  Mean NL bytes per message: {np.mean(all_bytes):.0f}")
    print(f"  QCP VQ message: {qcp_vq_size} bytes (1 byte code + metadata)")
    print(f"  QCP Attention message: {qcp_attn_size} bytes (sparse top-16 + metadata)")
    print(f"  Compression ratio (VQ): {overall_ratio_vq:.0f}x")
    print(f"  Compression ratio (Attn): {overall_ratio_attn:.0f}x")

    # LLM compute cost comparison
    print(f"\n  LLM Compute Cost Comparison:")
    print(f"  NL: receiver processes ~{np.mean(all_tokens):.0f} input tokens (attention cost)")
    print(f"  QCP: receiver performs 1 table lookup (O(1), no LLM call)")
    print(f"  Effective compute reduction: >>{overall_ratio_vq:.0f}x (superlinear in tokens)")

    # --- Plot: Token distribution ---
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left: NL token distribution by type
    type_names = list(MESSAGE_TEMPLATES.keys())
    token_means = [np.mean(type_stats[t]['nl_tokens']) for t in type_names]
    token_stds = [np.std(type_stats[t]['nl_tokens']) for t in type_names]

    bars = axes[0].barh(type_names, token_means, xerr=token_stds,
                         color=COLORS['nl'], alpha=0.7, capsize=3)
    axes[0].axvline(qcp_vq_size / 4, color=COLORS['qcp'], ls='--', lw=2,
                     label=f'QCP VQ (~{qcp_vq_size/4:.0f} token-equiv)')
    axes[0].set_xlabel("Tokens")
    axes[0].set_title("NL Message Size by Type")
    axes[0].legend()

    # Right: Compression ratio comparison
    x = np.arange(len(type_names))
    w = 0.35
    vq_ratios = [np.mean(type_stats[t]['nl_bytes']) / qcp_vq_size for t in type_names]
    attn_ratios = [np.mean(type_stats[t]['nl_bytes']) / qcp_attn_size for t in type_names]

    axes[1].bar(x - w/2, vq_ratios, w, label='QCP VQ', color=COLORS['qcp'], alpha=0.7)
    axes[1].bar(x + w/2, attn_ratios, w, label='QCP Attention', color=COLORS['qcp_attn'], alpha=0.7)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(type_names, rotation=30, ha='right')
    axes[1].set_ylabel("Compression Ratio (NL/QCP)")
    axes[1].set_title("Bandwidth Reduction by Message Type")
    axes[1].legend()

    fig.suptitle("Experiment 2: Bandwidth Reduction", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp2_bandwidth")

    # Save data
    save_csv(csv_rows,
             ["msg_type", "nl_tokens_avg", "nl_bytes_avg", "qcp_vq_bytes",
              "qcp_attn_bytes", "ratio_vq", "ratio_attn"],
             "exp2_bandwidth")

    save_json({
        'n_messages': n_messages,
        'mean_nl_tokens': float(np.mean(all_tokens)),
        'mean_nl_bytes': float(np.mean(all_bytes)),
        'qcp_vq_bytes': qcp_vq_size,
        'qcp_attn_bytes': qcp_attn_size,
        'compression_ratio_vq': float(overall_ratio_vq),
        'compression_ratio_attn': float(overall_ratio_attn),
        'per_type': {t: {
            'nl_tokens_mean': float(np.mean(type_stats[t]['nl_tokens'])),
            'nl_bytes_mean': float(np.mean(type_stats[t]['nl_bytes'])),
        } for t in type_names}
    }, "exp2_bandwidth_summary")

    print(f"\n  📝 Paper Summary:")
    print(f"  QCP reduces inter-module communication bandwidth by {overall_ratio_vq:.0f}x (VQ mode)")
    print(f"  and {overall_ratio_attn:.0f}x (attention mode) compared to natural language,")
    print(f"  reducing mean message size from {np.mean(all_bytes):.0f} bytes ({np.mean(all_tokens):.0f} tokens)")
    print(f"  to {qcp_vq_size} bytes (VQ) or {qcp_attn_size} bytes (attention).")

    return {
        'compression_vq': overall_ratio_vq,
        'compression_attn': overall_ratio_attn,
    }


if __name__ == "__main__":
    run()
