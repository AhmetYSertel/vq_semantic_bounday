"""
Experiment 16: Downstream Task Validation (NEW — P0)
=====================================================
The primary missing experiment from both reviews.

Tests whether QCP-compressed communication preserves TASK UTILITY,
not just encoding fidelity.

Setup: Semantic routing pipeline
  - 10 target modules (handlers)
  - 1000 messages that should be routed to the correct handler
  - Three communication modes:
    (a) NL handoff: cosine similarity between full message embedding and handler centroids
    (b) Raw embedding: same as NL but with raw float32 vectors (no quantization)
    (c) QCP handoff: encode message to QCP code, decode, then route

Metrics: routing accuracy, bandwidth, latency per mode
"""

import sys
import time
import numpy as np
sys.path.insert(0, ".")
from qcp import Codebook, Encoder, QCP
from utils import (load_diverse_texts, generate_agent_messages,
                   save_json, save_csv, save_plot, print_table, COLORS)
import matplotlib.pyplot as plt


# Simulated handler definitions
HANDLERS = {
    'memory_retrieval': [
        "Retrieve from memory", "Fetch stored context", "Look up previous conversation",
        "Access memory store", "Get cached results", "Recall earlier information",
    ],
    'web_search': [
        "Search the web", "Look up online", "Find information on the internet",
        "Query search engine", "Web lookup for current data",
    ],
    'code_generation': [
        "Write code", "Generate a function", "Create a script",
        "Implement the algorithm", "Code this feature",
    ],
    'summarization': [
        "Summarize this text", "Create a summary", "Condense the information",
        "Brief overview of the content", "Shorten this document",
    ],
    'translation': [
        "Translate to French", "Convert to Spanish", "Translate this text",
        "Render in German", "Localize to Japanese",
    ],
    'sentiment_analysis': [
        "Analyze the sentiment", "What is the tone", "Is this positive or negative",
        "Classify the emotion", "Sentiment of this review",
    ],
    'data_extraction': [
        "Extract entities", "Pull out the key facts", "Parse the structured data",
        "Identify the main entities", "Extract relevant fields",
    ],
    'validation': [
        "Validate the output", "Check for errors", "Verify the result",
        "Quality assurance check", "Confirm correctness",
    ],
    'classification': [
        "Classify this item", "Categorize the input", "What type is this",
        "Assign a label", "Determine the category",
    ],
    'math_computation': [
        "Calculate the result", "Compute the value", "Do the math",
        "Solve this equation", "Run the numerical computation",
    ],
}


def generate_routing_test_set(encoder, n_per_handler=100, seed=42):
    """Generate test messages that should route to specific handlers."""
    np.random.seed(seed)
    messages = []

    # Templates for generating diverse messages per handler
    variations = [
        "{base}",
        "Please {base}.",
        "I need you to {base}.",
        "Can you {base}?",
        "{base} for me.",
        "Go ahead and {base}.",
        "Your task: {base}.",
        "Next step: {base}.",
    ]

    for handler_name, examples in HANDLERS.items():
        for i in range(n_per_handler):
            base = examples[i % len(examples)]
            variation = variations[i % len(variations)]
            # Add some noise words
            noise_words = ["", " now", " quickly", " carefully", " immediately", " please"]
            noise = noise_words[np.random.randint(len(noise_words))]
            text = variation.format(base=base.lower()) + noise
            messages.append({
                'text': text.strip(),
                'ground_truth': handler_name,
            })

    np.random.shuffle(messages)
    return messages


def run(n_per_handler=100, K=256, seed=42):
    print("\n" + "=" * 60)
    print("  EXPERIMENT 16: Downstream Task Validation")
    print("=" * 60)

    np.random.seed(seed)
    encoder = Encoder()

    # --- 1. Build handler embeddings ---
    print("\n[1/5] Building handler reference embeddings...")
    handler_names = list(HANDLERS.keys())
    handler_embeddings = {}
    for name, examples in HANDLERS.items():
        embs = encoder.encode(examples)
        handler_embeddings[name] = np.mean(embs, axis=0)  # centroid of examples
    handler_matrix = np.stack([handler_embeddings[h] for h in handler_names])  # (10, d)

    # --- 2. Generate test messages ---
    print(f"[2/5] Generating {n_per_handler * len(HANDLERS)} test messages...")
    test_messages = generate_routing_test_set(encoder, n_per_handler, seed)
    test_texts = [m['text'] for m in test_messages]
    test_labels = [m['ground_truth'] for m in test_messages]
    test_embeddings = encoder.encode(test_texts, batch_size=256, show_progress_bar=True)

    # --- 3. Train QCP codebook (on separate data) ---
    print("[3/5] Training QCP codebook on separate corpus...")
    train_texts = load_diverse_texts(5000, seed=seed+1)  # different from test
    train_embs = encoder.encode(train_texts, batch_size=256)
    codebook = Codebook.train(train_embs, K=K, random_state=seed)
    qcp = QCP(codebook)

    # --- 4. Route in three modes ---
    print("[4/5] Routing in three modes...")

    def route(embeddings, handler_matrix, handler_names):
        """Route by cosine similarity to handler centroids."""
        # Normalize
        e_norm = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
        h_norm = handler_matrix / np.linalg.norm(handler_matrix, axis=1, keepdims=True)
        sims = e_norm @ h_norm.T  # (N, 10)
        predictions = [handler_names[i] for i in np.argmax(sims, axis=1)]
        return predictions, sims

    results = {}

    # Mode A: Raw embedding (ground truth proxy — no quantization)
    t0 = time.perf_counter()
    pred_raw, sims_raw = route(test_embeddings, handler_matrix, handler_names)
    t_raw = time.perf_counter() - t0
    acc_raw = float(np.mean([p == l for p, l in zip(pred_raw, test_labels)]))
    results['raw_embedding'] = {
        'accuracy': acc_raw,
        'latency_ms': t_raw * 1000,
        'bandwidth_per_msg': test_embeddings.shape[1] * 4,  # d * float32
    }

    # Mode B: QCP handoff
    t0 = time.perf_counter()
    qcp_result = qcp.encode_full_batch(test_embeddings)
    qcp_decoded = qcp_result['decoded']
    pred_qcp, sims_qcp = route(qcp_decoded, handler_matrix, handler_names)
    t_qcp = time.perf_counter() - t0
    acc_qcp = float(np.mean([p == l for p, l in zip(pred_qcp, test_labels)]))

    # Per-message bandwidth
    vq_count = int(np.sum(qcp_result['modes'] == 'vq'))
    attn_count = int(np.sum(qcp_result['modes'] == 'attn'))
    avg_bw = (vq_count * 37 + attn_count * 88) / len(test_embeddings)

    results['qcp'] = {
        'accuracy': acc_qcp,
        'latency_ms': t_qcp * 1000,
        'bandwidth_per_msg': avg_bw,
        'vq_ratio': qcp_result['vq_ratio'],
        'attn_ratio': qcp_result['attn_ratio'],
    }

    # Mode C: NL simulation (embedding of paraphrased text — simulates NL gen + re-encode)
    # We simulate NL communication by adding noise to embeddings (models NL paraphrase variability)
    t0 = time.perf_counter()
    noise_scale = 0.05  # empirical paraphrase embedding noise
    nl_embeddings = test_embeddings + np.random.randn(*test_embeddings.shape).astype(np.float32) * noise_scale
    pred_nl, sims_nl = route(nl_embeddings, handler_matrix, handler_names)
    t_nl = time.perf_counter() - t0
    acc_nl = float(np.mean([p == l for p, l in zip(pred_nl, test_labels)]))
    results['nl_simulated'] = {
        'accuracy': acc_nl,
        'latency_ms': t_nl * 1000,
        'bandwidth_per_msg': 45 * 4.4,  # avg 45 tokens * ~4.4 bytes
        'note': 'NL simulated via Gaussian noise on embeddings (scale=0.05)',
    }

    # --- 5. Analysis ---
    print("[5/5] Analyzing results...\n")

    # Accuracy delta
    acc_drop = acc_raw - acc_qcp

    # Per-handler accuracy breakdown
    per_handler = {}
    for handler in handler_names:
        mask = [l == handler for l in test_labels]
        if sum(mask) == 0:
            continue
        raw_h = float(np.mean([p == l for p, l, m in zip(pred_raw, test_labels, mask) if m]))
        qcp_h = float(np.mean([p == l for p, l, m in zip(pred_qcp, test_labels, mask) if m]))
        nl_h = float(np.mean([p == l for p, l, m in zip(pred_nl, test_labels, mask) if m]))
        per_handler[handler] = {'raw': raw_h, 'qcp': qcp_h, 'nl': nl_h}

    results['per_handler'] = per_handler
    results['accuracy_drop_qcp_vs_raw'] = acc_drop

    # Print
    headers = ["Mode", "Accuracy", "Bandwidth/msg", "Latency (ms)", "Acc Drop vs Raw"]
    rows = [
        ["Raw Embedding", f"{acc_raw:.3f}", f"{results['raw_embedding']['bandwidth_per_msg']:.0f} B",
         f"{results['raw_embedding']['latency_ms']:.2f}", "0 (baseline)"],
        ["QCP Handoff", f"{acc_qcp:.3f}", f"{results['qcp']['bandwidth_per_msg']:.0f} B",
         f"{results['qcp']['latency_ms']:.2f}", f"{acc_drop:+.3f}"],
        ["NL Simulated", f"{acc_nl:.3f}", f"{results['nl_simulated']['bandwidth_per_msg']:.0f} B",
         f"{results['nl_simulated']['latency_ms']:.2f}",
         f"{acc_raw - acc_nl:+.3f}"],
    ]
    print_table(headers, rows, "Downstream Task Validation: Semantic Routing")

    print("  Per-handler accuracy:")
    for h, vals in per_handler.items():
        print(f"    {h:25s}  raw={vals['raw']:.3f}  qcp={vals['qcp']:.3f}  nl={vals['nl']:.3f}")

    save_json({
        'seed': seed, 'K': K, 'n_per_handler': n_per_handler,
        'n_handlers': len(HANDLERS), 'total_messages': len(test_messages),
        'results': results,
    }, "exp16_downstream_validation")

    # Plot
    fig, axes = plt.subplots(1, 2, figsize=(14, 6))
    modes = ['Raw Embedding', 'QCP', 'NL Simulated']
    accs = [acc_raw, acc_qcp, acc_nl]
    bws = [results['raw_embedding']['bandwidth_per_msg'],
           results['qcp']['bandwidth_per_msg'],
           results['nl_simulated']['bandwidth_per_msg']]
    cs = [COLORS['raw_emb'], COLORS['qcp'], COLORS['nl']]

    axes[0].bar(modes, accs, color=cs, alpha=0.8)
    axes[0].set_ylabel("Routing Accuracy")
    axes[0].set_title("Task Accuracy by Communication Mode")
    axes[0].set_ylim(0, 1.05)
    for i, (m, a) in enumerate(zip(modes, accs)):
        axes[0].text(i, a + 0.01, f"{a:.3f}", ha='center', fontsize=10)

    axes[1].bar(modes, bws, color=cs, alpha=0.8)
    axes[1].set_ylabel("Bytes per Message")
    axes[1].set_title("Bandwidth per Message")
    for i, (m, b) in enumerate(zip(modes, bws)):
        axes[1].text(i, b + 2, f"{b:.0f}", ha='center', fontsize=10)

    fig.suptitle("Experiment 16: Downstream Task Validation", fontsize=14)
    plt.tight_layout()
    save_plot(fig, "exp16_downstream_validation")

    return results


if __name__ == "__main__":
    run()
