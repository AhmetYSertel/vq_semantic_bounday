# Analysis

This folder contains lightweight scripts to turn the raw JSON/CSV outputs under `results/` into
paper-style figures and summary tables.

## Usage

```bash
python analysis/make_figures.py
python analysis/make_tables.py
```

Outputs:
- Figures: `results/figures/`
- Tables: `results/tables/`
