"""Build paper-style summary tables from experiment outputs."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
OUTDIR = RESULTS / "tables"
OUTDIR.mkdir(parents=True, exist_ok=True)


def _read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def build_key_metrics_table() -> None:
    """Recreate a 'Table 3'-style summary from the saved result files when available."""

    rows = []

    # Exp2 bandwidth
    bw = RESULTS / "exp2_bandwidth_summary.json"
    if bw.exists():
        d = _read_json(bw)
        rows.append(("NL bytes / message", d.get("nl_bytes_per_message") or d.get("nl_bytes_mean")))
        rows.append(("VQ bytes / message", d.get("vq_bytes_per_message") or d.get("vq_bytes")))
        rows.append(("VQ compression ratio", d.get("compression_ratio") or d.get("bandwidth_compression")))

    # Exp4 throughput
    thr = RESULTS / "exp4_throughput_v2.json"
    if thr.exists():
        d = _read_json(thr)
        rows.append(("Batch VQ throughput (msg/s)", d.get("batch_vq_msgs_per_sec") or d.get("batch_vq_throughput")))
        rows.append(("Decode throughput (msg/s)", d.get("decode_msgs_per_sec") or d.get("decode_throughput")))

    # Exp1 fidelity
    fid = RESULTS / "exp1_fidelity_summary.json"
    if fid.exists():
        d = _read_json(fid)
        rows.append(("Mean fidelity (VQ-only)", d.get("mean_cosine") or d.get("mean_fidelity")))
        rows.append(("Median fidelity (VQ-only)", d.get("median_cosine") or d.get("median_fidelity")))

    # Exp3 coverage
    cov = RESULTS / "exp3_coverage_summary.json"
    if cov.exists():
        d = _read_json(cov)
        rows.append(("Coverage > 0.90 fidelity", d.get("coverage_over_0p9") or d.get("coverage_0p90")))

    # Exp5 cache
    cache = RESULTS / "exp5_cache_summary.json"
    if cache.exists():
        d = _read_json(cache)
        rows.append(("Semantic cache hit rate", d.get("code_hit_rate") or d.get("semantic_cache_hit_rate")))
        rows.append(("NL string cache hit rate", d.get("string_hit_rate") or d.get("nl_string_hit_rate")))

    # Exp17 routing baseline comparison
    rout = RESULTS / "exp17_baseline_comparison.json"
    if rout.exists():
        d = _read_json(rout)
        # best-effort
        for key, label in [
            ("raw_embeddings", "Raw embedding routing acc."),
            ("vq", "VQ routing accuracy"),
            ("qcp", "VQ routing accuracy"),
        ]:
            if key in d and isinstance(d[key], dict):
                acc = d[key].get("accuracy") or d[key].get("acc")
                if acc is not None:
                    rows.append((label, acc))

    # Exp19 negation
    neg = RESULTS / "exp19_negation_frequency.json"
    if neg.exists():
        d = _read_json(neg)
        rows.append(("Negation pass rate", d.get("negation_pass_rate") or d.get("pass_rate")))

    # Exp15 mismatch
    mm = RESULTS / "exp15_codebook_mismatch_summary.json"
    if mm.exists():
        d = _read_json(mm)
        rows.append(("Mismatch mean fidelity", d.get("mismatch_mean_fidelity") or d.get("mean_fidelity_mismatch")))

    df = pd.DataFrame(rows, columns=["Metric", "Result"]).dropna()
    out_csv = OUTDIR / "key_metrics_table.csv"
    out_md = OUTDIR / "key_metrics_table.md"
    df.to_csv(out_csv, index=False)

    # markdown export
    with out_md.open("w", encoding="utf-8") as f:
        f.write(df.to_markdown(index=False))
        f.write("\n")


def main() -> None:
    build_key_metrics_table()
    print(f"Saved tables to: {OUTDIR}")


if __name__ == "__main__":
    main()
