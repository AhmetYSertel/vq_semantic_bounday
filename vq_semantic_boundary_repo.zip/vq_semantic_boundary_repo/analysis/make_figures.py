"""Generate paper-style figures from experiment outputs.

This script is intentionally dependency-light and only reads files produced by `experiments/run_all.py`.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGDIR = RESULTS / "figures"
FIGDIR.mkdir(parents=True, exist_ok=True)


def _read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def fig_k_sweep() -> None:
    """Plot fidelity vs K and (if present) escalation/attention rate vs K."""
    path = RESULTS / "exp6_k_sweep.csv"
    if not path.exists():
        return
    df = pd.read_csv(path)

    # Best-effort column detection (repo evolved across versions)
    k_col = "K" if "K" in df.columns else ("k" if "k" in df.columns else df.columns[0])

    fidelity_cols = [c for c in df.columns if "fidelity" in c.lower() or "cos" in c.lower()]
    esc_cols = [c for c in df.columns if "escal" in c.lower() or "trigger" in c.lower() or "attention" in c.lower()]

    plt.figure(figsize=(8, 5))
    if fidelity_cols:
        plt.plot(df[k_col], df[fidelity_cols[0]], marker="o")
        plt.xscale("log")
        plt.xlabel("Codebook size (K)")
        plt.ylabel(fidelity_cols[0])
        plt.title("Fidelity vs Codebook Size")
        plt.tight_layout()
        plt.savefig(FIGDIR / "k_sweep_fidelity.png", dpi=200)
    plt.close()

    if esc_cols:
        plt.figure(figsize=(8, 5))
        plt.plot(df[k_col], df[esc_cols[0]], marker="o")
        plt.xscale("log")
        plt.xlabel("Codebook size (K)")
        plt.ylabel(esc_cols[0])
        plt.title("Escalation/Trigger Rate vs Codebook Size")
        plt.tight_layout()
        plt.savefig(FIGDIR / "k_sweep_escalation.png", dpi=200)
        plt.close()


def fig_routing_cliff() -> None:
    """Bar chart for routing accuracies from exp17 baseline comparison, if present."""
    path = RESULTS / "exp17_baseline_comparison.json"
    if not path.exists():
        return

    data = _read_json(path)

    # Expected keys from your paper: raw embeddings, NL proxy, generic VQ.
    # Best-effort extraction.
    candidates = {}
    for k, v in data.items():
        lk = k.lower()
        if isinstance(v, (int, float)):
            if "raw" in lk and "acc" in lk:
                candidates["Raw embeddings"] = v
            elif "nl" in lk and "acc" in lk:
                candidates["Natural-language proxy"] = v
            elif ("vq" in lk or "qcp" in lk) and "acc" in lk:
                candidates["Quantized codes"] = v

    # Fallback: some versions store nested dicts
    if not candidates:
        for k in ["raw_embeddings", "natural_language", "vq", "qcp"]:
            if k in data and isinstance(data[k], dict):
                acc = data[k].get("accuracy") or data[k].get("acc")
                if isinstance(acc, (int, float)):
                    label = {
                        "raw_embeddings": "Raw embeddings",
                        "natural_language": "Natural-language proxy",
                        "vq": "Quantized codes",
                        "qcp": "Quantized codes",
                    }[k]
                    candidates[label] = acc

    if not candidates:
        return

    labels = list(candidates.keys())
    vals = [candidates[l] for l in labels]

    plt.figure(figsize=(8, 5))
    plt.bar(labels, vals)
    plt.ylim(0, 1.0 if max(vals) <= 1.0 else 100.0)
    plt.ylabel("Accuracy")
    plt.title("Downstream Routing Accuracy")
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(FIGDIR / "routing_cliff.png", dpi=200)
    plt.close()


def fig_latency_breakdown() -> None:
    path = RESULTS / "exp18_latency_decomposition.json"
    if not path.exists():
        return
    data = _read_json(path)

    # Expected keys (ms): embedding, quantization, serialization, decoding
    # Best-effort extraction.
    items = {}
    for key in ["embedding_ms", "quantization_ms", "serialization_ms", "decode_ms", "decoding_ms"]:
        v = data.get(key)
        if isinstance(v, (int, float)):
            items[key.replace("_ms", "")] = v

    # Fallback nested
    if not items and "components_ms" in data and isinstance(data["components_ms"], dict):
        for k, v in data["components_ms"].items():
            if isinstance(v, (int, float)):
                items[k] = v

    if not items:
        return

    plt.figure(figsize=(8, 5))
    plt.bar(list(items.keys()), list(items.values()))
    plt.ylabel("Milliseconds")
    plt.title("VQ-Path Latency Decomposition")
    plt.tight_layout()
    plt.savefig(FIGDIR / "latency_decomposition.png", dpi=200)
    plt.close()


def main() -> None:
    fig_k_sweep()
    fig_routing_cliff()
    fig_latency_breakdown()
    print(f"Saved figures to: {FIGDIR}")


if __name__ == "__main__":
    main()
