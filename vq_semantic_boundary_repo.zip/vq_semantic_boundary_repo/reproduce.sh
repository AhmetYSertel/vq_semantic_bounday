#!/usr/bin/env bash
set -euo pipefail

python -m pip install --upgrade pip
pip install -r requirements.txt

# Run the core experiments that back the main claims in the paper.
python experiments/run_all.py --exp 1 2 4 5 6 15 16 17 18 19 20

# Build paper-style figures from the saved results.
python analysis/make_figures.py
python analysis/make_tables.py

echo "\nDone. See results/figures and results/tables." 
