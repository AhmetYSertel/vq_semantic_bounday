"""
QCP: Quantized Communication Protocol
Core library implementing the full QCP specification.

Reference: QCP Paper (Sertel, 2026)
"""

import numpy as np
import time
from dataclasses import dataclass, field
from typing import Optional, List, Tuple, Dict, Any
from sklearn.cluster import MiniBatchKMeans


# ============================================================
# Data Structures
# ============================================================

@dataclass
class QCPMessage:
    """Standard QCP message (VQ mode)."""
    mode: str  # 'vq' or 'attn'
    codes: List[int]
    qerr: float
    conf: float
    delta: float
    source_id: str = ""
    timestamp: int = 0
    meta: Dict[str, Any] = field(default_factory=dict)

    def size_bytes(self) -> int:
        """Estimate message size in bytes."""
        # codes: 1-2 bytes each, qerr/conf/delta: 4 bytes each (fp32),
        # source_id: ~16 bytes, timestamp: 8 bytes
        code_bytes = len(self.codes) * (1 if max(self.codes) < 256 else 2)
        return code_bytes + 12 + 16 + 8  # ~37 bytes typical


@dataclass
class QCPMessageAttn:
    """Attention-weighted QCP message."""
    mode: str = "attn"
    weights: np.ndarray = None          # full K-dim or sparse
    sparse_indices: np.ndarray = None   # top-k indices
    sparse_weights: np.ndarray = None   # top-k weights
    qerr: float = 0.0
    source_id: str = ""
    timestamp: int = 0
    meta: Dict[str, Any] = field(default_factory=dict)

    def size_bytes(self, sparse_k: int = 16) -> int:
        """Estimate message size in bytes (sparse transmission)."""
        # sparse top-k: k indices (2 bytes each) + k weights (2 bytes fp16 each)
        # + metadata (~24 bytes)
        return sparse_k * 2 + sparse_k * 2 + 24  # ~88 bytes for k=16


# ============================================================
# Codebook
# ============================================================

class Codebook:
    """
    QCP Codebook: a finite set of semantic centroids.
    C = {e_1, e_2, ..., e_K}, e_i ∈ R^d
    """

    def __init__(self, centroids: np.ndarray, version: str = "v1.0"):
        """
        Args:
            centroids: (K, d) array of centroid vectors
            version: codebook version identifier
        """
        self.centroids = centroids.astype(np.float32)
        self.K = centroids.shape[0]
        self.d = centroids.shape[1]
        self.version = version
        # Precompute norms for faster distance computation
        self._centroid_norms = np.linalg.norm(self.centroids, axis=1)

    @staticmethod
    def train(embeddings: np.ndarray, K: int, batch_size: int = 1024,
              random_state: int = 42, max_iter: int = 300) -> 'Codebook':
        """
        Train a codebook via MiniBatch K-Means.

        Args:
            embeddings: (N, d) training embeddings
            K: number of centroids
            batch_size: mini-batch size for k-means
            random_state: reproducibility seed
            max_iter: maximum iterations

        Returns:
            Trained Codebook instance
        """
        effective_K = min(K, len(embeddings))
        kmeans = MiniBatchKMeans(
            n_clusters=effective_K,
            batch_size=min(batch_size, len(embeddings)),
            random_state=random_state,
            max_iter=max_iter,
            n_init=3
        )
        kmeans.fit(embeddings)
        version = f"v1.0-K{effective_K}-d{embeddings.shape[1]}"
        return Codebook(kmeans.cluster_centers_, version=version)

    def decode(self, code: int) -> np.ndarray:
        """Decode a single code to its centroid vector. O(1) table lookup."""
        return self.centroids[code]

    def decode_batch(self, codes: np.ndarray) -> np.ndarray:
        """Decode a batch of codes. (N,) -> (N, d)."""
        return self.centroids[codes]

    def get_version(self) -> str:
        return self.version


# ============================================================
# Encoder Wrapper
# ============================================================

class Encoder:
    """Wrapper around sentence-transformers encoder."""

    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
                 device: str = None):
        from sentence_transformers import SentenceTransformer
        import torch
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model = SentenceTransformer(model_name, device=device)
        self.device = device
        self.d = self.model.get_sentence_embedding_dimension()
        self.model_name = model_name

    def encode(self, texts, batch_size: int = 256,
               show_progress_bar: bool = False) -> np.ndarray:
        """Encode texts to embeddings. Returns (N, d) float32 array."""
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress_bar,
            convert_to_numpy=True
        )
        return embeddings.astype(np.float32)

    def encode_single(self, text: str) -> np.ndarray:
        """Encode a single text. Returns (d,) float32 array."""
        return self.encode([text], batch_size=1)[0]


# ============================================================
# QCP Protocol Operations
# ============================================================

class QCP:
    """
    QCP Protocol: encoding, decoding, mode selection, and message construction.
    """

    def __init__(self, codebook: Codebook, alpha: float = 0.5,
                 delta_min: float = 0.01):
        """
        Args:
            codebook: QCP Codebook instance
            alpha: confidence threshold for mode selection
            delta_min: margin threshold for mode selection
        """
        self.codebook = codebook
        self.alpha = alpha
        self.delta_min = delta_min

    # --- Core Encoding ---

    def encode_vq(self, embedding: np.ndarray) -> Tuple[int, float, float, float]:
        """
        VQ argmin encoding (Mode 1: High Confidence).

        encode(s) = argmin_i ||E(s) - e_i||^2

        Args:
            embedding: (d,) input embedding

        Returns:
            (code, qerr, conf, delta)
        """
        # Compute squared distances to all centroids
        diff = self.codebook.centroids - embedding  # (K, d)
        distances_sq = np.sum(diff ** 2, axis=1)    # (K,)

        # Argmin
        code = int(np.argmin(distances_sq))
        qerr = float(distances_sq[code])

        # Confidence: conf(s) = 1 / (1 + qerr(s))
        conf = 1.0 / (1.0 + qerr)

        # Margin: Δ(s) = ||E(s) - e_(2)||^2 - ||E(s) - e_(1)||^2
        sorted_dists = np.sort(distances_sq)
        delta = float(sorted_dists[1] - sorted_dists[0]) if len(sorted_dists) > 1 else float('inf')

        return code, qerr, conf, delta

    def encode_vq_batch(self, embeddings: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """
        Batch VQ argmin encoding.

        Args:
            embeddings: (N, d) input embeddings

        Returns:
            (codes, qerrs, confs, deltas) each of shape (N,)
        """
        # Compute all pairwise squared distances: (N, K)
        # ||a - b||^2 = ||a||^2 + ||b||^2 - 2*a·b
        emb_norms_sq = np.sum(embeddings ** 2, axis=1, keepdims=True)  # (N, 1)
        cent_norms_sq = np.sum(self.codebook.centroids ** 2, axis=1, keepdims=True).T  # (1, K)
        dot_products = embeddings @ self.codebook.centroids.T  # (N, K)
        distances_sq = emb_norms_sq + cent_norms_sq - 2 * dot_products  # (N, K)

        # Argmin per row
        codes = np.argmin(distances_sq, axis=1)  # (N,)
        qerrs = distances_sq[np.arange(len(codes)), codes]  # (N,)
        confs = 1.0 / (1.0 + qerrs)

        # Margin: difference between 2nd nearest and nearest
        sorted_dists = np.sort(distances_sq, axis=1)
        deltas = sorted_dists[:, 1] - sorted_dists[:, 0]

        return codes.astype(np.int32), qerrs.astype(np.float32), confs.astype(np.float32), deltas.astype(np.float32)

    def encode_attention(self, embedding: np.ndarray,
                         sparse_k: int = 8) -> Tuple[np.ndarray, np.ndarray]:
        """
        Optimal reconstruction encoding (Mode 2: Low Confidence).
        
        Instead of softmax-weighted average (which optimizes similarity,
        not reconstruction), uses least-squares projection onto top-k
        nearest centroids. This finds the optimal weight combination
        that minimizes ||E(s) - Σ w_i * c_i||².

        Args:
            embedding: (d,) input embedding
            sparse_k: number of nearest centroids to use

        Returns:
            (weights, decoded_embedding) — weights: (K,), decoded: (d,)
        """
        # Find top-k nearest centroids by squared L2 distance (consistent with k-means / VQ)
        # dist^2(e, c) = ||e||^2 + ||c||^2 - 2 e·c
        e_norm = float(np.sum(embedding ** 2))
        dots = embedding @ self.codebook.centroids.T  # (K,)
        distances_sq = e_norm + self.codebook._centroid_norms ** 2 - 2.0 * dots  # (K,)
        top_indices = np.argsort(distances_sq)[:sparse_k]


        # Extract top-k centroids: (sparse_k, d)
        C_topk = self.codebook.centroids[top_indices]

        # Least-squares: w* = argmin ||e - C^T w||^2
        # Closed form: w* = (C C^T)^{-1} C e
        # Using numpy lstsq for numerical stability
        w_sparse, _, _, _ = np.linalg.lstsq(C_topk.T, embedding, rcond=None)  # (sparse_k,)

        # Reconstruct
        decoded = C_topk.T @ w_sparse  # (d,)

        # Store as full K-dim weight vector (sparse)
        weights = np.zeros(self.codebook.K, dtype=np.float32)
        weights[top_indices] = w_sparse.astype(np.float32)

        return weights, decoded.astype(np.float32)

    def encode_attention_batch(self, embeddings: np.ndarray,
                               sparse_k: int = 8) -> Tuple[np.ndarray, np.ndarray]:
        """
        Batch optimal reconstruction encoding via least-squares projection.
        Vectorized: precomputes Gram matrices and solves in batch.

        Args:
            embeddings: (N, d) input embeddings
            sparse_k: number of nearest centroids per sample

        Returns:
            (weights, decoded_embeddings) — weights: (N, K), decoded: (N, d)
        """
        N, d = embeddings.shape
        K = self.codebook.K

        # Find top-k nearest centroids per sample by squared L2 distance (consistent with k-means / VQ)
        # dist^2(E, C) = ||E||^2 + ||C||^2 - 2 E·C
        e_norms = np.sum(embeddings ** 2, axis=1, keepdims=True)  # (N, 1)
        dots = embeddings @ self.codebook.centroids.T  # (N, K)
        distances_sq = e_norms + (self.codebook._centroid_norms ** 2)[None, :] - 2.0 * dots  # (N, K)
        top_indices = np.argpartition(distances_sq, sparse_k-1, axis=1)[:, :sparse_k]  # (N, sparse_k)

        # Gather top-k centroids for all samples: (N, sparse_k, d)
        C_batch = self.codebook.centroids[top_indices]

        # Gram matrices: G_i = C_i @ C_i^T -> (N, sparse_k, sparse_k)
        G = np.einsum('nkd,nld->nkl', C_batch, C_batch)

        # Right-hand side: b_i = C_i @ e_i -> (N, sparse_k)
        b = np.einsum('nkd,nd->nk', C_batch, embeddings)

        # Regularize for numerical stability
        reg = 1e-6 * np.eye(sparse_k, dtype=np.float32)
        G += reg[None, :, :]

        # Batch solve: w = G^{-1} b
        # np.linalg.solve with batched inputs: G is (N, k, k), b must be (N, k, 1)
        try:
            w_batch = np.linalg.solve(G, b[..., None]).squeeze(-1)  # (N, sparse_k)
        except (np.linalg.LinAlgError, ValueError):
            # Fallback to per-sample lstsq if batch solve fails
            w_batch = np.zeros((N, sparse_k), dtype=np.float32)
            for i in range(N):
                w_batch[i], _, _, _ = np.linalg.lstsq(
                    C_batch[i].T, embeddings[i], rcond=None)

        # Reconstruct: decoded_i = C_i^T @ w_i -> (N, d)
        decoded = np.einsum('nkd,nk->nd', C_batch, w_batch)

        # Scatter weights into full K-dim vectors
        weights = np.zeros((N, K), dtype=np.float32)
        rows = np.arange(N)[:, None]
        weights[rows, top_indices] = w_batch.astype(np.float32)

        return weights, decoded.astype(np.float32)

    # --- Mode Selection ---

    def select_mode(self, conf: float, delta: float) -> str:
        """
        Dual-mode selection (Section 3.5.5).

        VQ Argmin: conf >= alpha AND delta >= delta_min
        Attention: conf < alpha OR delta < delta_min
        """
        if conf >= self.alpha and delta >= self.delta_min:
            return 'vq'
        return 'attn'

    # --- Full Encoding Pipeline ---

    def encode(self, embedding: np.ndarray) -> dict:
        """
        Full QCP encoding pipeline with automatic mode selection.
        Includes VQ fallback: if attention doesn't beat VQ, use VQ.

        Returns dict with mode, code/weights, metrics.
        """
        code, qerr, conf, delta = self.encode_vq(embedding)
        vq_decoded = self.codebook.decode(code)
        mode = self.select_mode(conf, delta)

        if mode == 'vq':
            return {
                'mode': 'vq',
                'code': code,
                'decoded': vq_decoded,
                'qerr': qerr,
                'conf': conf,
                'delta': delta
            }
        else:
            weights, attn_decoded = self.encode_attention(embedding)

            # VQ fallback guarantee
            attn_fidelity = self.cosine_similarity(embedding, attn_decoded)
            vq_fidelity = self.cosine_similarity(embedding, vq_decoded)

            if attn_fidelity <= vq_fidelity:
                # Attention didn't help, fall back to VQ
                return {
                    'mode': 'vq',
                    'code': code,
                    'decoded': vq_decoded,
                    'qerr': qerr,
                    'conf': conf,
                    'delta': delta
                }

            # Sparse top-k for transmission
            top_k = 16
            top_indices = np.argsort(weights)[-top_k:][::-1]
            sparse_weights = weights[top_indices]
            return {
                'mode': 'attn',
                'weights': weights,
                'sparse_indices': top_indices,
                'sparse_weights': sparse_weights,
                'decoded': attn_decoded,
                'qerr': qerr,
                'conf': conf,
                'delta': delta
            }

    def encode_full_batch(self, embeddings: np.ndarray) -> dict:
        """
        Batch encoding with per-sample mode selection.
        Includes VQ fallback guarantee: if attention reconstruction
        is worse than VQ for a sample, VQ is used instead.

        Returns dict with arrays for all metrics and per-sample modes.
        """
        codes, qerrs, confs, deltas = self.encode_vq_batch(embeddings)

        # Mode selection per sample
        vq_mask = (confs >= self.alpha) & (deltas >= self.delta_min)
        attn_mask = ~vq_mask

        # VQ decoded for ALL samples (needed for fallback comparison)
        vq_decoded = self.codebook.decode_batch(codes)

        # Attention decoded for low-confidence samples
        decoded = vq_decoded.copy()
        actual_attn_count = 0

        if np.any(attn_mask):
            attn_embeddings = embeddings[attn_mask]
            attn_weights, attn_decoded = self.encode_attention_batch(attn_embeddings)

            # VQ fallback guarantee: only use attention if it's actually better
            vq_for_attn = vq_decoded[attn_mask]

            # Compute fidelity for both
            attn_fidelities = self.cosine_similarity_batch(attn_embeddings, attn_decoded)
            vq_fidelities = self.cosine_similarity_batch(attn_embeddings, vq_for_attn)

            # Use attention only where it beats VQ
            attn_better = attn_fidelities > vq_fidelities
            actual_attn_count = int(np.sum(attn_better))

            # Apply: attention where better, VQ where not
            attn_indices = np.where(attn_mask)[0]
            for i, idx in enumerate(attn_indices):
                if attn_better[i]:
                    decoded[idx] = attn_decoded[i]
                # else: keep vq_decoded (already in decoded)

            # Update mask to reflect actual attention usage
            final_attn_mask = np.zeros(len(embeddings), dtype=bool)
            final_attn_mask[attn_indices[attn_better]] = True
            attn_mask = final_attn_mask
            vq_mask = ~attn_mask

        modes = np.where(attn_mask, 'attn', 'vq')

        return {
            'codes': codes,
            'qerrs': qerrs,
            'confs': confs,
            'deltas': deltas,
            'modes': modes,
            'decoded': decoded,
            'vq_ratio': float(np.mean(vq_mask)),
            'attn_ratio': float(np.mean(attn_mask)),
        }

    # --- Message Construction ---

    def build_message(self, embedding: np.ndarray,
                      source_id: str = "module_a") -> QCPMessage:
        """Build a QCPMessage from an embedding."""
        result = self.encode(embedding)
        return QCPMessage(
            mode=result['mode'],
            codes=[result.get('code', -1)],
            qerr=result['qerr'],
            conf=result['conf'],
            delta=result['delta'],
            source_id=source_id,
            timestamp=int(time.time()),
        )

    # --- Fidelity Computation ---

    @staticmethod
    def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))

    @staticmethod
    def cosine_similarity_batch(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Batch cosine similarity. (N, d) x (N, d) -> (N,)."""
        norms_a = np.linalg.norm(a, axis=1, keepdims=True)
        norms_b = np.linalg.norm(b, axis=1, keepdims=True)
        norms_a = np.maximum(norms_a, 1e-10)
        norms_b = np.maximum(norms_b, 1e-10)
        return np.sum((a / norms_a) * (b / norms_b), axis=1)

    def encoding_fidelity(self, embedding: np.ndarray) -> float:
        """
        Compute encoding fidelity: cos(E(s), decode(encode(s))).
        """
        code, _, _, _ = self.encode_vq(embedding)
        decoded = self.codebook.decode(code)
        return self.cosine_similarity(embedding, decoded)

    def encoding_fidelity_batch(self, embeddings: np.ndarray) -> np.ndarray:
        """Batch encoding fidelity."""
        codes, _, _, _ = self.encode_vq_batch(embeddings)
        decoded = self.codebook.decode_batch(codes)
        return self.cosine_similarity_batch(embeddings, decoded)


# ============================================================
# QCP Receiver Interface (Section 5)
# ============================================================

class QCPReceiver:
    """
    Minimal QCP Receiver Interface (Section 5.2).

    Any system can participate in QCP-based communication by
    implementing this interface.
    """

    def __init__(self):
        self.codebook: Optional[Codebook] = None

    def load_codebook(self, codebook: Codebook):
        """Accept and store a QCP codebook."""
        self.codebook = codebook

    def get_codebook_version(self) -> str:
        """Return version identifier of loaded codebook."""
        if self.codebook is None:
            return "none"
        return self.codebook.get_version()

    def on_message(self, msg: dict) -> np.ndarray:
        """
        Handle incoming QCP message.
        Returns decoded semantic vector.
        """
        assert self.codebook is not None, "No codebook loaded"

        if msg['mode'] == 'vq':
            return self.codebook.decode(msg['code'])
        elif msg['mode'] == 'attn':
            weights = msg['weights']
            return weights @ self.codebook.centroids
        else:
            raise ValueError(f"Unknown mode: {msg['mode']}")


# ============================================================
# Utility Functions
# ============================================================

def compute_retrieval_recall(query_embeddings: np.ndarray,
                             corpus_embeddings: np.ndarray,
                             codebook: Codebook,
                             k: int = 10,
                             probe_budget: int = 8) -> float:
    """
    Compute Recall@k for QCP-based retrieval.

    For each query, find the true top-k by brute-force cosine similarity,
    then find QCP's top-k by multi-probe code matching, and measure overlap.

    Args:
        query_embeddings: (N_q, d)
        corpus_embeddings: (N_c, d)
        codebook: QCP Codebook
        k: number of results to retrieve
        probe_budget: number of nearest centroids to probe

    Returns:
        Mean Recall@k
    """
    qcp = QCP(codebook)
    N_q = len(query_embeddings)

    # Encode corpus
    corpus_codes, _, _, _ = qcp.encode_vq_batch(corpus_embeddings)

    # Brute-force ground truth: cosine similarity
    q_norms = np.linalg.norm(query_embeddings, axis=1, keepdims=True)
    c_norms = np.linalg.norm(corpus_embeddings, axis=1, keepdims=True)
    q_normed = query_embeddings / np.maximum(q_norms, 1e-10)
    c_normed = corpus_embeddings / np.maximum(c_norms, 1e-10)

    recalls = []
    for i in range(N_q):
        # Ground truth top-k
        sims = q_normed[i] @ c_normed.T
        true_topk = set(np.argsort(sims)[-k:][::-1])

        # QCP multi-probe: find m nearest centroids to query
        q_emb = query_embeddings[i]
        dists_to_centroids = np.sum((codebook.centroids - q_emb) ** 2, axis=1)
        probe_codes = np.argsort(dists_to_centroids)[:probe_budget]

        # Candidates: all corpus items whose code is in probe set
        candidate_mask = np.isin(corpus_codes, probe_codes)
        candidate_indices = np.where(candidate_mask)[0]

        if len(candidate_indices) == 0:
            recalls.append(0.0)
            continue

        # Re-rank candidates by cosine similarity
        candidate_sims = q_normed[i] @ c_normed[candidate_indices].T
        if len(candidate_indices) <= k:
            retrieved_topk = set(candidate_indices)
        else:
            top_within = np.argsort(candidate_sims)[-k:][::-1]
            retrieved_topk = set(candidate_indices[top_within])

        recall = len(true_topk & retrieved_topk) / k
        recalls.append(recall)

    return float(np.mean(recalls))


def message_size_vq(K: int = 256) -> int:
    """Calculate VQ message size in bytes."""
    code_bytes = 1 if K <= 256 else 2
    # code + qerr(4) + conf(4) + delta(4) + source_id(16) + timestamp(8)
    return code_bytes + 4 + 4 + 4 + 16 + 8


def message_size_attn(sparse_k: int = 16) -> int:
    """Calculate attention message size in bytes."""
    # sparse indices (2 bytes each) + weights (2 bytes fp16 each) + metadata
    return sparse_k * 2 + sparse_k * 2 + 24


if __name__ == "__main__":
    print("QCP: Quantized Communication Protocol — Core Library")
    print(f"Supports codebook sizes K ∈ [1, 65536]")
    print(f"Dual-mode encoding: VQ argmin + Attention-weighted")
    print(f"Protocol version: 1.0")
